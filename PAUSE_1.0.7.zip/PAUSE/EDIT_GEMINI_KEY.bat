@echo off
cd /d "%~dp0"
if not exist ".env" (
  if exist ".env.example" (
    copy /Y ".env.example" ".env" >nul
  ) else (
    echo GEMINI_API_KEY= > ".env"
  )
)
notepad.exe "%~dp0.env"
