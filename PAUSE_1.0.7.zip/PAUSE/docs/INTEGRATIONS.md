# PAUSE provider integration guide

This document distinguishes a working provider flow from a roadmap card.

## Gmail — OAuth/API implemented, setup required

PAUSE uses an installed Desktop-app OAuth flow with PKCE and requests only:

`https://www.googleapis.com/auth/gmail.readonly`

The flow uses a loopback callback on `127.0.0.1`, exchanges the authorisation code, fetches the Gmail profile to verify the connection, and stores the refresh token encrypted with the current Windows user's DPAPI. The OAuth client ID is a public desktop-client identifier; PAUSE does not require a client secret in the UI.

### Setup

1. Create a Google Cloud project and enable the Gmail API.
2. Configure the OAuth consent screen and app audience/testing users.
3. Create a Desktop app OAuth client ID.
4. Paste the client ID in PAUSE → Connections → Gmail.
5. Start Connect Gmail and approve the read-only consent.
6. Run a manual scan or explicitly enable inbox monitoring.

The manual scan checks up to 20 messages in `in:inbox newer_than:2d`. The optional monitor repeats this every 120 seconds while the local PAUSE service is active. It is polling, not Gmail push notifications. Message contents are analysed in memory; event records contain the verdict, sender domain, reasons and summary but not the subject/body/full sender address. Hashed Gmail message IDs are stored for duplicate suppression.

Disconnect stops monitoring, attempts Google OAuth token revocation, and removes the local encrypted token file even if the device is offline. Users can also revoke app access from their Google Account settings.

**Google review:** Google classifies `gmail.readonly` as a restricted Gmail scope. Review/verification and security-assessment requirements depend on deployment and how restricted user data is stored/transmitted. A public PAUSE download must not claim an approved Gmail integration before those requirements are satisfied. Use a test account and dummy messages during development.

Official documentation:
- https://developers.google.com/workspace/gmail/api/auth/scopes
- https://developers.google.com/identity/protocols/oauth2
- https://developers.google.com/identity/protocols/oauth2/production-readiness/restricted-scope-verification
- https://developers.google.com/identity/protocols/oauth2/web-server#tokenrevoke

## Outlook and Hotmail — setup placeholder

Use Microsoft identity platform OAuth and Microsoft Graph. A message-change notification flow requires an Entra app registration, appropriate delegated mail permissions, subscription/webhook validation, renewal and recovery. Personal Microsoft accounts and work/school accounts have different permission boundaries and need separate testing. No Graph credentials or webhook are configured in this build.

Official documentation:
- https://learn.microsoft.com/en-us/graph/outlook-change-notifications-overview
- https://learn.microsoft.com/en-us/graph/api/subscription-post-subscriptions?view=graph-rest-1.0

## WhatsApp Personal — no direct inbox API

Do not scrape WhatsApp Web, copy session cookies, request QR login tokens or reverse-engineer private endpoints. The official WhatsApp Business Platform is separate from personal WhatsApp chats. PAUSE marks personal inbox access as unsupported. A future Windows notification-preview integration would only expose content Windows surfaces after a notification appears and could not stop delivery.

## WhatsApp Business — setup placeholder

The official Business Platform can deliver configured business message events to a verified webhook. A real connector needs a Meta business/developer app, registered business number, approved access token, webhook verification, subscription lifecycle, retention handling and a public HTTPS endpoint. This local-only build has no Meta credentials or public webhook.

Official developer hub:
- https://developers.facebook.com/documentation/business-messaging/whatsapp/

## Provider release rules

A connector may show **Connected** only after an actual provider authorisation and successful identity/API verification. Before public availability, every integration needs token encryption, state/signature validation, disconnect/revoke, permission expiry handling, duplicate-event handling, error/rate-limit handling, privacy documentation, retention tests and security review.


## Notification delivery

PAUSE intentionally does not request browser notification permission or create Windows/browser desktop pop-ups. Quiet Mode ON keeps findings in the in-app Alert Centre; OFF surfaces new priority batches in the app status line. Gmail monitoring polls every 120 seconds while the local PAUSE service is active. Events are stored locally for review when the app is open again.
