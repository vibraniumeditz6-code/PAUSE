# Security, privacy and known limits — PAUSE 1.0.1

PAUSE is a local-first heuristic protection tool. Build 1.0.1 is not antivirus, EDR, a network firewall, a certified system-wide action monitor, or an independently audited security product.

## Activity Map boundaries

- The Activity Map uses only the latest 120 local event records returned by the authenticated PAUSE activity API.
- Host clusters are grouped by the hostname stored on an event. Edges connect a host cluster only to its own recorded event rows.
- Records without a stored hostname are displayed as standalone event nodes; PAUSE does not invent a host or infer a path.
- The map is not packet capture, a live network topology, an endpoint detector, or proof that one event caused another.

## What this build does

- Serves the control room and local API on `127.0.0.1` only.
- Uses a local sign-up/sign-in gate with salted PBKDF2-HMAC-SHA256 password hashes.
- Uses an in-memory UI session and a separate random browser-extension pairing token.
- Checks supported Chromium link clicks and form destinations using local URL heuristics.
- Replays approved anchor/form actions to preserve normal site handlers where possible.
- Attempts to pause Chrome/Edge downloads, checks source information, and presents decisions where the browser permits it.
- Inspects selected file metadata/signatures locally after download and computes SHA-256.
- Analyses user-pasted message text and optional Gmail API messages; raw message content is processed in memory and not retained in activity records.
- Provides an opt-in Gmail OAuth read-only flow. Refresh tokens are encrypted with Windows DPAPI.
- Offers a Quiet Mode ON/OFF preference for in-app priority alert presentation. OS/browser desktop notifications remain disabled.

## What it does not do

- It does not inspect every click/action, desktop app, network request or Windows event.
- It cannot guarantee pre-blocking direct address-bar navigation, all custom script navigation, or every download.
- It is not a full antivirus: no full archive extraction, macro inspection, sandboxing, exploit detection, quarantine or guaranteed malware verdict.
- It does not connect to Outlook/Hotmail, WhatsApp Business, or Teams in this build.
- It cannot read or intercept ordinary personal WhatsApp chats through an official consumer inbox API.
- It does not provide a live commercial threat-intelligence reputation feed.
- It does not capture keystrokes, secretly record screens or scrape private app sessions.

## SAFE does not mean guaranteed safe

SAFE means no configured indicator in the current local heuristic rules was detected. A malicious item can evade these rules; legitimate items can trigger warnings. Scores are severity indicators, not probabilities. If an integration is disconnected or cannot complete the check, PAUSE must present UNKNOWN / NOT CHECKED.

## Browser action handling

The extension checks supported anchor clicks and form submissions. On user approval, it replays the original DOM action instead of unconditionally forcing a tab URL update. This preserves ordinary SPA/router handling in many sites, but some sites may ignore synthetic events; users may need to retry with a fresh click. New-tab gestures are handled by opening the approved destination in a new tab. This is not a browser-level network firewall.

The downloads API reports lifecycle events after a download starts. PAUSE attempts to pause it immediately, but pause may fail for fast or externally managed downloads. If no pause is possible, the result is recorded as already started / not held; PAUSE does not automatically cancel a download based only on a later heuristic score. Browser-native Safe Browsing remains important.

## Notifications and Quiet Mode

- The extension does not request Chromium notification permission and does not call the desktop notification API.
- The desktop app does not create Windows/browser desktop pop-ups. Results remain in the in-app Alert Centre and Activity Log.
- **Quiet Mode ON** keeps priority results in the Alert Centre; only user actions that need a decision can interrupt with the compact browser decision card.
- **Quiet Mode OFF** displays a single inline in-app status update for each newly observed WARNING/HIGH RISK batch. SAFE remains silent.
- Changing Quiet Mode does not change scanning, rules or action protection. It only changes how new priority events are surfaced in the app.

## Link X-Ray, File DNA and Threat Story

- **Link X-Ray** compares URL-like visible link text with the actual parsed destination, lists common redirect query parameters and shows URL anatomy. It does not follow redirects, load the destination, or query a live domain-reputation provider.
- **File DNA** reads selected-file metadata and a bounded header, recognises a limited set of common signatures, checks selected extension mismatches and computes SHA-256. It does not execute files, upload them, unpack archives, inspect macros or retrieve hash reputation.
- **Threat Story** groups recorded events sharing a hostname. A timeline is evidence correlation only; it does not establish that events share a cause, actor or campaign. Unobserved steps are never inferred.


## Gmail OAuth and user data

- Scope requested: `gmail.readonly` only.
- OAuth flow: Desktop app client + PKCE + loopback callback.
- Token store: Windows DPAPI for the current Windows user; OAuth token storage is disabled off Windows.
- Monitoring: disabled by default; user must explicitly enable the 120-second poller.
- The poller examines up to 20 recent inbox messages from the last 2 days. It is not push-based.
- Message body, subject, full sender address and attachment contents are not written to event records. Hashed message IDs are stored to avoid repeat scans.
- Disconnect stops monitoring, attempts to revoke Google's grant and deletes the local token file.
- A public distribution using `gmail.readonly` must meet Google's restricted-scope verification and data-use requirements. Some deployments can additionally require a security assessment. The current build has not been through those approvals.

Use a dedicated test mailbox and sample data first. Do not connect a primary inbox until the product has undergone independent review and Google's requirements are met.

## Local API boundary and data at rest

The HTTP service binds to `127.0.0.1`. UI routes require an in-memory PAUSE session except for bootstrap/auth routes. Browser extension requests use a separate pairing token and specific CORS origin support. The local PAUSE account does not encrypt the SQLite database, settings or pairing-token file. Use a protected Windows account and device encryption. This development build still needs an independent security review, including API origin handling, session lifecycle, rate limiting, extension permission minimisation, update signing, Windows ACLs and build provenance.

## Reporting and release readiness

Do not rely on PAUSE as your only protection for financial, school, work or other sensitive accounts. Keep browser Safe Browsing and Microsoft Defender enabled. Before public distribution, conduct independent security review, Windows integration tests, OAuth approval, updater/signing work, privacy review and extensive adversarial/false-positive tests.


## PAUSE AI, voice and page context

- The local service sends a submitted question to Google Gemini. When Google Search is enabled, the request also uses Google's Search grounding and PAUSE displays returned URL citations. Current model ID: `gemini-3.8-flash`.
- PAUSE uses the documented Gemini `models.generateContent` REST endpoint. When Google Search grounding is enabled, the request includes the `google_search` tool and returned grounding source URLs are displayed as citations.
- The Gemini API key is read from the project-root `.env` file (or, as a fallback, the `GEMINI_API_KEY` process environment variable). The `.env` file is plain text on this development build, excluded by `.gitignore`, and never returned by status/config endpoints or sent to the extension. Keep it private, protect the Windows account and device, and never include a populated `.env` file in a shared ZIP or source-control commit.
- Questions, bounded recent chat context, and any page text the user explicitly attaches are sent to Google when the question is submitted. PAUSE does not store chat history or audio recordings. Review page context before attaching a sensitive page; external AI processing means this is not a local-only feature.
- The extension's **Use this page** action clones visible page content after removing forms, inputs, textareas, selects, buttons, editable regions, embedded frames and scripts. It is a best-effort privacy filter, not a guarantee that every site's visible copy is free of personal information. User-selected text is included when supplied by the browser selection API.
- Speech recognition is explicitly started by the user. The optional “PAUSE” wake phrase runs only while the extension side panel is open and enabled; the browser's speech service may process audio. This build does not contain a native, system-wide always-listening wake-word engine. Spoken replies use browser text-to-speech.
- Website opening is limited to explicit user-entered HTTP/HTTPS destinations or clicking returned source citations. Model output is not executed as a browser command.

## Windows device helpers

- Wi-Fi display shows SSID names and authentication labels returned by Windows for networks visible to the adapter. PAUSE does not reveal or store Wi-Fi passwords.
- Bluetooth display lists Windows-known Bluetooth devices that report status OK. It does not scan for nearby unpaired devices.
- Shutdown/restart/sleep/cancel are fixed allow-listed commands; the backend rejects them without `confirmed: true`. The UI separately asks for confirmation. Shutdown/restart schedule a 60-second countdown; sleep occurs after confirmation and can interrupt unsaved work.
- PAUSE AI cannot call device actions, run shell commands or execute arbitrary computer-control instructions. Device actions are separate UI controls and are never accepted as model-generated tool calls.
