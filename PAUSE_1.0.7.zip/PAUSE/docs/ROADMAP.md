# PAUSE — engineering roadmap

## 0.1 — Local browser prototype

- Desktop control center and local authenticated bridge.
- Transparent rule-based URL and email scanning.
- Pre-flight link/form checks in Chromium-based browsers.
- User-triggered Gmail open-message scan.
- Local SQLite activity history and user domain lists.

## 0.2 — Experience and account access (included)

- Redesigned rounded desktop interface, updated extension popup/options UI, and animated three-state product tour.
- Local sign-up/sign-in gate, salted password hashing, profile settings, password changes, sign-out, and account deletion.
- Local browser bridge starts after sign-in and stops on sign-out.

## 0.3 — Download Guard and safer action handling (included in this build)

- Pause supported browser downloads while checking the source URL; ask the user before resuming warnings or high-risk items.
- Expose pending download decisions in the extension popup.
- Inspect completed files inside the standard Downloads folder for SHA-256, filename deception, selected file-signature mismatches, and Chrome's danger state.
- Keep file inspection metadata-only: no execution, archive extraction, automatic deletion, or false antivirus verdicts. If the desktop bridge is offline, show an unchecked/unknown state without silently cancelling the download.
- Continue cross-browser validation for Chrome and Edge, including fast downloads, service-worker restarts, and disconnected local service cases.

## 0.4 — Authorised mail integrations and reputation

- Gmail API using user-consented OAuth scopes selected for least privilege; support message change notifications and read-only analysis first.
- Microsoft Graph using delegated Mail.Read permission and message change subscriptions for Outlook.com/Hotmail and supported Microsoft mailboxes.
- Optional reputation providers behind explicit opt-in, with provider attribution, data sent, retention, last-updated time, rate limits, and offline fallback visible to the user.
- OAuth client registrations, consent-screen configuration, provider verification and production callback infrastructure are release prerequisites—not settings we can invent inside the app.

## 0.5 — Windows notification integrations

- Investigate a packaged Windows component using the documented User Notification Listener capability with explicit permission.
- Analyse only notification text exposed by the operating system and selected by the user; do not scrape private app databases or silently capture screens/keystrokes.
- Clearly label this as notification-preview protection: it cannot stop a message being delivered or block the sender from sending it.
- Add app-specific opt-ins and a one-click revoke/disable control.

## 0.6 — Consent-based desktop integrations

- Explore documented Windows accessibility and browser integration APIs for a limited, consent-based set of additional action types.
- Do not attempt hidden global keylogging, indiscriminate screen capture, or covert inspection of private applications.
- Each integration should have a visible permission, narrow scope, clear off switch, and auditable local processing.

## 1.0 — Release readiness

- Security architecture review and independent testing.
- Signed installer and signed extension/update process.
- Crash recovery, service health monitoring, accessibility, and localization.
- Published privacy notice, threat model, limitations, and vulnerability reporting process.
