# PAUSE 1.0 — Product and Security Architecture

**Status:** Engineering plan, not a statement that all integrations are implemented.

## Product promise

PAUSE is a user-controlled digital safety assistant. It observes only supported events from integrations the user explicitly enables, explains the evidence behind each decision, and intervenes only where the platform provides a supported control point.

PAUSE must never imply that it sees the entire device, that a clean heuristic result proves safety, or that it can stop an email/message from being delivered when it only sees the message after delivery.

## Non-negotiable safety rules

1. **UNKNOWN is a real result.** An offline service, missing permission, unsupported content type, expired token, oversized file, or failed scan must never become SAFE.
2. **Explain every decision.** Record the signal, source, timestamp, integration, policy and action. Distinguish evidence from inference.
3. **Least privilege.** Request only the OAuth and OS permissions required for the chosen feature. Do not request send/delete/modify scopes for an alert-only first release.
4. **Local-first processing.** Do not upload email or message bodies by default. Optional reputation providers must disclose the exact data sent and be independently switchable.
5. **No covert monitoring.** No keylogging, hidden screen recording, private-app database scraping, or unofficial consumer messaging APIs.
6. **Human control.** Never silently delete a user's files, messages, emails, or accounts. Overrides must be explicit and logged locally.
7. **Defence in depth.** PAUSE supplements—not replaces—browser Safe Browsing, Microsoft Defender, OS updates, MFA, and safe user behaviour.

## Proposed architecture

```text
       Chrome / Edge extension           Provider notifications / webhooks
       - links and forms                 - Gmail API / Pub/Sub
       - download lifecycle              - Microsoft Graph
       - browser danger signals          - WhatsApp Business Cloud API
                    |                                  |
                    +------------------+---------------+
                                       |
                         Authenticated integration adapters
                                       |
                         PAUSE local policy / risk engine
                         - URL and redirect analysis
                         - sender / identity checks
                         - message-content indicators
                         - file metadata / signatures
                         - reputation evidence and freshness
                                       |
                         Policy decision and explanation
                    +------------------+----------------+
                    |                  |                |
                 ALLOW               WARN/HOLD         BLOCK
                    |                  |                |
                    +------------------+----------------+
                                       |
                         Local event store and UI
                         - activity history
                         - threat investigation
                         - provider permissions
                         - retention and privacy controls
```

The local API must remain loopback-only, require per-installation pairing credentials, validate request sizes and schemas, rate-limit callers, and avoid permissive cross-origin access in a production build. Secrets should move from ordinary files into Windows Credential Manager / DPAPI-backed storage before public release. Database encryption and secure update/signing are release gates.

## Risk model

Do not treat a score as a mathematical probability. Each result should carry:

- `severity`: SAFE / WARNING / HIGH RISK / UNKNOWN;
- `confidence`: low / medium / high, based on evidence quality;
- `signals[]`: machine-readable indicator, source, timestamp and explanation;
- `action`: allow / warn / hold / block / needs-user-review;
- `coverage`: which checks ran and which did not;
- `provider_evidence`: provider name, response and freshness where applicable.

The user interface may present three primary signal colours—green, yellow and red—but UNKNOWN must be visible as an unverified/grey state or a yellow warning, never green.

## Integration contracts

### Browser Shield

- Inspect supported link clicks and form destinations before navigation where the content-script integration can intercept them.
- Inspect direct address-bar navigation after it begins; do not claim it is pre-blocked.
- Explain redirects, domain look-alikes, HTTPS/certificate context, and reputation evidence. A certificate only establishes a connection identity under its trust model; it does not establish that a site is honest.
- Use extension permissions narrowly and show users why broad page access is required.

### Download Guard

**Implemented in 0.3.0:**

1. On a supported Chrome/Edge download event, attempt to pause it immediately.
2. Check its source URL through the local PAUSE policy engine.
3. Resume a result configured to allow; keep WARNING/HIGH RISK downloads paused for a visible user decision.
4. Keep pending decisions available in the extension popup if a browser notification is dismissed.
5. After completion, inspect files only within the standard Downloads folder: SHA-256, selected filename deception patterns, selected file-header mismatches, and the browser's danger field.

**Still required for a stronger release:** native quarantine/staging, robust file-open brokering, archive and document-content scanning, reputation lookups, and integration with Windows Defender with a trustworthy result channel. Browser download events occur after the download starts and are not a universal interception point. PAUSE cannot guarantee another app will not open a completed file. Keep browser Safe Browsing and Defender enabled.

### Gmail

- Use the official Gmail API with the smallest scope that supports the chosen feature.
- Start with read-only message analysis. Never request send/delete/modify permissions merely to show a warning.
- New-message monitoring can be implemented with Gmail watch / Pub/Sub; this requires provider setup and a reliable webhook backend.
- Google classifies scopes by sensitivity; production use of sensitive/restricted scopes can require OAuth verification, and restricted-scope server storage/transmission may require a security assessment. The release team must complete the applicable Google verification before public distribution.
- Do not retain raw message bodies. Store only the minimum evidence summary unless a user explicitly asks to retain a specific item.

### Outlook and Hotmail

- Use Microsoft Graph delegated access for the signed-in user's own mailbox, starting with the least-privileged read permission such as `Mail.Read` where required for content inspection.
- Use message change subscriptions/webhooks for near-real-time notice of new mail; this needs an HTTPS endpoint and subscription renewal/expiry handling.
- Begin alert-only and read-only. Moving, deleting, or rewriting email is out of initial scope.
- Handle personal Microsoft accounts and work/school accounts as separate test cases because permission and tenant policies can differ.

### WhatsApp and messages

- **Personal WhatsApp:** do not scrape WhatsApp's private local databases or depend on reverse-engineered APIs. A Windows packaged notification-listener component may read only notification previews that Windows exposes after the user explicitly grants notification access. It can analyse a preview and display a PAUSE warning after notification arrival. It cannot stop delivery, pause the sender, or guarantee that the full message is present.
- **WhatsApp Business:** provide a separate, optional adapter for Meta's WhatsApp Business Platform Cloud API using authenticated webhooks. This is for a registered business messaging account, not a person's normal consumer inbox.
- **Windows Phone Link / other messaging apps:** a future notification adapter may analyse app notifications where Windows exposes them and the user opts in. The app must identify the source application and allow per-app disabling.

### Windows system integrations

Add Windows notification listening and any future file/network/system integration through a packaged native component with explicit OS capability declarations and user permission. A plain Tkinter process cannot assume it can access all notifications or every application's private content.

## Dashboard design map

Each workspace gets a different information layout, not the same generic card grid:

| Workspace | Main visual | Primary actions |
|---|---|---|
| Overview | Protection posture, trend charts, recent alerts | Pause protection, inspect alert |
| Live Protection | Streaming event timeline and status lanes | Stop/allow/review supported action |
| Threat Centre | Evidence graph linking sender, domain, URL and file hash | Investigate, export redacted report |
| Browser Shield | Domain/reputation panels, redirect path, permission map | Trusted/block rules |
| Mail Shield | Message queue, sender identity, link/attachment analysis | Mark reviewed, report false positive |
| File Shield | Download queue, scan stages, file fingerprints | Hold, release, open location |
| Messages | Notification inbox grouped by app and risk | Review, mute integration |
| Network Monitor | Process-to-destination activity chart and flow table | Inspect connection evidence; no covert packet capture |
| Rules Studio | Visual policy builder and rule simulator | Test, enable, roll back rule |
| Privacy Centre | Permission matrix, data-flow map, retention controls | Revoke, delete local history |
| Account & Devices | Local account, connected providers, session state | Sign out, disconnect provider |

The visual system should use the PAUSE identity—warm white, graphite, cool grey and signal red—with a real light/dark theme. Use graphs only where they answer a question. Every chart must be sourced from actual local event data, label the time range and provide an accessible table alternative.

## Release gates for a public 1.0

- Provider OAuth apps registered; consent scopes reviewed; required Google/Microsoft verification completed.
- WhatsApp Business onboarding (if included) approved and correctly scoped.
- Windows notification component packaged and permission-tested.
- Signed Windows installer, signed extension package and secure update channel.
- Threat model, dependency audit, static analysis, unit/integration/E2E tests and external security review.
- Privacy notice, data retention policy, incident response and vulnerability reporting.
- False-positive / missed-threat reporting with reproducible test cases.
- Performance testing on low-end Windows devices and accessibility testing.
- No feature marketed as universal, real-time, or guaranteed unless it has been independently verified across its declared coverage.

## Verified platform references

- Gmail API scopes: <https://developers.google.com/workspace/gmail/api/auth/scopes>
- Gmail messages list: <https://developers.google.com/workspace/gmail/api/reference/rest/v1/users.messages/list>
- Gmail watch: <https://developers.google.com/workspace/gmail/api/reference/rest/v1/users/watch>
- Microsoft Graph Outlook change notifications: <https://learn.microsoft.com/en-us/graph/outlook-change-notifications-overview>
- Chrome downloads API: <https://developer.chrome.com/docs/extensions/reference/api/downloads>
- Windows notification listener: <https://learn.microsoft.com/en-us/windows/apps/develop/notifications/app-notifications/notification-listener>
- WhatsApp Business Platform webhooks: <https://developers.facebook.com/documentation/business-messaging/whatsapp/webhooks/overview>
