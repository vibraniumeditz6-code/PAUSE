# PAUSE Midnight UI previews

- `overview-light-0.5.png` shows the current v0.5.0 light-mode dashboard with mock QA records.
- `live-demo-0.5.png` shows the three-state SAFE / WARNING / HIGH RISK demonstration with fictional sample messages.
- `account.png`, `connections.png`, and `message-shield.png` are earlier v0.4 design captures; the live application is authoritative for current layout.

All sample names, counts, messages, and events in these preview images are fictional QA data. They are not real user activity or proof of live provider connections.
