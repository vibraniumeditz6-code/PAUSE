const API = "http://127.0.0.1:8765";
const tokenEl = document.getElementById("token");
const statusEl = document.getElementById("status");
chrome.storage.local.get(["pairingToken"], (data) => { tokenEl.value = data.pairingToken || ""; });
document.getElementById("save").addEventListener("click", () => {
  chrome.storage.local.set({ pairingToken: tokenEl.value.trim() }, () => {
    statusEl.textContent = "Token saved in this browser profile.";
    statusEl.style.color = "#168653";
  });
});
document.getElementById("test").addEventListener("click", async () => {
  const token = tokenEl.value.trim();
  if (!token) { statusEl.textContent = "Paste the token first."; statusEl.style.color = "#d9363e"; return; }
  statusEl.textContent = "Testing local connection…";
  try {
    const response = await fetch(`${API}/api/status`, { headers: { "X-PAUSE-Token": token } });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || `HTTP ${response.status}`);
    chrome.storage.local.set({ pairingToken: token });
    statusEl.textContent = `Connected to PAUSE Guard ${data.version}. Protection ${data.protection_enabled ? "ON" : "OFF"}.`;
    statusEl.style.color = "#168653";
  } catch (error) {
    statusEl.textContent = error.message || "Connection failed. Check that the desktop app is open.";
    statusEl.style.color = "#d9363e";
  }
});
