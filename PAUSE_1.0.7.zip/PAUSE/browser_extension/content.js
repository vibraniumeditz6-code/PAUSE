(() => {
  if (window.__pauseGuardLoaded) return;
  window.__pauseGuardLoaded = true;

  let busy = false;
  let gmailButtonAdded = false;
  let guardSettings = { scan_links: true, scan_forms: true, scan_page_navigation: true, show_safe_notices: false, gmail_scan_enabled: false };
  messageBackground({ type: "PAUSE_GET_SETTINGS" }).then((response) => {
    if (response?.ok && response.settings) guardSettings = response.settings;
  });

  function messageBackground(message) {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage(message, (response) => {
          const err = chrome.runtime.lastError;
          if (err) resolve({ ok: false, error: err.message });
          else resolve(response || { ok: false, error: "No response from PAUSE." });
        });
      } catch (error) {
        resolve({ ok: false, error: error.message });
      }
    });
  }

  function cleanText(value, max = 6000) {
    return String(value || "").replace(/\s+/g, " ").trim().slice(0, max);
  }

  // PAUSE AI can request visible page context only after the user presses
  // "Use this page" in the extension side panel. Clone and remove forms,
  // editable fields, buttons and embedded scripts before extracting text.
  // The text is sent to Gemini only with the user's next submitted question.
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message?.type !== "PAUSE_CAPTURE_PAGE_CONTEXT") return;
    const selection = window.getSelection ? String(window.getSelection()) : "";
    const title = String(document.title || "").slice(0, 240);
    const url = String(location.href || "").slice(0, 1000);
    const clone = document.body?.cloneNode(true);
    clone?.querySelectorAll("form,input,textarea,select,option,button,[contenteditable],[role='textbox'],[data-private],iframe,script,style,noscript").forEach((node) => node.remove());
    const text = cleanText(clone?.innerText || "", 9000);
    sendResponse({ title, url, selection: cleanText(selection, 1200), text });
  });

  // Passive checks never create floating notices. Scan outcomes are recorded in
  // PAUSE Activity; only an intercepted user action that needs a decision gets
  // the compact white decision card below.
  function showToast() { /* intentionally quiet */ }

  // A compact decision card replaces the old dimmed, full-screen modal.
  // The page remains usable; only the action being inspected is held.
  function showDecision(result, onContinue, onStop, mode = "decision") {
    const old = document.getElementById("pause-guard-decision");
    if (old) old.remove();
    const high = result.level === "HIGH RISK";
    const passive = mode === "page-loaded";
    const messageResult = mode === "message-result";
    const color = high ? "#c74359" : result.level === "SAFE" ? "#16845f" : "#b27a22";
    const panel = document.createElement("section");
    panel.id = "pause-guard-decision";
    panel.setAttribute("role", "alertdialog");
    panel.setAttribute("aria-live", "assertive");
    panel.style.cssText = `position:fixed;z-index:2147483647;top:16px;right:16px;width:min(410px,calc(100vw - 32px));max-height:calc(100vh - 32px);overflow:auto;box-sizing:border-box;background:#fff;color:#24354b;border:1px solid #e1e8f0;border-left:4px solid ${color};border-radius:16px;box-shadow:0 18px 55px rgba(25,45,70,.20),0 3px 10px rgba(25,45,70,.07);padding:18px;font:13px/1.5 Segoe UI,Arial,sans-serif;`;

    const badge = document.createElement("div");
    badge.textContent = passive ? "PAGE CHECK · REVIEW" : messageResult ? `${result.level || "UNKNOWN"} · MESSAGE CHECK` : (high ? "HIGH RISK · ACTION HELD" : "WARNING · REVIEW BEFORE CONTINUING");
    badge.style.cssText = `font-size:10px;letter-spacing:.075em;font-weight:850;color:${color};margin-bottom:8px;`;
    const title = document.createElement("div");
    title.textContent = passive ? "This page is already open." : messageResult ? "Message inspection complete." : (high ? "PAUSE held this navigation." : "This destination needs a closer look.");
    title.style.cssText = "font-size:18px;letter-spacing:-.025em;font-weight:780;margin-bottom:7px;color:#1d2d42;";
    const target = document.createElement("div");
    target.textContent = result.host || result.target || "Unknown destination";
    target.style.cssText = "font-size:12px;font-weight:750;overflow-wrap:anywhere;margin-bottom:7px;color:#40536b;";
    const summary = document.createElement("div");
    summary.textContent = passive
      ? "This page finished loading before PAUSE could inspect it. Review the signals below; this was not a pre-navigation block."
      : (result.summary || (messageResult ? "PAUSE completed a local message check." : "PAUSE found signals that deserve attention."));
    summary.style.cssText = "font-size:12px;color:#68788c;margin-bottom:12px;";
    const listTitle = document.createElement("div");
    listTitle.textContent = `${result.level === "SAFE" ? "CHECKS COMPLETED" : "WHY IT WAS FLAGGED"} · ${Number(result.score || 0)}/100`;
    listTitle.style.cssText = "font-size:9px;font-weight:850;letter-spacing:.08em;color:#8794a6;margin-bottom:5px;";
    const list = document.createElement("ul");
    list.style.cssText = "padding-left:18px;margin:0 0 12px;color:#53647a;font-size:11px;";
    (result.reasons || []).slice(0, 4).forEach((reason) => {
      const li = document.createElement("li");
      li.textContent = reason;
      li.style.marginBottom = "4px";
      list.appendChild(li);
    });
    const xray = document.createElement("div");
    if (result.xray) {
      const match = result.xray.visible_destination_match === false ? "VISIBLE TEXT DOES NOT MATCH THE DESTINATION" : "LINK STRUCTURE CHECKED";
      xray.textContent = `${match} · ${result.xray.scheme || "unknown"}://${result.xray.destination_host || result.host}${(result.xray.redirect_candidates || []).length ? " · redirect parameter found" : ""}`;
      xray.style.cssText = "font-size:10px;color:#47627b;background:#f4f8fb;border:1px solid #dce9ef;border-radius:9px;padding:9px 10px;margin:-2px 0 12px;overflow-wrap:anywhere;";
    }
    const note = document.createElement("div");
    note.textContent = "PAUSE uses local indicators, not a definitive verdict. SAFE is not a guarantee.";
    note.style.cssText = "font-size:10px;color:#7b8999;background:#f5f7fa;border:1px solid #e9edf2;border-radius:9px;padding:9px 10px;margin-bottom:13px;";
    const actions = document.createElement("div");
    actions.style.cssText = "display:flex;gap:8px;flex-wrap:wrap;justify-content:flex-end;align-items:center;";
    const stop = document.createElement("button");
    stop.textContent = passive ? "Go back" : "Stop action";
    stop.style.cssText = "border:1px solid #dfe5ec;border-radius:9px;background:#f7f9fb;color:#35465b;padding:9px 12px;font-weight:700;cursor:pointer;";
    stop.addEventListener("click", () => { panel.remove(); onStop?.(); });
    if (passive || messageResult) {
      const dismiss = document.createElement("button");
      dismiss.textContent = messageResult ? "Close" : "Dismiss";
      dismiss.style.cssText = "border:0;border-radius:9px;background:#fff;color:#6b7a8d;padding:9px 12px;font-weight:650;cursor:pointer;";
      dismiss.addEventListener("click", () => panel.remove());
      if (messageResult) {
        actions.append(dismiss);
      } else {
        const back = stop;
        back.textContent = "Go back";
        actions.append(dismiss, back);
      }
      /* passive and informational cards have no override action */
    } else {
      const continueBtn = document.createElement("button");
      continueBtn.textContent = "Continue anyway";
      continueBtn.style.cssText = `border:1px solid ${high ? "#e7b8c0" : "#ead6b3"};border-radius:9px;background:#fff;color:${high ? "#a53549" : "#94651b"};padding:9px 12px;font-weight:750;cursor:pointer;`;
      if (high) {
        const reveal = document.createElement("button");
        reveal.textContent = "Advanced";
        reveal.style.cssText = "border:0;background:transparent;color:#6b79a1;padding:8px;cursor:pointer;font-size:11px;font-weight:700;";
        continueBtn.style.display = "none";
        reveal.addEventListener("click", () => {
          continueBtn.style.display = "inline-block";
          reveal.textContent = "Override available";
        });
        actions.append(reveal, continueBtn, stop);
      } else {
        actions.append(continueBtn, stop);
      }
      continueBtn.addEventListener("click", () => { panel.remove(); onContinue?.(); });
    }
    panel.append(badge, title, target, summary, listTitle, list, ...(result.xray ? [xray] : []), note, actions);
    document.documentElement.appendChild(panel);
  }

  async function scanUrl(url, kind = "url", displayText = "") {
    return messageBackground({ type: "PAUSE_SCAN", payload: { type: kind, url, display_text: cleanText(displayText, 180) } });
  }

  function openApproved(url, newTab) {
    return messageBackground({ type: "PAUSE_CONTINUE", url, newTab });
  }

  function continueApprovedLink(link, url, newTab) {
    if (newTab) return openApproved(url, true);
    if (link && link.isConnected && link.href === url) {
      // Replay the original anchor activation exactly once. This lets client
      // routers and in-page handlers handle the approved click naturally.
      link.dataset.pauseApprovedOnce = "1";
      link.click();
      if (link.dataset.pauseApprovedOnce === "1") delete link.dataset.pauseApprovedOnce;
      return Promise.resolve({ ok: true, replayed: true });
    }
    return openApproved(url, false);
  }

  async function handleLink(event, link) {
    // A user-approved replay is allowed through so the site's own SPA/router
    // click handlers can run and the page does not get force-reloaded.
    if (link.dataset.pauseApprovedOnce === "1") {
      delete link.dataset.pauseApprovedOnce;
      return;
    }
    if (busy) {
      event.preventDefault();
      event.stopImmediatePropagation();
      return;
    }
    const url = link.href;
    if (!/^https?:/i.test(url)) return;
    if (link.hasAttribute("download")) return;
    // Respect native new-tab gestures while still pre-checking the destination.
    const newTab = link.target === "_blank" || event.ctrlKey || event.metaKey || event.button === 1;
    event.preventDefault();
    event.stopImmediatePropagation();
    busy = true;
    const response = await scanUrl(url, "url", link.getAttribute("aria-label") || link.innerText || link.textContent || "");
    busy = false;
    if (!response?.ok) {
      showDecision({ level: "WARNING", score: 0, host: new URL(url).hostname,
        summary: "PAUSE could not complete this check. No risk verdict is available.",
        reasons: [response?.error || "The local service is unavailable. Stop the action or reconnect PAUSE before retrying."] },
        () => continueApprovedLink(link, url, newTab), () => {});
      return;
    }
    const result = response.result;
    if (result.action === "allow" || result.level === "SAFE" || result.level === "PAUSED") {
      // SAFE checks are recorded in the PAUSE Activity Centre; they do not
      // create page pop-ups or system notifications.
      continueApprovedLink(link, url, newTab);
      return;
    }
    const displayResult = result.action === "warn" && result.level === "HIGH RISK" ? { ...result, level: "WARNING" } : result;
    showDecision(displayResult, () => continueApprovedLink(link, url, newTab), () => {});
  }

  const handleDocumentClick = (event) => {
    if (!guardSettings.scan_links) return;
    if (event.defaultPrevented || (event.button !== 0 && event.button !== 1)) return;
    const link = event.target?.closest?.("a[href]");
    if (!link) return;
    handleLink(event, link);
  };
  document.addEventListener("click", handleDocumentClick, true);
  document.addEventListener("auxclick", handleDocumentClick, true);

  function continueApprovedForm(form) {
    if (!form || !form.isConnected) return;
    form.dataset.pauseApprovedOnce = "1";
    if (typeof form.requestSubmit === "function") form.requestSubmit();
    else HTMLFormElement.prototype.submit.call(form);
  }

  document.addEventListener("submit", async (event) => {
    if (!guardSettings.scan_forms) return;
    const form = event.target;
    if (!(form instanceof HTMLFormElement)) return;
    if (form.dataset.pauseApprovedOnce === "1") {
      delete form.dataset.pauseApprovedOnce;
      return;
    }
    if (busy) {
      event.preventDefault();
      event.stopImmediatePropagation();
      return;
    }
    const destination = form.action || location.href;
    if (!/^https?:/i.test(destination)) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    busy = true;
    const response = await scanUrl(destination, "form");
    busy = false;
    if (!response?.ok) {
      showDecision({ level: "WARNING", score: 0, host: new URL(destination).hostname,
        summary: "PAUSE could not complete this check. No risk verdict is available.", reasons: [response?.error || "Form destination could not be checked. Reconnect PAUSE before retrying."] },
        () => continueApprovedForm(form), () => {});
      return;
    }
    const result = response.result;
    const proceed = () => continueApprovedForm(form);
    if (result.action === "allow" || result.level === "SAFE" || result.level === "PAUSED") {
      // Routine SAFE form checks stay quiet and appear in the Activity Centre.
      proceed();
    } else {
      const displayResult = result.action === "warn" && result.level === "HIGH RISK" ? { ...result, level: "WARNING" } : result;
      showDecision(displayResult, proceed, () => {});
    }
  }, true);

  // A page reached via the address bar or an external redirect is analysed after it loads.
  // Link clicks above are checked before navigation; direct navigation cannot be reliably
  // cancelled at the browser network layer by a normal content script.
  async function checkLoadedPage() {
    if (!/^https?:$/.test(location.protocol)) return;
    const settingResponse = await messageBackground({ type: "PAUSE_GET_SETTINGS" });
    if (!settingResponse?.ok || !settingResponse.settings?.scan_page_navigation) return;
    const response = await scanUrl(location.href, "page navigation");
    if (!response?.ok) return;
    const result = response.result;
    // Passive checks happen after the page has loaded. They are recorded in
    // Activity only; never cover the page with a card after navigation completed.
  }
  if (document.readyState === "complete") window.setTimeout(checkLoadedPage, 250);
  else window.addEventListener("load", checkLoadedPage, { once: true });

  async function addGmailButton() {
    if (location.hostname !== "mail.google.com" || gmailButtonAdded) return;
    const settingResponse = await messageBackground({ type: "PAUSE_GET_SETTINGS" });
    if (!settingResponse?.ok || !settingResponse.settings?.gmail_scan_enabled) return;
    gmailButtonAdded = true;
    const button = document.createElement("button");
    button.textContent = "PAUSE  •  Scan this email";
    button.id = "pause-gmail-scan-button";
    button.style.cssText = "position:fixed;right:22px;bottom:22px;z-index:2147483000;background:linear-gradient(100deg,#5ce1d4,#79b7ff 60%,#9d84ff);color:#081321;border:1px solid rgba(255,255,255,.22);border-radius:999px;padding:13px 18px;font:900 11px Segoe UI,Arial;letter-spacing:.04em;box-shadow:0 13px 35px rgba(0,0,0,.35),0 0 28px rgba(92,225,212,.15);cursor:pointer;";
    button.addEventListener("click", async () => {
      const bodyNode = document.querySelector(".a3s.aiL") || document.querySelector("[data-message-id] .a3s") || document.querySelector("[role='main'] .a3s");
      if (!bodyNode) {
        button.textContent = "Open an email first";
        button.title = "Open one Gmail message. PAUSE scans only the message you explicitly select.";
        return;
      }
      button.disabled = true;
      button.textContent = "PAUSE  •  Scanning…";
      const senderNode = document.querySelector("[email]");
      const sender = senderNode?.getAttribute("email") || "";
      const senderName = senderNode?.textContent || "";
      const subject = document.querySelector("h2.hP")?.textContent || document.title || "";
      const attachments = [...document.querySelectorAll(".aQw .aZo, .aQy .aV3")].map((el) => cleanText(el.textContent, 100));
      const payload = { type: "email", sender, sender_name: senderName, subject,
        body: cleanText(bodyNode.innerText, 60000), attachments, source: "Gmail open-message scan" };
      const response = await messageBackground({ type: "PAUSE_SCAN", payload });
      button.disabled = false;
      button.textContent = "PAUSE  •  Scan this email";
      if (!response?.ok) {
        button.textContent = "PAUSE unavailable";
        button.title = response?.error || "Could not reach the PAUSE desktop app.";
        return;
      }
      const result = response.result;
      showDecision(result, null, null, "message-result");
    });
    document.documentElement.appendChild(button);
  }

  if (location.hostname === "mail.google.com") {
    addGmailButton();
    const observer = new MutationObserver(() => {
      if (!document.getElementById("pause-gmail-scan-button")) {
        gmailButtonAdded = false;
        addGmailButton();
      }
    });
    observer.observe(document.documentElement, { childList: true, subtree: true });
  }
})();
