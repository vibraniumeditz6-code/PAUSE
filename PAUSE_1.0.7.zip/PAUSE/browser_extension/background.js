const API = "http://127.0.0.1:8765";
const downloadChecksInFlight = new Set();
const fileChecksInFlight = new Set();
const completedDownloadChecks = new Set();
const COMPLETED_DOWNLOADS_KEY = "pauseCompletedFileChecks";

async function readConfig() {
  const data = await chrome.storage.local.get(["pairingToken"]);
  return { token: data.pairingToken || "" };
}

async function apiRequest(path, options = {}) {
  const { token } = await readConfig();
  if (!token) throw new Error("Not paired. Open PAUSE extension settings and add your desktop pairing token.");
  const response = await fetch(`${API}${path}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      "X-PAUSE-Token": token,
      ...(options.headers || {})
    }
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || `PAUSE local service returned ${response.status}`);
  return data;
}

async function scan(payload) {
  return apiRequest("/api/scan", { method: "POST", body: JSON.stringify(payload) });
}

// PAUSE intentionally does not create operating-system notifications. Results are
// shown in the in-app Alert Centre; held downloads use the toolbar badge and popup.

async function updatePendingBadge() {
  try {
    const pending = await readPendingDownloads();
    const count = Object.keys(pending).length;
    await chrome.action.setBadgeText({ text: count ? (count > 99 ? "99+" : String(count)) : "" });
    await chrome.action.setBadgeBackgroundColor({ color: count ? "#bd465d" : "#168a80" });
    await chrome.action.setTitle({ title: count ? `PAUSE · ${count} download decision(s) waiting` : "PAUSE AI & Browser Shield" });
  } catch (_) {}
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  (async () => {
    try {
      if (message?.type === "PAUSE_PING") {
        const status = await apiRequest("/api/status");
        sendResponse({ ok: true, status });
        return;
      }
      if (message?.type === "PAUSE_GET_SETTINGS") {
        const data = await apiRequest("/api/settings");
        sendResponse({ ok: true, settings: data.settings });
        return;
      }
      if (message?.type === "PAUSE_SCAN") {
        const result = await scan({ ...message.payload, source: "browser extension" });
        sendResponse({ ok: true, result });
        return;
      }
      if (message?.type === "PAUSE_PENDING_DOWNLOADS") {
        sendResponse({ ok: true, pending: await readPendingDownloads() });
        return;
      }
      if (message?.type === "PAUSE_DOWNLOAD_DECISION") {
        await decidePendingDownload(Number(message.downloadId), Boolean(message.resume));
        sendResponse({ ok: true });
        return;
      }
      if (message?.type === "PAUSE_CONTINUE") {
        const url = String(message.url || "");
        if (!/^https?:\/\//i.test(url)) throw new Error("Only web links can be opened by PAUSE.");
        const newTab = Boolean(message.newTab);
        if (newTab) {
          await chrome.tabs.create({ url, active: true });
        } else if (sender.tab?.id !== undefined) {
          await chrome.tabs.update(sender.tab.id, { url });
        }
        sendResponse({ ok: true });
        return;
      }
      if (message?.type === "PAUSE_OPEN_OPTIONS") {
        await chrome.runtime.openOptionsPage();
        sendResponse({ ok: true });
        return;
      }
      if (message?.type === "PAUSE_OPEN_AI") {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (!chrome.sidePanel?.open || !tab?.windowId) throw new Error("PAUSE AI needs a recent Chrome/Edge version with the Side Panel API.");
        await chrome.sidePanel.open({ windowId: tab.windowId });
        sendResponse({ ok: true });
        return;
      }
      if (message?.type === "PAUSE_AI_STATUS") {
        sendResponse({ ok: true, data: await apiRequest("/api/assistant/status") });
        return;
      }
      if (message?.type === "PAUSE_AI_CHAT") {
        sendResponse({ ok: true, data: await apiRequest("/api/assistant/chat", {
          method: "POST", body: JSON.stringify(message.payload || {})
        }) });
        return;
      }
      if (message?.type === "PAUSE_GET_PAGE_CONTEXT") {
        const tabId = Number(message.tabId);
        if (!Number.isInteger(tabId)) throw new Error("No active browser tab is available.");
        const context = await chrome.tabs.sendMessage(tabId, { type: "PAUSE_CAPTURE_PAGE_CONTEXT" });
        sendResponse({ ok: true, context });
        return;
      }
      if (message?.type === "PAUSE_DEVICE_SNAPSHOT") {
        sendResponse({ ok: true, data: await apiRequest("/api/device/snapshot") });
        return;
      }
      if (message?.type === "PAUSE_DEVICE_ACTION") {
        const data = await apiRequest("/api/device/action", {
          method: "POST", body: JSON.stringify({ action: message.action, confirmed: message.confirmed === true })
        });
        sendResponse({ ok: true, data });
        return;
      }
      if (message?.type === "PAUSE_OPEN_URL") {
        const url = String(message.url || "");
        if (!/^https?:\/\//i.test(url)) throw new Error("PAUSE can open only HTTP or HTTPS websites.");
        await chrome.tabs.create({ url, active: true });
        sendResponse({ ok: true });
        return;
      }
      sendResponse({ ok: false, error: "Unknown PAUSE request." });
    } catch (error) {
      sendResponse({ ok: false, error: error.message || "PAUSE request failed." });
    }
  })();
  return true;
});


// DOWNLOAD GUARD -------------------------------------------------------------
// The browser downloads API reports a download after it starts. PAUSE attempts
// to pause it immediately, checks the source URL, and asks the user before
// resuming warnings. This is not a guarantee against every download path.
const PENDING_DOWNLOADS_KEY = "pausePendingDownloads";
const HIGH_DANGER_STATES = new Set(["content", "url", "host"]);
const WARNING_DANGER_STATES = new Set(["file", "uncommon", "unwanted", "passwordProtected", "blockedTooLarge"]);

async function readPendingDownloads() {
  const data = await chrome.storage.local.get([PENDING_DOWNLOADS_KEY]);
  return data[PENDING_DOWNLOADS_KEY] || {};
}

async function writePendingDownload(downloadId, value) {
  const pending = await readPendingDownloads();
  pending[String(downloadId)] = value;
  await chrome.storage.local.set({ [PENDING_DOWNLOADS_KEY]: pending });
  await updatePendingBadge();
}

async function clearPendingDownload(downloadId) {
  const pending = await readPendingDownloads();
  delete pending[String(downloadId)];
  await chrome.storage.local.set({ [PENDING_DOWNLOADS_KEY]: pending });
  await updatePendingBadge();
}

async function decidePendingDownload(downloadId, resume) {
  if (!Number.isInteger(downloadId)) throw new Error("Invalid download id.");
  const pending = await readPendingDownloads();
  const record = pending[String(downloadId)];
  if (!record) throw new Error("This download no longer has a pending PAUSE decision.");
  if (resume) {
    if (record.paused !== false && !record.cancelled) await chrome.downloads.resume(downloadId);
  } else {
    await chrome.downloads.cancel(downloadId);
  }
  await clearPendingDownload(downloadId);
}

async function loadProtectionSettings() {
  const response = await apiRequest("/api/settings");
  if (!response || !response.settings) throw new Error("PAUSE settings are unavailable.");
  return response.settings;
}

async function onDownloadCreated(item) {
  const id = Number(item.id);
  if (!Number.isInteger(id) || downloadChecksInFlight.has(id)) return;
  downloadChecksInFlight.add(id);
  let paused = false;
  try {
    const settings = await loadProtectionSettings();
    if (!settings.protection_enabled || settings.scan_downloads === false) return;

    // Pause is best-effort. A fast download must not be cancelled merely
    // because Chrome did not leave enough time for PAUSE to pause it.
    try {
      await chrome.downloads.pause(id);
      paused = true;
    } catch (_) {}

    const url = item.finalUrl || item.url || "";
    const response = await scan({ type: "download source", url });
    if (!response?.level) throw new Error("PAUSE returned no risk decision.");

    let level = response.level;
    let action = response.action;
    const danger = String(item.danger || "");
    if (HIGH_DANGER_STATES.has(danger)) {
      level = "HIGH RISK";
      action = "block";
      response.reasons = [...(response.reasons || []), `Chrome download protection classified the item as '${danger}'.`];
    } else if (WARNING_DANGER_STATES.has(danger) && level === "SAFE") {
      level = "WARNING";
      action = "warn";
      response.reasons = [...(response.reasons || []), `Chrome download protection classified the item as '${danger}'.`];
    }

    if (action === "allow" || level === "SAFE" || level === "PAUSED") {
      if (paused) await chrome.downloads.resume(id);
      return; // SAFE checks are intentionally silent.
    }

    const isHigh = level === "HIGH RISK";
    if (paused) {
      await writePendingDownload(id, {
        level, target: response.host || url, createdAt: Date.now(), paused: true,
        reasons: (response.reasons || []).slice(0, 3)
      });
      return;
    }

    // If the download moved too quickly to pause, do not auto-cancel it based
    // on a heuristic result. Record the verdict for review; the user can cancel
    // it explicitly from the extension popup.
    await writePendingDownload(id, {
      level, target: response.host || url, createdAt: Date.now(), paused: false,
      status: "already_started",
      reasons: (response.reasons || []).slice(0, 3)
    });
  } catch (error) {
    const url = item.finalUrl || item.url || "";
    let target = url;
    try { target = new URL(url).hostname; } catch (_) {}
    await writePendingDownload(id, {
      level: "UNKNOWN", target, createdAt: Date.now(), paused,
      status: paused ? "paused_check_unavailable" : "not_checked",
      detail: String(error.message || "PAUSE could not complete the check.").slice(0, 220)
    });
    // No system pop-up. The extension badge and Downloads on hold area carry
    // the state without interrupting the user.
  } finally {
    downloadChecksInFlight.delete(id);
  }
}

chrome.downloads.onCreated.addListener((item) => {
  void onDownloadCreated(item);
});

async function wasFileCheckRecorded(downloadId, filename) {
  const data = await chrome.storage.local.get([COMPLETED_DOWNLOADS_KEY]);
  const completed = Array.isArray(data[COMPLETED_DOWNLOADS_KEY]) ? data[COMPLETED_DOWNLOADS_KEY] : [];
  return completed.includes(`${downloadId}:${filename}`);
}

async function recordFileCheck(downloadId, filename) {
  const data = await chrome.storage.local.get([COMPLETED_DOWNLOADS_KEY]);
  const completed = Array.isArray(data[COMPLETED_DOWNLOADS_KEY]) ? data[COMPLETED_DOWNLOADS_KEY] : [];
  const key = `${downloadId}:${filename}`;
  const next = [...completed.filter((entry) => entry !== key), key].slice(-500);
  await chrome.storage.local.set({ [COMPLETED_DOWNLOADS_KEY]: next });
  completedDownloadChecks.add(downloadId);
}

async function inspectCompletedDownload(downloadId) {
  if (fileChecksInFlight.has(downloadId) || completedDownloadChecks.has(downloadId)) return;
  fileChecksInFlight.add(downloadId);
  try {
    const items = await chrome.downloads.search({ id: downloadId });
    const item = items && items[0];
    if (!item || item.state !== "complete" || !item.filename) return;
    const settings = await loadProtectionSettings();
    if (settings.scan_downloads === false) return;
    if (await wasFileCheckRecorded(downloadId, item.filename)) {
      completedDownloadChecks.add(downloadId);
      return;
    }
    const result = await apiRequest("/api/download/file-scan", {
      method: "POST",
      body: JSON.stringify({ path: item.filename, chrome_danger: item.danger || "" })
    });
    await recordFileCheck(downloadId, item.filename);
    if (result.level === "HIGH RISK" || result.level === "WARNING") {
      // The Activity Centre holds the details; no desktop or page notification.
      await updatePendingBadge();
    }
  } catch (error) {
    console.warn("PAUSE file inspection unavailable:", error.message || error);
  } finally {
    fileChecksInFlight.delete(downloadId);
  }
}

chrome.downloads.onChanged.addListener(async (delta) => {
  // Ignore routine progress/state changes. Only query the local service when
  // Chrome reports a danger classification, and avoid duplicating an active
  // onCreated inspection for the same download.
  if (delta.state?.current === "complete") {
    void inspectCompletedDownload(delta.id);
    return;
  }
  const danger = delta.danger?.current;
  if (!danger || (!HIGH_DANGER_STATES.has(danger) && !WARNING_DANGER_STATES.has(danger))) return;
  if (downloadChecksInFlight.has(delta.id)) return;

  try {
    const settings = await loadProtectionSettings();
    if (!settings.protection_enabled || settings.scan_downloads === false) return;
    const pending = await readPendingDownloads();
    if (pending[String(delta.id)]) return;
    let paused = false;
    try { await chrome.downloads.pause(delta.id); paused = true; } catch (_) {}
    const high = HIGH_DANGER_STATES.has(danger);
    await writePendingDownload(delta.id, {
      level: high ? "HIGH RISK" : "WARNING",
      target: "Browser download protection alert",
      createdAt: Date.now(), paused,
      status: paused ? "paused_browser_alert" : "already_started",
      reasons: [`Chrome classified this download as '${danger}'.`]
    });
  } catch (error) {
    console.warn("PAUSE download event could not be processed:", error.message || error);
  }
});

chrome.runtime.onStartup.addListener(() => { void updatePendingBadge(); });
chrome.runtime.onInstalled.addListener(() => { void updatePendingBadge(); });
void updatePendingBadge();
