const $ = (id) => document.getElementById(id);
function send(message) {
  return new Promise((resolve) => chrome.runtime.sendMessage(message, (response) => {
    if (chrome.runtime.lastError) resolve({ ok: false, error: chrome.runtime.lastError.message });
    else resolve(response || { ok: false, error: "No response" });
  }));
}
async function refresh() {
  const response = await send({ type: "PAUSE_PING" });
  if (response.ok) {
    $("dot").className = "pulse";
    $("status").textContent = response.status.protection_enabled ? "PAUSE is connected" : "Protection is paused";
    $("detail").textContent = `${response.status.stats.total} local checks recorded`;
  } else {
    $("dot").className = "pulse off";
    $("status").textContent = "Local engine unavailable";
    $("detail").textContent = response.error || "Open PAUSE and pair this extension.";
  }
}
$("scan").addEventListener("click", async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.url || !/^https?:/.test(tab.url)) {
    $("result").querySelector("b").textContent = "This page cannot be inspected";
    $("result").querySelector("small").textContent = "Browser internal pages are not available to the extension.";
    return;
  }
  const response = await send({ type: "PAUSE_SCAN", payload: { type: "manual page scan", url: tab.url } });
  $("result").querySelector("b").textContent = response.ok ? `${response.result.level} · ${response.result.score}/100` : "Scan unavailable";
  $("result").querySelector("small").textContent = response.ok ? response.result.summary : response.error;
});
$("ai").addEventListener("click", async () => { try { const [tab] = await chrome.tabs.query({ active: true, currentWindow: true }); if (!chrome.sidePanel?.open || !tab?.windowId) throw new Error("Update Chrome/Edge to a version with Side Panel support."); await chrome.sidePanel.open({ windowId: tab.windowId }); window.close(); } catch (error) { $("result").querySelector("b").textContent = "PAUSE AI unavailable"; $("result").querySelector("small").textContent = error.message; } });
$("settings").addEventListener("click", () => send({ type: "PAUSE_OPEN_OPTIONS" }));
$("dashboard").addEventListener("click", () => chrome.tabs.create({ url: "http://127.0.0.1:8765/app" }));
async function refreshPendingDownloads() {
  const response = await send({ type: "PAUSE_PENDING_DOWNLOADS" });
  const pending = response?.pending || {};
  const entries = Object.entries(pending);
  const panel = $("pending");
  const list = $("pending-list");
  $("pending-count").textContent = String(entries.length);
  if (!entries.length) { panel.hidden = true; list.replaceChildren(); return; }
  panel.hidden = false; list.replaceChildren();
  entries.forEach(([id, item]) => {
    const card = document.createElement("div"); card.className = "pending-item";
    const name = document.createElement("div"); name.className = "pending-name"; name.textContent = item.target || `Download ${id}`;
    const meta = document.createElement("div"); meta.className = "pending-meta"; meta.textContent = `${item.level || "WARNING"} · waiting for your decision`;
    const actions = document.createElement("div"); actions.className = "pending-actions";
    const finish = async (resume) => {
      const done = await send({ type: "PAUSE_DOWNLOAD_DECISION", downloadId: id, resume });
      if (done.ok) refreshPendingDownloads();
      else meta.textContent = done.error || "Could not update this download.";
    };
    if (item.cancelled || item.status === "cancelled_after_check") {
      meta.textContent = `${item.level || "HIGH RISK"} · cancelled after inspection`;
      const acknowledge = document.createElement("button"); acknowledge.className = "resume"; acknowledge.textContent = "Acknowledge";
      acknowledge.addEventListener("click", () => finish(true));
      actions.append(acknowledge);
    } else if (item.paused === false) {
      meta.textContent = `${item.level || "UNKNOWN"} · download already started; it was not held`;
      const cancel = document.createElement("button"); cancel.textContent = "Cancel download";
      cancel.addEventListener("click", () => finish(false));
      const dismiss = document.createElement("button"); dismiss.className = "resume"; dismiss.textContent = "Keep / dismiss";
      dismiss.addEventListener("click", () => finish(true));
      actions.append(cancel, dismiss);
    } else {
      const cancel = document.createElement("button"); cancel.textContent = "Cancel download";
      cancel.addEventListener("click", () => finish(false));
      const resume = document.createElement("button"); resume.className = "resume"; resume.textContent = item.level === "HIGH RISK" ? "Advanced: resume" : "Resume anyway";
      resume.addEventListener("click", () => finish(true));
      actions.append(cancel, resume);
    }
    card.append(name, meta, actions); list.append(card);
  });
}
$("version").textContent = `PAUSE ${chrome.runtime.getManifest().version}`;
refresh(); refreshPendingDownloads();
