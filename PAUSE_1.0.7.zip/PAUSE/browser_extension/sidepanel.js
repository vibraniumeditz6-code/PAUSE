const $ = (id) => document.getElementById(id);
const messages = [];
let pageContext = null;
let recognition = null;
let handsFree = false;
let waitingForCommand = false;
let sending = false;
let speechSpeaking = false;

function send(message) {
  return new Promise((resolve) => chrome.runtime.sendMessage(message, (response) => {
    if (chrome.runtime.lastError) resolve({ ok: false, error: chrome.runtime.lastError.message });
    else resolve(response || { ok: false, error: "No response from PAUSE." });
  }));
}
function addMessage(role, text, citations = []) {
  const item = document.createElement("article"); item.className = `message ${role}`;
  const avatar = document.createElement("div"); avatar.className = "avatar"; avatar.textContent = role === "assistant" ? "P" : "YOU";
  const bubble = document.createElement("div"); bubble.className = "bubble";
  if (role === "assistant") { const label = document.createElement("b"); label.textContent = "PAUSE AI"; bubble.append(label); }
  const p = document.createElement("p"); p.textContent = text; bubble.append(p);
  if (citations.length) {
    const box = document.createElement("div"); box.className = "citations";
    citations.forEach((source, index) => {
      const a = document.createElement("a"); a.href = source.url; a.target = "_blank"; a.rel = "noopener noreferrer";
      a.textContent = `${index + 1}. ${source.title || new URL(source.url).hostname}`; box.append(a);
    });
    bubble.append(box);
  }
  item.append(avatar, bubble); $("messages").append(item); $("messages").scrollTop = $("messages").scrollHeight;
  return item;
}
function speak(text) {
  if (!$("speakReplies").checked || !("speechSynthesis" in window)) return;
  const resumeWakeListener = handsFree;
  if (resumeWakeListener && recognition) {
    speechSpeaking = true;
    const activeRecognition = recognition;
    recognition = null;
    try { activeRecognition.stop(); } catch (_) {}
  }
  speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text.slice(0, 3500));
  utterance.rate = 1.02;
  const voices = speechSynthesis.getVoices();
  const voice = voices.find(v => /en-IN/i.test(v.lang)) || voices.find(v => /^en/i.test(v.lang));
  if (voice) utterance.voice = voice;
  const resumeListener = () => {
    if (!resumeWakeListener) return;
    speechSpeaking = false;
    if (handsFree && !recognition) setTimeout(startHandsFreeRecognition, 650);
  };
  utterance.onend = resumeListener;
  utterance.onerror = resumeListener;
  speechSynthesis.speak(utterance);
}

function explicitOpenTarget(text) {
  const match = String(text || "").trim().match(/^(?:please\s+)?(?:open|go\s+to|navigate\s+to)\s+(https?:\/\/[^\s]+|(?:[a-z0-9-]+\.)+[a-z]{2,}(?:\/[^\s]*)?)$/i);
  if (!match) return "";
  const raw = match[1].replace(/[),.]+$/, "");
  try {
    const url = new URL(/^https?:\/\//i.test(raw) ? raw : `https://${raw}`);
    if (!/^https?:$/.test(url.protocol) || url.username || url.password) return "";
    return url.href;
  } catch (_) { return ""; }
}

async function ask(question) {
  const prompt = String(question || "").trim(); if (!prompt || sending) return;
  addMessage("user", prompt); messages.push({ role: "user", content: prompt });
  const openTarget = explicitOpenTarget(prompt);
  if (openTarget) {
    const response = await send({ type: "PAUSE_OPEN_URL", url: openTarget });
    addMessage("assistant", response.ok ? `Opened ${openTarget} in a new browser tab.` : (response.error || "Could not open that website."));
    messages.push({ role: "assistant", content: response.ok ? `Opened ${openTarget}` : "Website could not be opened." });
    $("question").value = "";
    return;
  }
  $("question").value = ""; $("send").disabled = true; sending = true;
  const placeholder = addMessage("assistant", "Thinking through that…");
  try {
    const response = await send({ type: "PAUSE_AI_CHAT", payload: {
      question: prompt, context: pageContext, history: messages.slice(0, -1).slice(-8), web_search: $("webSearch").checked
    }});
    if (!response.ok) throw new Error(response.error || "PAUSE AI request failed.");
    const result = response.data;
    placeholder.remove(); addMessage("assistant", result.answer, result.citations || []);
    messages.push({ role: "assistant", content: result.answer });
    speak(result.answer);
  } catch (error) {
    placeholder.remove(); addMessage("assistant", error.message || "PAUSE AI could not answer that.");
  } finally { sending = false; $("send").disabled = false; $("question").focus(); }
}

$("composer").addEventListener("submit", (event) => { event.preventDefault(); void ask($("question").value); });
$("question").addEventListener("keydown", (event) => { if (event.key === "Enter" && !event.shiftKey) { event.preventDefault(); $("composer").requestSubmit(); } });
$("clearChat").addEventListener("click", () => { messages.length = 0; $("messages").replaceChildren(); addMessage("assistant", "Fresh conversation. What are we exploring?"); });

$("pageContext").addEventListener("click", async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id || !/^https?:/i.test(tab.url || "")) { addMessage("assistant", "This browser page does not expose readable web content to PAUSE. Try a normal HTTP/HTTPS page."); return; }
  $("pageContext").disabled = true; $("pageContext").querySelector("b").textContent = "Reading page…";
  const response = await send({ type: "PAUSE_GET_PAGE_CONTEXT", tabId: tab.id });
  $("pageContext").disabled = false; $("pageContext").querySelector("b").textContent = "Use this page";
  if (!response.ok || !response.context) { addMessage("assistant", response.error || "Could not read page text. Some browser pages block extensions."); return; }
  pageContext = response.context;
  $("pageTitle").textContent = `${pageContext.title || "Untitled page"} · ${pageContext.url}`;
  $("pageBadge").hidden = false;
  addMessage("assistant", `Page context attached: ${pageContext.title || pageContext.url}. Ask me to explain, summarize or check something on this page.`);
});
$("removePage").addEventListener("click", () => { pageContext = null; $("pageBadge").hidden = true; });

function getRecognition() { return window.SpeechRecognition || window.webkitSpeechRecognition || null; }
$("micButton").addEventListener("click", () => {
  const Recognition = getRecognition();
  if (!Recognition) { addMessage("assistant", "Speech recognition is not available in this browser. You can still use text chat and spoken replies."); return; }
  if (recognition) { try { recognition.stop(); } catch (_) {} }
  recognition = new Recognition(); recognition.lang = "en-IN"; recognition.interimResults = false; recognition.maxAlternatives = 1; recognition.continuous = false;
  $("voiceStatus").hidden = false; $("voiceStatus").textContent = "Listening once… your browser may process speech recognition audio.";
  recognition.onresult = (event) => { const transcript = event.results[0]?.[0]?.transcript || ""; $("voiceStatus").textContent = `Heard: ${transcript}`; $("question").value = transcript; void ask(transcript); };
  recognition.onerror = (event) => { $("voiceStatus").textContent = `Voice input: ${event.error || "not available"}`; };
  recognition.onend = () => { if (!handsFree) setTimeout(() => { $("voiceStatus").hidden = true; }, 3500); };
  try { recognition.start(); } catch (error) { $("voiceStatus").textContent = error.message; }
});

function stopHandsFree() {
  handsFree = false; waitingForCommand = false; $("wakeToggle").classList.remove("active"); $("wakeToggle").textContent = "Enable “PAUSE”";
  if (recognition) { try { recognition.stop(); } catch (_) {} recognition = null; }
  $("voiceStatus").textContent = "Wake phrase is off. Microphone is not being used by PAUSE.";
  setTimeout(() => { if (!handsFree) $("voiceStatus").hidden = true; }, 3500);
}
function startHandsFreeRecognition() {
  if (!handsFree) return;
  const Recognition = getRecognition(); if (!Recognition) { stopHandsFree(); addMessage("assistant", "Hands-free recognition is not supported in this browser."); return; }
  recognition = new Recognition(); recognition.lang = "en-IN"; recognition.continuous = true; recognition.interimResults = false; recognition.maxAlternatives = 1;
  recognition.onresult = (event) => {
    for (let i = event.resultIndex; i < event.results.length; i++) {
      if (!event.results[i].isFinal) continue;
      const transcript = String(event.results[i][0]?.transcript || "").trim(); if (!transcript) continue;
      const lower = transcript.toLowerCase();
      if (!waitingForCommand) {
        const at = lower.indexOf("pause");
        if (at < 0) continue;
        const command = transcript.slice(at + 5).replace(/^[\s,.:;-]+/, "").trim();
        waitingForCommand = true;
        $("voiceStatus").hidden = false;
        if (command) { waitingForCommand = false; $("voiceStatus").textContent = `Wake phrase heard: ${command}`; void ask(command); }
        else $("voiceStatus").textContent = "PAUSE heard. Say your question now…";
      } else {
        waitingForCommand = false; $("voiceStatus").textContent = `Heard: ${transcript}`; void ask(transcript);
      }
    }
  };
  recognition.onerror = (event) => { if (event.error === "not-allowed" || event.error === "service-not-allowed") { addMessage("assistant", "Microphone permission was denied. Wake phrase has been switched off."); stopHandsFree(); } };
  recognition.onend = () => { recognition = null; if (handsFree && !speechSpeaking) setTimeout(startHandsFreeRecognition, 450); };
  try { recognition.start(); } catch (_) { recognition = null; setTimeout(() => { if (handsFree) startHandsFreeRecognition(); }, 800); }
}
$("wakeToggle").addEventListener("click", () => {
  if (handsFree) { stopHandsFree(); return; }
  const Recognition = getRecognition(); if (!Recognition) { addMessage("assistant", "Hands-free wake phrase is not supported in this browser."); return; }
  if (!confirm("Enable the PAUSE wake phrase while this side panel remains open? The microphone will stay active and your browser's speech-recognition service may process audio. PAUSE does not store recordings. You can switch this off at any time.")) return;
  handsFree = true; waitingForCommand = false; $("wakeToggle").classList.add("active"); $("wakeToggle").textContent = "Turn wake phrase off";
  $("voiceStatus").hidden = false; $("voiceStatus").textContent = 'Wake phrase is active. Say “PAUSE” followed by your question. Panel must stay open.';
  startHandsFreeRecognition();
});
$("stopSpeech").addEventListener("click", () => { if ("speechSynthesis" in window) speechSynthesis.cancel(); if (speechSpeaking) { speechSpeaking = false; if (handsFree && !recognition) setTimeout(startHandsFreeRecognition, 400); } });
window.addEventListener("pagehide", () => { stopHandsFree(); if ("speechSynthesis" in window) speechSynthesis.cancel(); });

$("deviceToggle").addEventListener("click", () => { $("devicePanel").hidden = !$("devicePanel").hidden; if (!$("devicePanel").hidden) refreshDevices(); });
async function refreshDevices() {
  $("deviceInfo").textContent = "Checking supported Windows device information…";
  const response = await send({ type: "PAUSE_DEVICE_SNAPSHOT" });
  if (!response.ok) { $("deviceInfo").textContent = response.error; return; }
  const device = response.data.device || {};
  const wifi = (device.wifi_networks || []).map(x => `Wi-Fi · ${x.ssid} · ${x.security}`).join("\n") || "Wi-Fi · No visible networks returned";
  const bt = (device.bluetooth_known_devices || []).map(x => `Bluetooth · ${x.name}`).join("\n") || "Bluetooth · No Windows-known devices returned";
  $("deviceInfo").textContent = `${wifi}\n\n${bt}\n\n${device.note || ""}`;
}
$("refreshDevices").addEventListener("click", refreshDevices);
$("devicePanel").querySelectorAll("[data-power]").forEach(button => button.addEventListener("click", async () => {
  const action = button.dataset.power;
  const prompts = { shutdown: "Schedule Windows shutdown in 60 seconds? You can cancel the countdown from PAUSE.", restart: "Schedule Windows restart in 60 seconds? You can cancel the countdown from PAUSE.", sleep: "Put this Windows computer to sleep now? Unsaved work may be interrupted.", cancel: "Cancel a pending Windows shutdown/restart countdown?" };
  if (!confirm(prompts[action])) return;
  button.disabled = true;
  try { const response = await send({ type: "PAUSE_DEVICE_ACTION", action, confirmed: true }); if (!response.ok) throw new Error(response.error); addMessage("assistant", response.data.message); }
  catch (error) { addMessage("assistant", error.message || "The device action failed."); }
  finally { button.disabled = false; }
}));

(async function init() {
  const response = await send({ type: "PAUSE_AI_STATUS" });
  if (response.ok && response.data.assistant.configured) {
    $("engineDot").classList.add("ready"); $("engineStatus").textContent = `Gemini · ${response.data.assistant.model_label || response.data.assistant.model || "AI configured"}`;
  } else {
    $("engineStatus").textContent = "AI setup required";
    addMessage("assistant", "PAUSE AI needs a Gemini API key. Open the PAUSE project folder, double-click EDIT_GEMINI_KEY.bat, paste your key after GEMINI_API_KEY= in .env, save, then refresh PAUSE AI status in Settings.");
  }
})();
