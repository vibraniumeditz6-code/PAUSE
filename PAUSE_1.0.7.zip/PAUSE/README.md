# PAUSE — Digital Safety Command

**Build:** 1.0.7 · **Platform:** Windows desktop + Chrome / Microsoft Edge (Chromium) · **Architecture:** Python loopback service + browser-based desktop control room

PAUSE is a local-first security workspace for supported browser actions, downloads, and explicitly authorised email inspection. It combines a Chromium extension, local heuristic analysis, an opt-in Gmail OAuth connector, a local account gate, and a multi-workspace control room.

> **Safety notice:** 1.0.7 is a tested development release, not a certified antivirus, firewall, EDR product, or independently audited security tool. Keep Chrome/Edge Safe Browsing and Microsoft Defender enabled. A **SAFE** result means only that the configured checks did not detect their indicators; it is not a guarantee.

## 1.0.7 — Gemini model switcher

- PAUSE AI now lets you choose among stable Gemini text-generation models from the AI page or Settings.
- The model choice is saved locally and shared by desktop chat and the browser side panel. The API key remains in `.env`.
- Gemini 3.5 Flash-Lite is the efficient default; Gemini 3.8 Flash, 3.6 Flash and 4 Argon remain available when supported by the Google project.
- A 429 may be tied to a model quota or a project-level restriction. To isolate Search grounding, try a request with Live web search off; if plain requests fail on multiple models, check the project in Google AI Studio.

### Select a Gemini model

1. Open **PAUSE AI** or **Settings → PAUSE AI → Default Gemini model**.
2. Choose a model. The choice saves to PAUSE's local settings and applies to desktop and extension chats.
3. Use **Test AI connection** to test the selected model.
4. If you see HTTP 429, try another model and one request with Live web search disabled. Switching models does not bypass project-wide quota or account restrictions.


## 1.0.4 — Gemini .env rebuild

- Removed the Settings-screen Gemini key input and the separate DPAPI key vault. PAUSE now reads the key from the project-root `.env` file.
- Added `.env.example`, a blank `.env` template and `EDIT_GEMINI_KEY.bat` to open the file directly in Notepad.
- Switched the Gemini client to the documented `models.generateContent` REST endpoint and documented Google Search grounding payload.
- The Settings page now shows the `.env` location, key-detection status, a refresh action and a real connection test.
- Google API errors include the actual status/message returned by Google, making HTTP 400 responses diagnosable.

### Configure PAUSE AI in 1.0.4

1. Open the PAUSE folder.
2. Double-click `EDIT_GEMINI_KEY.bat`.
3. Paste the Gemini key after `GEMINI_API_KEY=` in Notepad, then save and close.
4. In PAUSE → Settings → PAUSE AI, choose **Refresh key status**, then **Test AI connection**.
5. Keep `.env` private. It is ignored by Git; never share it or include a real key in a ZIP or screenshot.

The `.env` key is read directly for each AI request, so a PAUSE restart is not required after saving. The older in-app key-save route is retired. The existing animated interface and reduced-motion support remain included.

## 1.0.1 maintenance update

Local sign-in is remembered on this device for up to 30 days unless you sign out. In PAUSE AI, press Enter to send and Shift+Enter for a newline.

## What's new in 1.0.1 — PAUSE AI

- **PAUSE AI in the desktop app and browser side panel:** ask general questions, learn concepts, work through maths and coding, and request current web research. The service uses the Gemini `generateContent` REST API; when **Search the web** is enabled it can use Google Search grounding and return source links. The selected model can be changed in the PAUSE AI page or Settings; the default is `gemini-3.5-flash-lite`.
- **Explicit current-page context:** in the extension side panel choose **Use this page**. PAUSE extracts bounded visible page text after removing forms, editable fields, buttons and embedded scripts. It sends that context to Gemini only alongside a question you submit. Passwords and ordinary form fields are not intentionally collected; still review sensitive pages before attaching them.
- **Voice input and spoken answers:** use the one-shot **Speak** control, or optionally enable the “PAUSE” wake phrase while the extension side panel is open. The microphone is active only while the user has enabled listening and the panel remains open. Browser speech-recognition services may process audio; PAUSE does not save recordings. This is not a system-wide Windows wake-word listener.
- **Quick website opening:** enter an explicit command such as `open example.com` or `go to https://example.com` in the extension side panel. PAUSE opens only HTTP/HTTPS URLs that the user explicitly typed; search-grounded source links are also clickable.
- **Windows device helpers:** view Wi-Fi network names currently visible to the adapter and Windows-known Bluetooth devices. These are not Wi-Fi credentials or a scan of unpaired nearby Bluetooth devices. Shutdown/restart are scheduled with a 60-second cancellation window; Sleep, shutdown and restart all require a separate confirmation.
- **Local AI key handling:** place the Gemini API key in the project-root `.env` file as `GEMINI_API_KEY=...`. The file is ignored by Git and is never sent to the extension. The extension calls the authenticated local PAUSE service, which contacts Google only when a question is submitted. Google processes requests under its service terms; Google API quotas and paid usage may apply.
- **Updated branding:** the supplied gradient PAUSE monogram is used for the desktop app and extension. Added the extension side panel and tightened disclosure around page context, voice input and device controls.

### Configure PAUSE AI

1. Start PAUSE and sign in.
2. Open `EDIT_GEMINI_KEY.bat` and paste the key after `GEMINI_API_KEY=` in `.env`.
3. Return to **Settings → PAUSE AI**, refresh status and test the connection.
4. In Chrome/Edge, reload the unpacked PAUSE extension and open its toolbar icon → **Open PAUSE AI**. Keep PAUSE running and the extension paired.
5. Enable **Search the web** for current information. Attach a page only when you want PAUSE to use it. Click source links to open cited pages.

For voice, use **Speak** for one request or explicitly enable the wake phrase while the panel remains open. The built-in browser speech service may process audio. A true system-wide, background “Hey PAUSE” listener is not included in this release.

## What's new in 0.8.0

- **Interactive Activity Map:** a pan/zoom/drag graph of the latest 120 local event records, with filters for severity and surface plus an inspector for recorded host and event details. Graph edges represent only an event's recorded hostname membership; this is not packet capture, an attack-path detector, or a view of all device traffic.
- **Link X-Ray:** compares a URL's real destination with URL-like visible link text, surfaces common redirect parameters, and displays host/protocol/port/path/query-key anatomy. It uses local parsing and heuristics only; it does not resolve live redirect chains or consult a domain reputation feed.
- **File DNA:** selected files can be inspected locally for common file signatures, filename-extension mismatches, size/MIME metadata and a complete SHA-256 fingerprint. The selected file is read in the browser session and is not uploaded or executed. A fingerprint is an identity check, not a malware verdict.
- **Threat Story:** groups actual PAUSE activity records sharing a hostname into a timeline. It explicitly describes correlation, not causation, and never invents missing mail/browser/download steps.
- **Quiet Mode:** a real ON/OFF preference. ON keeps routine priority findings in the Alert Centre; OFF surfaces new WARNING/HIGH RISK batches once in the app's inline status line. Neither mode enables operating-system or browser desktop notifications, and neither changes scanning/protection rules.
- Added the supplied PAUSE brand mark to the desktop app and extension icons. Chrome/Edge popup and options pages now use a light surface while retaining cyan/violet accent glows.
- Simplified the workspace sidebar and added the in-app Gmail Desktop OAuth setup walkthrough.

## Using the Activity Map

1. Start PAUSE and sign in to your local account.
2. Open **Activity Map** from the Workspace sidebar.
3. Use the severity, surface and search filters to narrow the graph.
4. Click a host cluster or event node to inspect recorded details and reasons.
5. Drag a node to rearrange its cluster, drag the background to pan, use the mouse wheel or +/- buttons to zoom, and choose **Reset view** to restore the default layout.

The map starts empty when the local activity history is empty. Create real records using supported Browser Shield checks, File DNA inspections, manual message scans, or an authorised Gmail scan. It never seeds the graph with fake events.

## What's new in 0.6.3

- **Light mode is now the default**; users can switch to Midnight dark mode in Settings. The branded sign-in hero keeps its dark cyan/violet glow treatment and animated shield/orbits.
- Removed operating-system notifications entirely. SAFE checks are silent; WARNING and HIGH RISK results are kept in the in-app Alert Centre, while only an action that needs a decision receives one compact white browser card.
- Browser link/form approval now replays the original anchor or form action so normal site/router handlers can run, rather than always forcing a tab URL replacement.
- Browser extension alerts now use the PAUSE shield icon, derived from the supplied brand artwork. The original artwork is preserved under `browser_extension/assets/`.
- Download decisions are reviewed from the extension popup using a quiet toolbar badge. Routine SAFE file checks do not create system notifications.
- Added **Gmail OAuth 2.0 with PKCE** using only the read-only `gmail.readonly` scope. Gmail refresh tokens are protected with Windows DPAPI; the app never stores the token as plain text. The integration supports a manually started recent-inbox scan and optional 2-minute polling, disabled by default.
- Gmail activity records contain a redacted verdict and sender domain only; message body, subject, and full sender address are not retained in the PAUSE activity database.
- Gmail monitoring resumes after a service restart only when the user previously enabled it and an encrypted token is still available.
- Improved disconnect behaviour: PAUSE attempts Google token revocation and always removes its local token copy.
- Expanded automated tests for Gmail parsing, redacted storage, integration state, and local API security boundaries.

## 0.7.0 — Link intelligence and evidence release

- Added Link X-Ray, local File DNA, and hostname-based Threat Story views.
- Added a persistent Quiet Mode ON/OFF setting while keeping OS/browser desktop notifications disabled.
- Applied supplied PAUSE logo artwork to the app and extension, and refreshed extension popup/options styling to a light theme.
- Simplified sidebar navigation and added a step-by-step Gmail Desktop OAuth guide inside Connections.
- Added regression tests for visible-link mismatches, redirect parameters, local file signatures/hashes, cautious event correlation, Quiet Mode persistence and API output.

## 0.6.3 — Calm interaction release

- Removed floating status banners from browser pages; passive scans are recorded quietly in Activity.
- Passive page-load checks no longer interrupt after navigation; only a clicked action that needs a decision receives the compact white card.
- Replaced bottom/right floating app toasts with a small inline status label in the top bar, rate-limited to avoid visual spam.
- Gmail button errors are shown on the button itself instead of creating a new page notification.
- Updated the extension, API and app version to 0.6.3.

## 0.6.2 — Quiet stability release

- Defaults to quiet notification delivery and migrates older noisy settings to Quiet.
- Removes per-scan system notifications and repeated bottom-right app toasts.
- Replaces the full-screen dark browser warning overlay with a compact white decision card that does not dim the whole webpage.
- Removes the Chrome Notifications permission and all automatic desktop notification calls.
- Uses a non-interrupting extension toolbar badge for download decisions.
- Stops cancelling a download solely because Chrome did not pause it quickly enough; the outcome is marked as already started/unknown where appropriate.
- Reduces dashboard polling and avoids re-rendering the entire page on each background refresh.

## Quick start (Windows)

1. Extract the `PAUSE` folder from the ZIP.
2. Install Python 3.10 or newer and enable **Add Python to PATH** in the installer.
3. Double-click `run.bat`.
4. Keep the launcher console open while PAUSE is running. It opens the local control room in a browser/app window.
5. Create a local PAUSE account on first launch; sign in on later launches.
6. Light mode is the default; use Settings to choose Midnight dark mode. Quiet Mode can be switched ON or OFF in Settings. Results stay in Activity/Alert Centre, and brief action feedback appears inline in the top bar.
7. Open Browser Shield and pair the extension using the local pairing token.

No `pip install` step is required; the Python application uses the standard library.

## Browser extension setup

1. Keep PAUSE running and sign in.
2. In Chrome open `chrome://extensions`; in Edge open `edge://extensions`.
3. Enable **Developer mode**.
4. Choose **Load unpacked** and select the `browser_extension` folder in the extracted project.
5. Open PAUSE → **Browser Shield** → reveal/copy the pairing token.
6. Open the extension's Settings page, paste the token and choose **Test connection**.
7. Open the PAUSE toolbar icon and select **Open PAUSE AI**. This uses Chromium Side Panel support (Chrome 116+).

The extension inspects supported clicked links and form destinations; URL-like visible link text is compared with the actual destination as part of Link X-Ray. It also listens for Chromium download lifecycle events, attempts to pause downloads while checking source information, and can inspect selected local metadata after completion. Browser timing can prevent a pause from succeeding; no extension can promise interception of every download or every navigation path.

### Quiet notifications and warning decisions

- **No system notifications are used.** PAUSE does not request Chrome/Edge Notifications permission and does not call the Windows/browser desktop notification API.
- SAFE checks are silent. WARNING and HIGH RISK records appear in the in-app Alert Centre. A clicked link/form that requires a user decision receives one compact white card; repeated cards replace the previous card rather than stacking.
- Held downloads are shown by a count on the PAUSE extension icon and are reviewed in the extension popup. There are no per-download OS toast stacks.
- Warning/high-risk link decisions use a compact white card in the top-right of the webpage. The rest of the page is not dimmed or covered. **Continue anyway** replays the original link/form event so normal page event handlers have an opportunity to run. Some sites reject synthetic events and may still require a fresh user click; direct navigation is not universally interceptable.
- If the app service cannot be reached, PAUSE reports **CHECK NOT COMPLETED** rather than presenting a clean result. A fast download that cannot be paused is not cancelled merely because PAUSE missed the pause window; its check status is labelled accordingly.

## Notification and download troubleshooting

- PAUSE intentionally has no desktop notification permission or notification code. Use the in-app Alert Centre for events and the extension toolbar badge/popup for pending download decisions.
- Before installing this build, open `chrome://extensions` or `edge://extensions`, remove every older PAUSE extension entry, then load only this package's `browser_extension` folder. This prevents an older copy from continuing to send alerts. Old copies can continue generating notifications even after the new build is installed.
- If you still see repeated pop-ups after removing older PAUSE extensions, they are coming from another browser extension or application, not this PAUSE build.
- For a completed-file result, the extension must be able to reach the PAUSE service and access the downloaded file path. PAUSE checks supported metadata and selected signatures; it does not unpack archives, scan macros, or replace Microsoft Defender. If access fails, the result should be treated as **UNKNOWN**, not SAFE.
- Gmail monitoring is a 120-second poll, not push delivery. Keep the PAUSE local service running; the redacted event is available in the Activity Log when you reopen PAUSE. Routine inbox results do not create system pop-ups.

## Gmail OAuth setup (Windows)

Gmail OAuth is implemented, but each developer/test installation must supply its own Google OAuth Desktop client ID. PAUSE cannot connect an account until that setup and the user's consent are completed.

1. Create a Google Cloud project and enable the **Gmail API**.
2. Configure the Google OAuth consent screen. During development, add the Google account you will test with as a test user if the app is in Testing status.
3. Create an OAuth client whose application type is **Desktop app**.
4. In PAUSE → **Connections** → Gmail, paste the client ID and select **Connect Gmail**.
5. Review Google's consent page. PAUSE requests `https://www.googleapis.com/auth/gmail.readonly`; it does not request send, modify, delete, or compose permission.
6. After consent, return to PAUSE. Use **Scan recent inbox** for a user-initiated scan, or explicitly enable **2-minute inbox monitoring**.

The inbox monitor checks up to 20 recent messages from the last 2 days every 120 seconds while the local PAUSE service is running. Monitoring is off by default. Message bodies are analysed in memory, and the activity database stores only a redacted result. Gmail OAuth tokens are encrypted with the current Windows user's DPAPI. Disconnect attempts to revoke the Google grant and deletes PAUSE's local token file. **Google testing-mode caveat:** an External OAuth app left in Testing receives Gmail-scope refresh tokens that expire after 7 days; expect to reconnect during development. `gmail.readonly` is a restricted scope, so public distribution may require Google's OAuth verification and security assessment.

**Important Google policy note:** `gmail.readonly` is classified as a restricted Gmail scope. Personal/testing use can have different verification treatment, but making PAUSE available to the public can require Google OAuth verification and, depending on data handling and distribution, a third-party security assessment. Do not advertise a public Gmail connection until Google requirements and privacy/data-use obligations are met.

Before connecting a primary inbox, test with a dedicated test account and sample messages. PAUSE is still a development build and has not had an independent security audit.

Official Google setup reference: https://developers.google.com/workspace/gmail/api/quickstart/python

## Other provider status

| Provider | Current state | Boundary |
|---|---|---|
| Gmail | OAuth/API implemented; client ID and consent required | Read-only scope; local token encrypted with Windows DPAPI |
| Outlook / Hotmail | Setup placeholder | Microsoft Entra app, Graph OAuth and verified change-notification infrastructure not configured |
| WhatsApp Personal | Not supported for direct inbox access | No official public consumer inbox API to silently read/intercept personal chats |
| WhatsApp Business | Setup placeholder | Requires Meta business setup, business access token and public verified webhook |
| Microsoft Teams | Planned | Graph registration and permissions not configured |

A Windows notification-preview connector may be considered separately in a future build; it would only inspect content Windows exposes after the notification appears and cannot stop delivery. PAUSE does not scrape WhatsApp Web, copy session cookies, or request QR/session tokens.

## Current protection scope and limits

| Surface | What PAUSE does | Important limit |
|---|---|---|
| Browser links | Pre-checks supported clicked links using local heuristics | Address-bar/direct loads and custom JavaScript navigation cannot be guaranteed pre-blocked |
| Forms | Checks supported form destinations before submit | Some custom forms/scripts may not be intercepted |
| Downloads | Attempts to pause newly created downloads and check source; browser danger metadata can raise risk | Browser event arrives after download starts; pause may fail due to timing |
| Completed files | Filename deception, selected file-signature checks, size/path boundaries and SHA-256 | Not antivirus; no archive extraction, macro scanning, sandboxing or quarantine |
| Gmail | OAuth read-only scan of up to 20 recent messages / 2-day window; optional 2-minute polling | Requires a user's own OAuth client ID and consent; polling is not push delivery |
| PAUSE AI | Gemini chat, optional Google Search grounding, voice input/output and explicit page context in the extension | Requires a user-supplied Gemini API key and internet; attached page context/questions are sent to Google when submitted; no global wake word |
| Windows device tools | Visible Wi-Fi SSIDs, Windows-known Bluetooth devices, confirmed shutdown/restart/sleep | No Wi-Fi passwords, no live scan of unknown Bluetooth devices; power actions require confirmation; shutdown/restart have a 60-second cancel window |
| Message Shield | Analyses text entered by the user | Not a system-wide message listener |
| Network Map | Displays a topology/workspace visualisation | No packet capture, process monitoring or network blocking adapter |
| Windows apps | No global action interception | Requires a separately designed, reviewed Windows integration |

## Risk states

- **SAFE:** no configured indicator in the current heuristic checks fired. This is not a guarantee or a malware verdict.
- **WARNING:** caution signals were detected; the supported action may be held for a user decision.
- **HIGH RISK:** stronger configured signals were detected; supported browser actions/downloads can be paused. An advanced override may be available.
- **UNKNOWN / not checked:** PAUSE could not complete a check or the required integration is unavailable. It must not be relabelled SAFE.

Risk scores are heuristic severity points, not calibrated probabilities. False positives and false negatives are possible.

## Local account and data

The PAUSE login is a **device-local app account**, not cloud identity. It does not verify an email address. Passwords are stored as salted PBKDF2-HMAC-SHA256 hashes. The activity database and settings are stored under `%LOCALAPPDATA%\\PAUSEGuard\\`. The local login does not encrypt the SQLite database, settings, or pairing token. Gmail OAuth tokens are separately protected with Windows DPAPI. Use a protected Windows account and device encryption.

Raw Gmail content is processed in memory and not persisted to activity records. PAUSE stores hashed Gmail message IDs for duplicate avoidance. The browser extension stores its pairing token in the browser profile's extension storage.

## Motion / performance

The interface uses CSS transitions, transforms and `requestAnimationFrame` visuals. It respects `prefers-reduced-motion`; it does not promise a fixed 250 FPS because rendering depends on display refresh, browser scheduling, GPU and device performance.

## Tests

```bat
python -m unittest discover -s tests -v
```

The suite covers local accounts, URL/email heuristics, file inspection, Gmail parsing/redaction, AI key handling, device-action confirmation, local API authentication and extension assets. Browser JavaScript syntax can be checked with `node --check`.

## Project structure

```text
PAUSE/
├── main.py
├── run.bat
├── run_tests.bat
├── pause_guard/
│   ├── engine.py       # URL and message heuristics
│   ├── downloads.py    # Local post-download metadata inspection
│   ├── gmail.py        # Gmail OAuth, read-only API, DPAPI vault and polling
│   ├── server.py       # Loopback API, sessions and provider catalogue
│   ├── storage.py      # Local accounts, settings, event history and pairing token
│   └── web/index.html  # PAUSE light/dark desktop control room
├── browser_extension/
│   ├── manifest.json
│   ├── background.js   # Quiet browser scan bridge and download lifecycle
│   ├── content.js      # Link/form/Gmail open-message integration
│   ├── icons/          # Derived PAUSE shield toolbar icons
│   ├── assets/         # Original supplied PAUSE brand art
│   └── popup.* / options.*
├── tests/
└── docs/
```
