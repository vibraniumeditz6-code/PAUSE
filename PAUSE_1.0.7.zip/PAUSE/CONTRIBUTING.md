# Contributing to PAUSE

- Keep changes defensive and permission-transparent.
- Do not add covert monitoring, keylogging, hidden screen capture, or private-app database scraping.
- Do not store raw messages, form values, passwords, or provider tokens in activity history.
- Add tests for every risk rule and enforcement path, including false-positive and integration-offline cases.
- Unknown or failed checks must never be converted to SAFE.
- Do not call a heuristic file check antivirus.
- Keep browser permissions and OAuth scopes to the minimum required.
- Never commit OAuth credentials, `.env` files, pairing tokens, local databases, or personal data.
