# PAUSE 1.0.7

- Added a persistent Gemini model selector shared by desktop chat and the browser side panel.
- Added stable Gemini 4/3 text-generation choices, with Gemini 3.5 Flash-Lite as the efficient default.
- Model selection is validated server-side and saved in local PAUSE settings.
- Gemini 429 and model-not-found errors now identify the selected model and explain project-wide quota behavior.

## 1.0.6 — frontend runtime repair

- Restored the missing shared `wireCommon()` interaction hook used by every dynamically rendered page.
- Restored the shared detail modal, safe demo runner and activity CSV export handler that were accidentally dropped from the 1.0.4/1.0.5 UI bundle.
- Changed common click wiring to delegated handling on the current view, so dynamically rendered navigation links remain functional after page updates.
- Added regression tests that fail if a shared UI helper is missing or the AI composer loses its `preventDefault()` submit handler.
- Preserved the Gemini `.env` configuration and account page changes.

## 1.0.5 — account renderer crash fix

- Restored the missing `renderAccount()` page used by the navigation map.
- Implemented local profile update, password change, sign-out and account deletion UI against existing authenticated endpoints.
- Added a regression test that checks every renderer referenced by `renderPage()` is defined.
- No change to Gemini `.env` configuration or API request behaviour.

## 1.0.4 — Gemini .env rebuild

- Removed the in-app Gemini API-key entry and DPAPI key vault path entirely.
- PAUSE now reads `GEMINI_API_KEY` directly from the project-root `.env` file; `.env` is excluded from Git by default.
- Added `.env.example` and `EDIT_GEMINI_KEY.bat` to open the file in Notepad.
- Switched the Gemini client to the documented `models.generateContent` REST request and matching Google Search grounding request shape.
- Added Gemini `groundingMetadata` citation parsing and clearer HTTP 400/401/403/429 error details.
- Settings now explains the `.env` workflow and can refresh key status and test the live connection.

## 1.0.3 — persistence + motion polish

- Main Settings save now persists the Gemini key when a value has been entered; the dedicated secure-key save remains supported.
- The UI clearly explains that saved API keys are deliberately hidden after verification.
- Failed key replacement no longer removes the previous verified key; temporary encrypted files are cleaned up safely.
- Settings writes are atomic.
- Added an animated aurora layer, restrained depth/glow interactions, button sheen and smooth workspace/chat entrances, with reduced-motion support.
- Added key persistence and UI regression tests.

## 1.0.1 — persistence and usability fix

- Local sign-in sessions now survive PAUSE service restarts and browser restarts for up to 30 days on this device. Session tokens are stored in browser local storage and only SHA-256 digests are stored in the local SQLite database. Signing out revokes the session.
- Gemini key saving now verifies the encrypted DPAPI file by decrypting it immediately before reporting success. The Settings screen shows the local vault path.
- PAUSE AI desktop composer sends on Enter; Shift+Enter inserts a new line.
- Version labels updated to 1.0.1.

# Changelog

## 1.0.0 — PAUSE AI and Windows companion

- Added PAUSE AI to the desktop app and a Chromium side panel, powered by the Gemini Interactions API with optional Google Search grounding and returned source citations.
- Added explicit **Use this page** context capture in the extension. Page text is bounded and form controls/editable areas are removed before submission; the user must attach context and submit a question.
- Added one-shot speech input, spoken replies and an optional “PAUSE” wake phrase that listens only while the side panel is open and enabled. Browser speech services may process audio; no recording is stored by PAUSE. A system-wide wake-word listener is not included.
- Added explicit website-open commands for user-entered HTTP/HTTPS URLs and clickable source citations.
- Added Windows device information for visible Wi-Fi network names and Windows-known Bluetooth devices, plus confirmed shutdown/restart/sleep controls. Shutdown/restart use a 60-second cancellable countdown.
- Stored the Gemini API key using Windows DPAPI; the key is not returned to the extension. Questions and explicitly attached page context are sent to Gemini only when submitted; requests disable saved Interactions API history (`store=false`).
- Replaced app and extension branding with the supplied PAUSE gradient monogram; updated the extension side panel, popup and UI version labels to 1.0.0.
- Added regression tests for PAUSE AI, key handling, API authentication, explicit device-action confirmation, side-panel voice disclosures and privacy-filtered page context.

## 0.8.0 — Interactive Activity Map

- Added an interactive Activity Map populated from the latest 120 locally recorded PAUSE events.
- Added severity/source/search filters, host clusters, individual event nodes, node inspection, dragging, pan, zoom, and reset controls.
- Graph edges only connect a recorded hostname cluster to its own recorded event rows; no causal attack paths or unobserved traffic are inferred.
- The graph is explicit that it is local event telemetry, not packet capture or a live view of all device connections.


## 0.7.0 — Link intelligence and evidence release

- Added Link X-Ray: local destination anatomy, URL-like visible-text comparison and common redirect-parameter inspection. The UI states that live redirects and external reputation are not resolved.
- Added File DNA: local selected-file signature hints, extension mismatch checks and SHA-256 fingerprinting without upload or execution.
- Added Threat Story: cautious timelines grouped from actual local records by hostname; the UI disclaims causal inference.
- Added a persisted Quiet Mode ON/OFF preference. OFF only shows priority batches in the app's inline status area; system notifications remain disabled.
- Added the supplied PAUSE logo to app and extension assets; switched extension popup and options surfaces to light mode while retaining accent glows.
- Simplified sidebar categories and added an in-app Gmail OAuth setup walkthrough.
- Added regression coverage for the new analysis, settings, assets and Threat Story endpoint.
- Versioned app, API, desktop package and extension as 0.7.0.

## 0.6.3 — Calm interaction release

- Removed floating in-page status notices; passive scan results are recorded in Activity without banners.
- Passive page-load checks no longer interrupt users after navigation.
- Replaced floating desktop-app toast cards with one small, rate-limited inline status label in the top bar.
- Gmail scan errors stay on the Gmail scan button instead of spawning notifications.
- Maintained the compact white action-decision card only for a clicked link/form that requires a choice.
- Added regression tests for quiet page checks, inline status feedback and absence of the floating toast system.
- Versioned the app, extension and API as 0.6.3.

## 0.6.2 — Quiet reliability patch

- Kept desktop/browser operating-system notifications completely disabled; SAFE checks remain silent and warning details stay in the in-app Activity/Alert Centre.
- Kept browser decisions as one compact white inline card only when a clicked action needs the user's choice; no full-screen dimming or stacked cards.
- Removed automatic cancellation of a download when PAUSE failed to pause it in time, even if heuristic analysis later labels it HIGH RISK. The extension records the result and leaves an explicit Cancel control in its popup.
- Persistently deduplicated completed-file inspection records across browser service-worker restarts to prevent repeated work and duplicate activity.
- Made settings loading fail visibly as UNKNOWN when the local service cannot be reached, instead of silently skipping a scan under an empty settings object.
- Retained quiet toolbar-badge/popup handling for downloads waiting for a decision.
- Versioned the app, extension and API consistently as 0.6.2.

## 0.6.1 — Interruptions removed

- Removed system notifications entirely: the extension no longer requests the Notifications permission or calls the desktop notification API.
- SAFE checks remain silent; passive WARNING results stay in Activity; only a user action that needs a decision gets a single white inline card.
- Old notification settings are forcibly migrated to quiet and cannot re-enable desktop pop-ups.
- Replaced the browser's dimmed, full-screen warning overlay with a compact white top-right decision card; the rest of the webpage remains usable.
- Made browser status notices single-instance and short-lived.
- Added an extension toolbar badge for pending downloads; the popup is the decision centre.
- Reduced download event work by ignoring routine onChanged progress updates.
- A download that cannot be paused is no longer cancelled merely because the pause window was missed; outcomes are labelled honestly.
- Reduced dashboard refresh frequency and stopped re-rendering the whole workspace on each poll.
- Simplified the navigation to currently usable workspaces.
- Added regression tests for quiet defaults, legacy settings migration, and the absence of system notification permissions/calls.

## 0.4.0 — PAUSE Midnight redesign and authenticated control room

- Replaced the old light-grey/red Tkinter UI with PAUSE Midnight and dedicated module layouts.
- Added local account sign-up/sign-in, settings, activity and provider status screens.
- Added browser extension popup, pairing/options page and three-state live demo.

## 0.3.0 — Download Guard and safer action handling

- Added browser download source checks and pending user decisions.
- Added local file metadata/signature checks and SHA-256 fingerprints.
- Added safer unknown states when checks cannot complete.

## 0.2.0 — Local accounts and interactive demo

- Added first-run local accounts, sign-in, password changes and account deletion.
- Added SAFE/WARNING/HIGH RISK training demo.

## 0.1.0 — Browser guard prototype

- Added local heuristic scanner, Chromium browser extension, domain lists and local activity history.
