@echo off
cd /d "%~dp0"
title PAUSE 1.0.7 - Local Safety Control Center
if not exist ".env" (
  if exist ".env.example" (
    copy /Y ".env.example" ".env" >nul
  ) else (
    echo GEMINI_API_KEY= > ".env"
  )
)
where python >nul 2>nul
if errorlevel 1 (
  echo Python 3.10 or newer is required. Install Python from python.org and try again.
  pause
  exit /b 1
)
echo.
echo  PAUSE 1.0.7
echo Gemini key file: %CD%\.env
echo Edit it with EDIT_GEMINI_KEY.bat if PAUSE AI is not configured.
echo.
python main.py
if errorlevel 1 pause
