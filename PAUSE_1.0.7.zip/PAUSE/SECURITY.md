# Security Policy

PAUSE is security-sensitive software. Do not send real private emails, message exports, passwords, OAuth tokens, or live malicious files in public bug reports.

## Reporting a vulnerability

When this project is published to its official GitHub repository, enable GitHub private vulnerability reporting / Security Advisories and use that private channel. Until that is configured, do not publish exploit details publicly; report the issue to the project maintainer privately.

## Safe testing

Use reserved `.test` domains and synthetic messages for demos. Do not use real people's inboxes or accounts without their explicit permission. Never disable Microsoft Defender or browser Safe Browsing to test PAUSE.

## Current status

The 0.5.0 build is a local security development release, not an audited antivirus or an independently certified security product. See `docs/SECURITY_AND_LIMITS.md` and `docs/PAUSE_1.0_ARCHITECTURE.md` before relying on it.
