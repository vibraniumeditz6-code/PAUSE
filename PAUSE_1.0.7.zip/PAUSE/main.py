"""PAUSE desktop launcher — opens the local-first control center."""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
import time
import webbrowser
from pathlib import Path

from pause_guard.engine import APP_VERSION
from pause_guard.assistant import PROJECT_ENV_PATH
from pause_guard.storage import Store
from pause_guard.server import LocalAPI

HOST = "127.0.0.1"
PORT = 8765


def open_app_window(url: str):
    candidates = []
    for env in ("PROGRAMFILES", "PROGRAMFILES(X86)", "LOCALAPPDATA"):
        base = os.environ.get(env)
        if base:
            candidates += [
                os.path.join(base, "Microsoft", "Edge", "Application", "msedge.exe"),
                os.path.join(base, "Google", "Chrome", "Application", "chrome.exe"),
            ]
    candidates += [shutil.which(x) or "" for x in ("msedge", "chrome", "google-chrome", "chromium")]
    for exe in candidates:
        if exe and os.path.exists(exe):
            try:
                subprocess.Popen([exe, f"--app={url}", "--window-size=1480,960", "--disable-features=TranslateUI"])
                return
            except OSError:
                continue
    webbrowser.open(url)


def main():
    store = Store()
    store.purge_old()
    api = LocalAPI(store)
    try:
        api.start()
    except OSError as exc:
        print(f"PAUSE could not start its local service: {exc}", file=sys.stderr)
        input("Press Enter to close…")
        return 1

    url = f"http://{HOST}:{PORT}/app"
    print(f"PAUSE {APP_VERSION} running at {url}")
    print("Local-only service is bound to 127.0.0.1. Keep this window open while using PAUSE.")
    print(f"Gemini key file: {PROJECT_ENV_PATH} (edit with EDIT_GEMINI_KEY.bat)")
    if "--headless" in sys.argv:
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            api.stop()
    else:
        open_app_window(url)
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            api.stop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
