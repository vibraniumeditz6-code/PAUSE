"""Opt-in Gmail OAuth integration for the PAUSE Windows desktop app.

Uses Google's installed-app OAuth flow with PKCE and Gmail readonly scope.
Refresh tokens are encrypted with Windows DPAPI; they are never written in
plaintext. Message bodies are analysed in memory and are not retained.
"""
from __future__ import annotations

import base64
import ctypes
import hashlib
import html
import json
import os
import secrets
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from email.utils import parseaddr
from html.parser import HTMLParser
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

from .engine import scan_email

GOOGLE_AUTH = "https://accounts.google.com/o/oauth2/v2/auth"
GOOGLE_TOKEN = "https://oauth2.googleapis.com/token"
GMAIL_API = "https://gmail.googleapis.com/gmail/v1/users/me"
GMAIL_SCOPE = "https://www.googleapis.com/auth/gmail.readonly"


class GmailIntegrationError(RuntimeError):
    pass


class _DataBlob(ctypes.Structure):
    _fields_ = [("cbData", ctypes.c_uint32), ("pbData", ctypes.POINTER(ctypes.c_ubyte))]


class DpapiVault:
    """Encrypt small secrets using the current Windows user's DPAPI context."""

    @staticmethod
    def _protect(data: bytes, unprotect: bool = False) -> bytes:
        if os.name != "nt":
            raise GmailIntegrationError("Secure Gmail token storage requires Windows DPAPI.")
        source = ctypes.create_string_buffer(data)
        in_blob = _DataBlob(len(data), ctypes.cast(source, ctypes.POINTER(ctypes.c_ubyte)))
        out_blob = _DataBlob()
        crypt32 = ctypes.WinDLL("crypt32", use_last_error=True)
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        blob_pointer = ctypes.POINTER(_DataBlob)
        kernel32.LocalFree.argtypes = [ctypes.c_void_p]
        kernel32.LocalFree.restype = ctypes.c_void_p
        crypt32.CryptProtectData.argtypes = [
            blob_pointer, ctypes.c_wchar_p, blob_pointer, ctypes.c_void_p,
            ctypes.c_void_p, ctypes.c_uint32, blob_pointer,
        ]
        crypt32.CryptProtectData.restype = ctypes.c_int
        crypt32.CryptUnprotectData.argtypes = [
            blob_pointer, ctypes.POINTER(ctypes.c_wchar_p), blob_pointer,
            ctypes.c_void_p, ctypes.c_void_p, ctypes.c_uint32, blob_pointer,
        ]
        crypt32.CryptUnprotectData.restype = ctypes.c_int
        description = ctypes.c_wchar_p()
        if unprotect:
            ok = crypt32.CryptUnprotectData(
                ctypes.byref(in_blob), ctypes.byref(description), None, None, None, 0x1,
                ctypes.byref(out_blob),
            )
        else:
            ok = crypt32.CryptProtectData(
                ctypes.byref(in_blob), "PAUSE Gmail OAuth tokens", None, None, None, 0x1,
                ctypes.byref(out_blob),
            )
        if description.value:
            kernel32.LocalFree(ctypes.cast(description, ctypes.c_void_p))
        if not ok:
            raise GmailIntegrationError("Windows could not protect the Gmail token store.")
        try:
            return ctypes.string_at(out_blob.pbData, out_blob.cbData)
        finally:
            kernel32.LocalFree(out_blob.pbData)

    def save(self, path: Path, payload: dict) -> None:
        raw = json.dumps(payload, separators=(",", ":")).encode("utf-8")
        encrypted = self._protect(raw, False)
        path.write_bytes(encrypted)
        try:
            path.chmod(0o600)
        except OSError:
            pass

    def load(self, path: Path) -> dict | None:
        if not path.exists():
            return None
        raw = self._protect(path.read_bytes(), True)
        value = json.loads(raw.decode("utf-8"))
        return value if isinstance(value, dict) else None

    @staticmethod
    def delete(path: Path) -> None:
        try:
            path.unlink(missing_ok=True)
        except OSError:
            pass


class _MailHTMLParser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.text_parts: list[str] = []
        self.links: list[str] = []

    def handle_starttag(self, tag, attrs):
        if tag.lower() == "a":
            href = dict(attrs).get("href", "")
            if href.startswith(("http://", "https://")):
                self.links.append(href)

    def handle_data(self, data):
        if data.strip():
            self.text_parts.append(data.strip())


class GmailIntegration:
    def __init__(self, store, on_result=None, vault=None):
        self.store = store
        self.on_result = on_result
        self.vault = vault or DpapiVault()
        self.token_path = store.data_dir / "gmail_tokens.dpapi"
        self.seen_path = store.data_dir / "gmail_seen.json"
        self._flow_lock = threading.RLock()
        self._flow = None
        self._tokens_cache = None
        self._email = ""
        self._last_error = ""
        self._last_scan_at = ""
        self._last_scan_count = 0
        self._last_alert_count = 0
        self._monitor_lock = threading.RLock()
        self._monitor_event = threading.Event()
        self._monitor_thread = None
        self._monitor_generation = 0
        self._monitor_enabled = False
        try:
            saved = self.vault.load(self.token_path)
            if saved:
                self._tokens_cache = saved
                self._email = str(saved.get("email", ""))
        except Exception as exc:
            self._last_error = str(exc)

    @staticmethod
    def _b64url(data: bytes) -> str:
        return base64.urlsafe_b64encode(data).decode("ascii").rstrip("=")

    @staticmethod
    def _read_json(url: str, token: str | None = None) -> dict:
        headers = {"Accept": "application/json", "User-Agent": "PAUSE-Desktop/1.0.0"}
        if token:
            headers["Authorization"] = f"Bearer {token}"
        req = urllib.request.Request(url, headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=20) as response:
                data = json.loads(response.read(2_000_000).decode("utf-8"))
            return data if isinstance(data, dict) else {}
        except urllib.error.HTTPError as exc:
            detail = ""
            try:
                payload = json.loads(exc.read(8192).decode("utf-8"))
                detail = payload.get("error", {}).get("message", "") if isinstance(payload.get("error"), dict) else payload.get("error_description", "")
            except Exception:
                pass
            raise GmailIntegrationError(f"HTTP {exc.code}: {detail or 'Google API request failed.'}") from exc
        except (urllib.error.URLError, TimeoutError, OSError) as exc:
            raise GmailIntegrationError("Could not reach Google. Check your internet connection and try again.") from exc

    @staticmethod
    def _post_form(url: str, values: dict) -> dict:
        encoded = urllib.parse.urlencode(values).encode("utf-8")
        req = urllib.request.Request(url, data=encoded, headers={
            "Content-Type": "application/x-www-form-urlencoded",
            "Accept": "application/json",
            "User-Agent": "PAUSE-Desktop/1.0.0",
        })
        try:
            with urllib.request.urlopen(req, timeout=25) as response:
                data = json.loads(response.read(1_000_000).decode("utf-8"))
            if not isinstance(data, dict):
                raise GmailIntegrationError("Google returned an invalid token response.")
            return data
        except urllib.error.HTTPError as exc:
            detail = ""
            try:
                payload = json.loads(exc.read(8192).decode("utf-8"))
                detail = payload.get("error_description") or payload.get("error") or ""
            except Exception:
                pass
            raise GmailIntegrationError(f"HTTP {exc.code}: {str(detail)[:300] or 'Google OAuth request failed.'}") from exc
        except (urllib.error.URLError, TimeoutError, OSError) as exc:
            raise GmailIntegrationError("Could not reach Google's OAuth service. Check your internet connection.") from exc

    def _save_tokens(self, tokens: dict) -> None:
        self.vault.save(self.token_path, tokens)
        self._tokens_cache = dict(tokens)

    def _load_tokens(self) -> dict:
        if self._tokens_cache:
            return self._tokens_cache
        try:
            loaded = self.vault.load(self.token_path)
        except Exception as exc:
            raise GmailIntegrationError(str(exc)) from exc
        if not loaded:
            raise GmailIntegrationError("Gmail is not connected. Choose Connect Gmail first.")
        self._tokens_cache = loaded
        return loaded

    def _refresh_access_token(self) -> str:
        tokens = self._load_tokens()
        if tokens.get("access_token") and float(tokens.get("expires_at", 0)) > time.time() + 45:
            return tokens["access_token"]
        refresh = tokens.get("refresh_token")
        client_id = str(self.store.settings.get("gmail_client_id", "")).strip()
        if not refresh or not client_id:
            raise GmailIntegrationError("Gmail authorisation has expired. Disconnect and connect again.")
        result = self._post_form(GOOGLE_TOKEN, {
            "client_id": client_id,
            "refresh_token": refresh,
            "grant_type": "refresh_token",
        })
        tokens.update(result)
        tokens["refresh_token"] = refresh
        tokens["expires_at"] = time.time() + max(60, int(result.get("expires_in", 3600)) - 60)
        self._save_tokens(tokens)
        return tokens["access_token"]

    def _gmail_get(self, path: str, query: dict | None = None) -> dict:
        token = self._refresh_access_token()
        url = f"{GMAIL_API}/{path.lstrip('/')}"
        if query:
            url += "?" + urllib.parse.urlencode(query, doseq=True)
        try:
            return self._read_json(url, token)
        except GmailIntegrationError as exc:
            if "HTTP 401" not in str(exc):
                raise
            self._tokens_cache = None
            token = self._refresh_access_token()
            return self._read_json(url, token)

    def status(self) -> dict:
        connected = bool(self._tokens_cache and self._tokens_cache.get("refresh_token"))
        return {
            "connected": connected,
            "email": self._email,
            "client_id_set": bool(str(self.store.settings.get("gmail_client_id", "")).strip()),
            "client_id": str(self.store.settings.get("gmail_client_id", "")),
            "token_storage_supported": os.name == "nt",
            "monitoring": self._monitor_enabled,
            "last_scan_at": self._last_scan_at,
            "last_scan_count": self._last_scan_count,
            "last_alert_count": self._last_alert_count,
            "last_error": self._last_error,
        }

    def start_auth(self, client_id: str) -> str:
        client_id = str(client_id or "").strip()
        if not client_id or len(client_id) > 300 or " " in client_id:
            raise GmailIntegrationError("Enter the OAuth Client ID from your Google Cloud Desktop app credentials.")
        if os.name != "nt":
            raise GmailIntegrationError("Secure Gmail OAuth token storage is enabled for Windows builds only (DPAPI).")
        self.store.save_settings({"gmail_client_id": client_id})
        state = secrets.token_urlsafe(28)
        verifier = self._b64url(secrets.token_bytes(48))
        challenge = self._b64url(hashlib.sha256(verifier.encode("ascii")).digest())
        owner = self

        class CallbackHandler(BaseHTTPRequestHandler):
            def log_message(self, fmt, *args):
                return

            def do_GET(self):
                params = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
                supplied_state = params.get("state", [""])[0]
                code = params.get("code", [""])[0]
                oauth_error = params.get("error", [""])[0]
                ok = False
                message = "PAUSE did not receive a valid Google authorisation response."
                if not secrets.compare_digest(supplied_state, state):
                    message = "Security check failed. Close this window and start Gmail connection again."
                elif oauth_error:
                    message = f"Google authorisation was not completed: {oauth_error[:120]}"
                elif code:
                    try:
                        token_response = owner._post_form(GOOGLE_TOKEN, {
                            "client_id": client_id,
                            "code": code,
                            "code_verifier": verifier,
                            "grant_type": "authorization_code",
                            "redirect_uri": redirect_uri,
                        })
                        access = token_response.get("access_token", "")
                        if not access:
                            raise GmailIntegrationError("Google did not return an access token.")
                        profile = owner._read_json(f"{GMAIL_API}/profile", access)
                        tokens = dict(token_response)
                        if not tokens.get("refresh_token") and owner._tokens_cache:
                            tokens["refresh_token"] = owner._tokens_cache.get("refresh_token", "")
                        if not tokens.get("refresh_token"):
                            raise GmailIntegrationError("Google did not issue a refresh token. Disconnect any existing PAUSE Google grant and connect again with consent.")
                        tokens["expires_at"] = time.time() + max(60, int(tokens.get("expires_in", 3600)) - 60)
                        tokens["email"] = str(profile.get("emailAddress", ""))
                        tokens["scope"] = str(token_response.get("scope", GMAIL_SCOPE))
                        owner._save_tokens(tokens)
                        owner._email = tokens["email"]
                        owner._last_error = ""
                        ok = True
                        message = f"Gmail connected successfully for {owner._email}. You can close this window and return to PAUSE."
                    except Exception as exc:
                        owner._last_error = str(exc)[:300]
                        message = owner._last_error
                body = ("<!doctype html><html><head><meta charset='utf-8'><title>PAUSE Gmail</title>"
                        "<meta name='viewport' content='width=device-width,initial-scale=1'>"
                        "<style>body{font:16px Segoe UI,Arial;background:#f5f8fc;color:#15243a;display:grid;place-items:center;min-height:100vh;margin:0}.card{max-width:560px;padding:36px;border:1px solid #dce6f1;border-radius:24px;background:white;box-shadow:0 20px 60px #18355a18}b{color:" + ("#12816f" if ok else "#b95b43") + "}</style></head><body><div class='card'><h2>PAUSE · Gmail connection</h2><p><b>" + ("Connected" if ok else "Not connected") + "</b></p><p>" + html_escape(message) + "</p></div></body></html>").encode("utf-8")
                self.send_response(200 if ok else 400)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Cache-Control", "no-store")
                self.send_header("X-Content-Type-Options", "nosniff")
                self.end_headers()
                self.wfile.write(body)
                threading.Thread(target=self.server.shutdown, daemon=True).start()

        callback = HTTPServer(("127.0.0.1", 0), CallbackHandler)
        callback.timeout = 300
        port = callback.server_address[1]
        redirect_uri = f"http://127.0.0.1:{port}/"
        with self._flow_lock:
            if self._flow and self._flow.get("server"):
                try:
                    self._flow["server"].shutdown()
                    self._flow["server"].server_close()
                except Exception:
                    pass
            self._flow = {"state": state, "server": callback, "started": time.time()}
        threading.Thread(target=callback.serve_forever, daemon=True, name="PAUSE-Gmail-OAuth").start()
        params = {
            "client_id": client_id,
            "redirect_uri": redirect_uri,
            "response_type": "code",
            "scope": GMAIL_SCOPE,
            "state": state,
            "code_challenge": challenge,
            "code_challenge_method": "S256",
            "access_type": "offline",
            "prompt": "consent",
            "include_granted_scopes": "true",
        }
        return GOOGLE_AUTH + "?" + urllib.parse.urlencode(params)

    def disconnect(self) -> dict:
        self.set_monitoring(False)
        tokens = self._tokens_cache
        if not tokens:
            try:
                tokens = self.vault.load(self.token_path)
            except Exception:
                tokens = None
        revoked = False
        revoke_error = ""
        token = (tokens or {}).get("refresh_token") or (tokens or {}).get("access_token")
        if token:
            try:
                encoded = urllib.parse.urlencode({"token": token}).encode("utf-8")
                req = urllib.request.Request(
                    "https://oauth2.googleapis.com/revoke", data=encoded,
                    headers={"Content-Type": "application/x-www-form-urlencoded", "User-Agent": "PAUSE-Desktop/1.0.0"},
                )
                with urllib.request.urlopen(req, timeout=15) as response:
                    revoked = response.status == 200
            except Exception as exc:
                # Always delete our local copy even when offline. The user can
                # additionally revoke PAUSE from their Google Account settings.
                revoke_error = str(exc)[:180]
        self.vault.delete(self.token_path)
        self._tokens_cache = None
        self._email = ""
        self._last_error = revoke_error
        return {"remote_revoked": revoked, "revoke_error": revoke_error}

    @staticmethod
    def _decode_part(data: str) -> str:
        if not data:
            return ""
        try:
            raw = base64.urlsafe_b64decode(data + "=" * (-len(data) % 4))
            return raw.decode("utf-8", errors="replace")
        except Exception:
            return ""

    @classmethod
    def _message_payload(cls, message: dict) -> dict:
        headers = {str(h.get("name", "")).lower(): str(h.get("value", ""))
                   for h in message.get("payload", {}).get("headers", [])}
        from_value = headers.get("from", "")
        sender_name, sender_email = parseaddr(from_value)
        subject = headers.get("subject", "")[:300]
        plain_parts: list[str] = []
        html_parts: list[str] = []
        links: list[str] = []
        attachments: list[str] = []

        def walk(part: dict):
            filename = str(part.get("filename", "")).strip()
            if filename:
                attachments.append(filename[:200])
            mime = str(part.get("mimeType", "")).lower()
            body = part.get("body", {}) or {}
            data = cls._decode_part(str(body.get("data", "")))
            if data:
                if mime == "text/plain":
                    plain_parts.append(data)
                elif mime == "text/html":
                    parser = _MailHTMLParser()
                    try:
                        parser.feed(data)
                        html_parts.append(" ".join(parser.text_parts))
                        links.extend(parser.links)
                    except Exception:
                        html_parts.append(html.unescape(data))
            for child in part.get("parts", []) or []:
                walk(child)

        walk(message.get("payload", {}) or {})
        body = "\n".join(plain_parts or html_parts)
        if links:
            body += "\nLinks in email HTML: " + " ".join(dict.fromkeys(links[:30]))
        return {
            "sender": sender_email or from_value,
            "sender_name": sender_name,
            "subject": subject,
            "body": body[:60000],
            "attachments": attachments[:30],
        }

    def _seen(self) -> set[str]:
        try:
            data = json.loads(self.seen_path.read_text(encoding="utf-8"))
            return set(data if isinstance(data, list) else [])
        except Exception:
            return set()

    def _mark_seen(self, message_id: str, seen: set[str]) -> None:
        seen.add(hashlib.sha256(message_id.encode("utf-8")).hexdigest())
        try:
            self.seen_path.write_text(json.dumps(sorted(seen)[-2000:]), encoding="utf-8")
            self.seen_path.chmod(0o600)
        except OSError:
            pass

    def scan_recent(self, limit: int = 20) -> dict:
        data = self._gmail_get("messages", {"maxResults": max(1, min(25, int(limit))), "q": "in:inbox newer_than:2d"})
        refs = data.get("messages", []) or []
        seen = self._seen()
        results = []
        alerts = 0
        for ref in refs:
            message_id = str(ref.get("id", ""))
            if not message_id:
                continue
            digest = hashlib.sha256(message_id.encode("utf-8")).hexdigest()
            if digest in seen:
                continue
            message = self._gmail_get("messages/" + urllib.parse.quote(message_id, safe=""), {"format": "full"})
            payload = self._message_payload(message)
            result = scan_email(payload, self.store.settings)
            sender_domain = result.get("host", "Sender not identified")
            result["kind"] = "gmail"
            result["target"] = f"Gmail message · {sender_domain}"
            result["summary"] = (
                f"A Gmail message from {sender_domain} was analysed locally. "
                f"{result.get('links_checked', 0)} link(s) checked. Subject and message body were not retained."
            )
            result.pop("link_results", None)
            result["source"] = "Gmail OAuth inbox scan"
            if result["level"] in {"WARNING", "HIGH RISK"}:
                alerts += 1
            if self.on_result:
                self.on_result(result)
            results.append({k: result.get(k) for k in ("level", "score", "host", "summary", "reasons", "kind")})
            self._mark_seen(message_id, seen)
        self._last_scan_at = time.strftime("%Y-%m-%d %H:%M:%S")
        self._last_scan_count = len(results)
        self._last_alert_count = alerts
        self._last_error = ""
        return {"scanned": len(results), "alerts": alerts, "results": results, "checked_at": self._last_scan_at}

    def set_monitoring(self, enabled: bool) -> dict:
        enabled = bool(enabled)
        if enabled and not self.status()["connected"]:
            raise GmailIntegrationError("Connect Gmail before enabling inbox monitoring.")
        with self._monitor_lock:
            self._monitor_generation += 1
            generation = self._monitor_generation
            # Signal any older worker. Each worker owns its own stop event, so a
            # quick off/on toggle cannot accidentally restart or stop the wrong one.
            self._monitor_event.set()
            self._monitor_enabled = enabled
            self._monitor_thread = None
            if enabled:
                stop_event = threading.Event()
                self._monitor_event = stop_event
                worker = threading.Thread(
                    target=self._monitor_loop,
                    args=(generation, stop_event),
                    daemon=True,
                    name="PAUSE-Gmail-Monitor",
                )
                self._monitor_thread = worker
                worker.start()
        return self.status()

    def _monitor_loop(self, generation: int, stop_event: threading.Event):
        # First pass is immediate. Monitoring is off by default and can only be
        # enabled after a deliberate opt-in in the PAUSE Connections screen.
        while not stop_event.is_set():
            with self._monitor_lock:
                if generation != self._monitor_generation or not self._monitor_enabled:
                    break
            try:
                self.scan_recent(20)
            except Exception as exc:
                self._last_error = str(exc)[:300]
            if stop_event.wait(120):
                break
        with self._monitor_lock:
            if generation == self._monitor_generation:
                self._monitor_enabled = False
                self._monitor_thread = None


def html_escape(value: str) -> str:
    return html.escape(str(value), quote=True)
