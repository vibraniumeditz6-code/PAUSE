"""PAUSE local-first desktop service.

The service binds only to loopback. The UI authenticates with revocable, time-limited device sessions stored as
SHA-256 token digests in SQLite; browser extensions use a separate pairing token.
Message text is analysed in memory and is never written to the activity log.
"""
from __future__ import annotations

import json
import secrets
import csv
import io
import mimetypes
from pathlib import Path
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from threading import Thread, RLock
from urllib.parse import urlparse, parse_qs

from .engine import scan_payload, scan_url, scan_email, APP_VERSION
from .downloads import scan_download_file
from .gmail import GmailIntegration, GmailIntegrationError
from .stories import build_threat_stories
from .assistant import AssistantIntegration, AssistantError
from .system_tools import get_device_snapshot, perform_power_action, DeviceActionError

WEB_DIR = Path(__file__).with_name("web")


class LocalAPI:
    def __init__(self, store, on_event=None, host="127.0.0.1", port=8765):
        self.store = store
        self.on_event = on_event
        self.host = host
        self.port = port
        self.httpd = None
        self.thread = None
        self.sessions: dict[str, dict] = {}
        self._session_lock = RLock()
        self.gmail = GmailIntegration(store, on_result=self._gmail_result)
        self.assistant = AssistantIntegration(store)

    def _gmail_result(self, result):
        """Persist only a redacted Gmail verdict; message contents are never logged."""
        safe_result = dict(result)
        safe_result["target"] = str(result.get("target", "Gmail message"))[:160]
        safe_result["summary"] = str(result.get("summary", "Gmail message analysed locally."))[:500]
        safe_result.pop("link_results", None)
        self.store.add_event(safe_result, source="Gmail OAuth inbox scan")
        self._notify(safe_result)

    def _session_user(self, token: str):
        # Sessions survive browser restarts and PAUSE service restarts. Only a
        # SHA-256 digest is stored in SQLite; the bearer token stays client-side.
        return self.store.get_session_account(token)

    def _new_session(self, account: dict):
        return self.store.create_session(account, lifetime_days=30)

    def _notify(self, result):
        if self.on_event:
            try:
                self.on_event(result)
            except Exception:
                pass

    def start(self):
        if self.httpd:
            return True
        owner = self

        class Handler(BaseHTTPRequestHandler):
            server_version = "PAUSE-Local/1.0.7"

            def log_message(self, fmt, *args):
                return

            def _headers(self, status=200, content_type="application/json; charset=utf-8"):
                self.send_response(status)
                self.send_header("Content-Type", content_type)
                self.send_header("Cache-Control", "no-store")
                self.send_header("X-Content-Type-Options", "nosniff")
                self.send_header("Referrer-Policy", "no-referrer")
                self.send_header("X-Frame-Options", "DENY")
                origin = self.headers.get("Origin", "")
                if origin.startswith(("chrome-extension://", "edge-extension://", "moz-extension://")):
                    self.send_header("Access-Control-Allow-Origin", origin)
                    self.send_header("Vary", "Origin")
                    self.send_header("Access-Control-Allow-Headers", "Content-Type, X-PAUSE-Token")
                    self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
                self.end_headers()

            def _json(self, obj, status=200):
                raw = json.dumps(obj, ensure_ascii=False).encode("utf-8")
                self._headers(status)
                self.wfile.write(raw)

            def _body(self):
                try:
                    length = int(self.headers.get("Content-Length", "0"))
                except ValueError:
                    length = 0
                if length < 0 or length > 120_000:
                    raise ValueError("Request too large.")
                try:
                    return json.loads(self.rfile.read(length) or b"{}")
                except Exception as exc:
                    raise ValueError("Invalid JSON.") from exc

            def _session(self):
                return owner._session_user(self.headers.get("X-PAUSE-Session", ""))

            def _extension_auth(self):
                supplied = self.headers.get("X-PAUSE-Token", "")
                return bool(supplied) and secrets.compare_digest(supplied, owner.store.token)

            def _authorized(self, extension_allowed=True):
                return bool(self._session() or (extension_allowed and self._extension_auth()))

            def _require_auth(self, extension_allowed=True):
                if not self._authorized(extension_allowed):
                    self._json({"error": "Please sign in to PAUSE."}, 401)
                    return False
                return True

            def do_OPTIONS(self):
                self._headers(204)

            def do_GET(self):
                parsed = urlparse(self.path)
                path = parsed.path
                if path in ("/", "/app", "/index.html"):
                    try:
                        raw = (WEB_DIR / "index.html").read_bytes()
                    except OSError:
                        return self._json({"error": "PAUSE interface files are missing."}, 500)
                    self._headers(200, "text/html; charset=utf-8")
                    self.wfile.write(raw)
                    return
                if path == "/favicon.svg":
                    svg = b'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" rx="18" fill="#11182c"/><path d="M32 9 50 17v13c0 12-7 20-18 25C21 50 14 42 14 30V17z" fill="none" stroke="#75e4dd" stroke-width="5"/><path d="m24 32 6 6 12-14" fill="none" stroke="#a78bfa" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/></svg>'
                    self._headers(200, "image/svg+xml")
                    self.wfile.write(svg)
                    return
                if path == "/pause-icon.png":
                    icon_path = Path(__file__).with_name("web") / "pause-icon.png"
                    if not icon_path.is_file():
                        return self._json({"error": "PAUSE icon is missing."}, 404)
                    self._headers(200, "image/png")
                    self.wfile.write(icon_path.read_bytes())
                    return
                if path == "/api/health":
                    return self._json({"ok": True, "service": "PAUSE", "version": APP_VERSION})
                if path == "/api/auth/status":
                    session = self._session()
                    return self._json({"has_account": owner.store.account_count() > 0,
                                        "logged_in": bool(session), "account": session,
                                        "version": APP_VERSION})
                if not self._require_auth():
                    return
                if path == "/api/overview":
                    events = owner.store.list_events(14)
                    stats = owner.store.stats()
                    counts = {"SAFE": 0, "WARNING": 0, "HIGH RISK": 0}
                    for event in events:
                        counts[event.get("level", "UNKNOWN")] = counts.get(event.get("level", "UNKNOWN"), 0) + 1
                    return self._json({"version": APP_VERSION, "stats": stats, "events": events,
                                       "recent_distribution": counts,
                                       "protection_enabled": owner.store.settings.get("protection_enabled", True)})
                if path == "/api/status":
                    return self._json({"ok": True, "version": APP_VERSION,
                                       "protection_enabled": owner.store.settings.get("protection_enabled", True),
                                       "stats": owner.store.stats()})
                if path == "/api/events":
                    query = parse_qs(parsed.query)
                    limit = min(500, max(1, int(query.get("limit", ["100"])[0])))
                    level = query.get("level", [""])[0].upper()
                    needle = query.get("q", [""])[0].lower()
                    items = owner.store.list_events(limit)
                    if level:
                        items = [e for e in items if e.get("level", "").upper() == level]
                    if needle:
                        items = [e for e in items if needle in (str(e.get("host", "")) + " " + str(e.get("target", "")) + " " + str(e.get("summary", ""))).lower()]
                    return self._json({"events": items})
                if path == "/api/threat-stories":
                    events = owner.store.list_events(500)
                    return self._json({"stories": build_threat_stories(events), "events_checked": len(events)})
                if path == "/api/settings":
                    return self._json({"settings": owner.store.settings})
                if path == "/api/token":
                    return self._json({"token": owner.store.token})
                if path == "/api/connections":
                    providers = provider_catalog()
                    gmail_status = owner.gmail.status()
                    if gmail_status.get("connected"):
                        providers["gmail"]["status"] = "connected"
                        providers["gmail"]["account"] = gmail_status.get("email", "")
                    return self._json({"providers": providers, "gmail": gmail_status})
                if path == "/api/gmail/status":
                    if not self._require_auth(False):
                        return
                    return self._json({"gmail": owner.gmail.status()})
                if path == "/api/assistant/status":
                    return self._json({"assistant": owner.assistant.status()})
                if path == "/api/device/snapshot":
                    return self._json({"device": get_device_snapshot()})
                if path == "/api/events/export":
                    output = io.StringIO()
                    writer = csv.writer(output)
                    writer.writerow(["created_at", "level", "kind", "host", "score", "action", "summary", "source"])
                    for event in owner.store.list_events(500):
                        writer.writerow([event.get(k, "") for k in ("created_at", "level", "kind", "host", "score", "action", "summary", "source")])
                    self._headers(200, "text/csv; charset=utf-8")
                    self.wfile.write(output.getvalue().encode("utf-8"))
                    return
                return self._json({"error": "Not found"}, 404)

            def do_POST(self):
                # Reject cross-origin browser writes to the loopback service. The
                # desktop UI is same-origin; the extension uses its own scheme
                # and a separate pairing token. Requests with no Origin (for
                # local tests/CLI clients) still rely on endpoint authentication.
                origin = self.headers.get("Origin", "")
                path = urlparse(self.path).path
                active_port = self.server.server_port
                trusted_origins = {
                    f"http://{owner.host}:{active_port}",
                    f"http://localhost:{active_port}",
                }
                is_extension_origin = origin.startswith((
                    "chrome-extension://", "edge-extension://", "moz-extension://"
                ))
                extension_routes = {"/api/scan", "/api/download/file-scan", "/api/assistant/chat", "/api/device/snapshot", "/api/device/action"}
                extension_write = is_extension_origin and path in extension_routes
                if origin and origin not in trusted_origins and not extension_write:
                    return self._json({"error": "Cross-origin requests are not allowed."}, 403)

                try:
                    payload = self._body()
                except ValueError as exc:
                    return self._json({"error": str(exc)}, 400)
                if not isinstance(payload, dict):
                    return self._json({"error": "Expected an object."}, 400)

                if path == "/api/auth/signup":
                    if owner.store.account_count() > 0:
                        return self._json({"error": "A local account already exists. Sign in instead."}, 409)
                    try:
                        account = owner.store.create_account(payload.get("display_name", ""),
                                                             payload.get("email", ""), payload.get("password", ""))
                        token = owner._new_session(account)
                        return self._json({"ok": True, "session": token, "account": account})
                    except ValueError as exc:
                        return self._json({"error": str(exc)}, 400)

                if path == "/api/auth/login":
                    try:
                        account = owner.store.sign_in(payload.get("email", ""), payload.get("password", ""))
                        token = owner._new_session(account)
                        return self._json({"ok": True, "session": token, "account": account})
                    except ValueError as exc:
                        return self._json({"error": str(exc)}, 401)

                if path == "/api/auth/logout":
                    token = self.headers.get("X-PAUSE-Session", "")
                    owner.store.revoke_session(token)
                    owner.store.sign_out()
                    return self._json({"ok": True})

                if path == "/api/auth/profile":
                    if not self._require_auth(False):
                        return
                    try:
                        account = owner.store.update_account_profile(payload.get("display_name", ""), payload.get("email", ""))
                        return self._json({"ok": True, "account": account})
                    except ValueError as exc:
                        return self._json({"error": str(exc)}, 400)

                if path == "/api/auth/password":
                    if not self._require_auth(False):
                        return
                    try:
                        owner.store.change_account_password(payload.get("current_password", ""), payload.get("new_password", ""))
                        return self._json({"ok": True})
                    except ValueError as exc:
                        return self._json({"error": str(exc)}, 400)

                if path == "/api/auth/delete":
                    if not self._require_auth(False):
                        return
                    try:
                        owner.store.delete_current_account(payload.get("password", ""))
                        token = self.headers.get("X-PAUSE-Session", "")
                        owner.store.revoke_session(token)
                        return self._json({"ok": True})
                    except ValueError as exc:
                        return self._json({"error": str(exc)}, 400)

                if path == "/api/scan":
                    if not self._extension_auth():
                        return self._json({"error": "Browser extension pairing token missing or invalid."}, 401)
                    if not owner.store.settings.get("protection_enabled", True):
                        return self._json({"level": "PAUSED", "action": "allow", "reasons": ["Protection is turned off in PAUSE settings."], "score": 0})
                    result = scan_payload(payload, owner.store.settings)
                    if result.get("level") == "HIGH RISK" and not owner.store.settings.get("block_high_risk", True):
                        result["action"] = "warn"
                    if result.get("level") == "WARNING" and not owner.store.settings.get("warn_on_suspicious", True):
                        result["action"] = "allow"
                    result["event_id"] = owner.store.add_event(result, source=str(payload.get("source", "browser")))
                    owner._notify(result)
                    return self._json(result)

                if path == "/api/messages/analyse":
                    if not self._require_auth(False):
                        return
                    if not owner.store.settings.get("protection_enabled", True):
                        return self._json({"level": "PAUSED", "action": "allow", "score": 0,
                                           "reasons": ["Protection is turned off in PAUSE settings."]})
                    result = scan_email(payload, owner.store.settings)
                    result["kind"] = payload.get("channel", "message")
                    # Never store message bodies, subjects, or full sender addresses.
                    safe_result = dict(result)
                    safe_result["target"] = str(result.get("host") or "Message analysed")
                    safe_result["summary"] = f"A {payload.get('channel', 'message')} was analysed locally. {result.get('links_checked', 0)} link(s) checked. Message text was not retained."
                    result["event_id"] = owner.store.add_event(safe_result, source=f"{payload.get('channel', 'message')} scan")
                    owner._notify(result)
                    result.pop("link_results", None)
                    return self._json(result)

                if path == "/api/toolkit/url":
                    if not self._require_auth(False):
                        return
                    result = scan_url(str(payload.get("url", "")), owner.store.settings, display_text=str(payload.get("display_text", "")))
                    result["event_id"] = owner.store.add_event(result, source="manual URL inspection")
                    return self._json(result)

                if path == "/api/download/file-scan":
                    # The paired extension uses its token; the desktop app may
                    # also inspect a user-selected file under its local session.
                    if not self._require_auth():
                        return
                    if not owner.store.settings.get("protection_enabled", True) or not owner.store.settings.get("scan_downloads", True):
                        return self._json({"level": "PAUSED", "action": "allow", "reasons": ["Download inspection is disabled in PAUSE settings."], "score": 0})
                    if not payload.get("path"):
                        return self._json({"error": "A completed download path is required."}, 400)
                    result = scan_download_file(str(payload.get("path", "")), owner.store.settings,
                                                chrome_danger=payload.get("chrome_danger"))
                    result["event_id"] = owner.store.add_event(result, source="browser download file scan")
                    owner._notify(result)
                    return self._json(result)

                if path == "/api/assistant/config":
                    if not self._require_auth(False):
                        return
                    return self._json({
                        "error": "In-app Gemini key saving has been retired. Edit the project .env file with EDIT_GEMINI_KEY.bat instead."
                    }, 410)

                if path == "/api/assistant/test":
                    if not self._require_auth(False):
                        return
                    try:
                        return self._json(owner.assistant.test_connection())
                    except AssistantError as exc:
                        return self._json({"error": str(exc)}, 400)

                if path == "/api/assistant/chat":
                    if not self._require_auth():
                        return
                    try:
                        result = owner.assistant.chat(
                            payload.get("question", ""), payload.get("context"),
                            payload.get("history", []), bool(payload.get("web_search", False)),
                        )
                        return self._json({"ok": True, **result})
                    except AssistantError as exc:
                        return self._json({"error": str(exc)}, 400)

                if path == "/api/device/action":
                    if not self._require_auth():
                        return
                    try:
                        result = perform_power_action(payload.get("action", ""), confirmed=payload.get("confirmed") is True)
                        return self._json(result)
                    except DeviceActionError as exc:
                        return self._json({"error": str(exc)}, 400)

                if path == "/api/gmail/connect":
                    if not self._require_auth(False):
                        return
                    try:
                        auth_url = owner.gmail.start_auth(payload.get("client_id", ""))
                        return self._json({"ok": True, "authorization_url": auth_url,
                                           "message": "Complete Google consent in the browser window opened by PAUSE."})
                    except GmailIntegrationError as exc:
                        return self._json({"error": str(exc)}, 400)

                if path == "/api/gmail/scan":
                    if not self._require_auth(False):
                        return
                    try:
                        result = owner.gmail.scan_recent(payload.get("limit", 20))
                        return self._json({"ok": True, **result, "gmail": owner.gmail.status()})
                    except (GmailIntegrationError, ValueError) as exc:
                        return self._json({"error": str(exc)}, 400)

                if path == "/api/gmail/monitor":
                    if not self._require_auth(False):
                        return
                    try:
                        result = owner.gmail.set_monitoring(payload.get("enabled", False))
                        owner.store.save_settings({"gmail_monitor_enabled": result.get("monitoring", False)})
                        return self._json({"ok": True, "gmail": result})
                    except GmailIntegrationError as exc:
                        return self._json({"error": str(exc)}, 400)

                if path == "/api/gmail/disconnect":
                    if not self._require_auth(False):
                        return
                    revoke = owner.gmail.disconnect()
                    owner.store.save_settings({"gmail_monitor_enabled": False})
                    return self._json({"ok": True, "gmail": owner.gmail.status(), **revoke})

                if path == "/api/settings/update":
                    if not self._require_auth(False):
                        return
                    settings = owner.store.save_settings(payload)
                    return self._json({"settings": settings})

                if path == "/api/events/clear":
                    if not self._require_auth(False):
                        return
                    owner.store.clear_events()
                    return self._json({"ok": True})

                if path == "/api/token/rotate":
                    if not self._require_auth(False):
                        return
                    owner.store.token = secrets.token_urlsafe(24)
                    owner.store.token_path.write_text(owner.store.token, encoding="utf-8")
                    try:
                        owner.store.token_path.chmod(0o600)
                    except OSError:
                        pass
                    return self._json({"ok": True, "token": owner.store.token})

                if path == "/api/connections/intent":
                    if not self._require_auth(False):
                        return
                    key = str(payload.get("provider", ""))
                    catalog = provider_catalog()
                    item = catalog.get(key)
                    if not item:
                        return self._json({"error": "Unknown provider."}, 404)
                    # Never claim an OAuth connection is established without a configured,
                    # verified provider flow and an explicit consent callback.
                    return self._json({"ok": False, "status": item["status"],
                                       "provider": key, "message": item["setup_message"],
                                       "requirements": item["requirements"]})

                return self._json({"error": "Not found"}, 404)

        self.httpd = ThreadingHTTPServer((self.host, self.port), Handler)
        self.httpd.daemon_threads = True
        self.thread = Thread(target=self.httpd.serve_forever, daemon=True)
        self.thread.start()
        # Resume only a previously user-enabled monitor, and only when the
        # encrypted Gmail refresh token is present and decryptable on this device.
        if self.store.settings.get("gmail_monitor_enabled", False):
            try:
                if self.gmail.status().get("connected"):
                    self.gmail.set_monitoring(True)
                else:
                    self.store.save_settings({"gmail_monitor_enabled": False})
            except GmailIntegrationError:
                self.store.save_settings({"gmail_monitor_enabled": False})
        return True

    def stop(self):
        # Stop the worker but preserve the saved opt-in so it can resume when
        # the user starts PAUSE again. No worker is left running after shutdown.
        self.gmail.set_monitoring(False)
        if self.httpd:
            self.httpd.shutdown()
            self.httpd.server_close()
            self.httpd = None


def provider_catalog():
    """Honest capability catalogue; no provider is shown as connected by default."""
    return {
        "gmail": {
            "name": "Gmail", "vendor": "Google", "status": "setup_required", "mode": "OAuth 2.0",
            "capability": "Inbox metadata and message content only after explicit Google OAuth consent.",
            "setup_message": "Gmail OAuth is implemented with PKCE and the read-only Gmail scope. Add your Google Desktop OAuth Client ID, then approve access in Google. Secure token storage uses Windows DPAPI.",
            "requirements": ["Create a Google Cloud project and enable the Gmail API", "Configure the OAuth consent screen and add your account as a test user if the app is in testing", "Create a Desktop app OAuth client ID", "Use the Connect Gmail button and review the gmail.readonly consent"]
        },
        "outlook": {
            "name": "Outlook / Hotmail", "vendor": "Microsoft", "status": "setup_required", "mode": "Microsoft Graph OAuth",
            "capability": "Mail change notifications and message analysis with user-approved Graph permissions.",
            "setup_message": "Outlook and Hotmail need a Microsoft Entra app registration and Graph permissions. No tenant/client ID is configured yet.",
            "requirements": ["Register a public-client app in Microsoft Entra", "Configure delegated Mail.Read permissions", "Implement token refresh and revocation", "Complete a verified Graph change-notification callback"]
        },
        "whatsapp_personal": {
            "name": "WhatsApp Personal", "vendor": "Meta", "status": "not_supported", "mode": "No public consumer inbox API",
            "capability": "Personal chats cannot be silently read or blocked through an official public API.",
            "setup_message": "Meta does not provide a supported public API for reading and intercepting ordinary personal WhatsApp chats. PAUSE will not scrape the app or request QR/session tokens.",
            "requirements": ["Optional future: user-approved Windows notification-preview analysis", "Only preview text actually exposed by Windows will be available", "Alerts cannot stop the sender delivering a message"]
        },
        "whatsapp_business": {
            "name": "WhatsApp Business", "vendor": "Meta", "status": "setup_required", "mode": "WhatsApp Business Cloud API",
            "capability": "Business-number messages delivered to a configured webhook, with documented business permissions.",
            "setup_message": "WhatsApp Business needs a Meta Business app, phone-number registration, access token and a publicly reachable webhook. This local-only build has none configured.",
            "requirements": ["Create a Meta developer app and WhatsApp Business account", "Register a business phone number and system-user token", "Host and verify a secure webhook endpoint", "Subscribe to supported message events and apply retention controls"]
        },
        "teams": {
            "name": "Microsoft Teams", "vendor": "Microsoft", "status": "planned", "mode": "Microsoft Graph / Teams APIs",
            "capability": "Future opt-in integration where API permissions and policy allow.",
            "setup_message": "Teams integration is not configured in this build.",
            "requirements": ["Microsoft Entra app registration", "Minimum required Graph permissions", "Admin/user consent and webhook lifecycle"]
        }
    }
