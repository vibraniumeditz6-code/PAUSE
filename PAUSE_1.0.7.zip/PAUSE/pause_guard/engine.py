"""Local, heuristic risk analysis for PAUSE Guard.

This engine is deliberately transparent: it identifies indicators, not certainty.
It does not contact reputation services or upload inspected content.
"""
from __future__ import annotations

import ipaddress
import re
from urllib.parse import urlparse, parse_qs, unquote

APP_VERSION = "1.0.7"

SHORTENERS = {
    "bit.ly", "t.co", "tinyurl.com", "ow.ly", "is.gd", "buff.ly",
    "cutt.ly", "rebrand.ly", "shorturl.at", "rb.gy"
}
SUSPICIOUS_TLDS = {"zip", "mov", "top", "click", "country", "gq", "tk", "work"}
SUSPICIOUS_HOST_WORDS = {
    "verify", "wallet", "secure-login", "account-update", "password-reset",
    "signin-alert", "gift-card", "invoice-payment", "recover-account"
}
BAD_DEMO_MARKERS = {"phishing.test", "malware.test", "fake-login.test", "credential-theft.test"}
URL_PATTERN = re.compile(r"https?://[^\s<>\]\[()\"']+", re.IGNORECASE)
EMAIL_PATTERN = re.compile(r"[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}", re.IGNORECASE)


def _unique(items):
    seen = set()
    result = []
    for item in items:
        if item not in seen:
            seen.add(item)
            result.append(item)
    return result


def _normalise_url(value: str) -> str:
    value = (value or "").strip()
    if not value:
        return ""
    if not re.match(r"^[a-zA-Z][a-zA-Z0-9+.-]*://", value):
        value = "https://" + value
    return value


def scan_url(url: str, settings: dict | None = None, context: str = "link", display_text: str = "") -> dict:
    settings = settings or {}
    url = _normalise_url(url)
    reasons: list[str] = []
    score = 0
    try:
        parsed = urlparse(url)
        host = (parsed.hostname or "").lower().rstrip(".")
    except ValueError:
        parsed = urlparse("")
        host = ""
        score += 50
        reasons.append("The address has invalid authority syntax and could not be parsed safely.")
    display_host = host or "Unrecognised destination"
    try:
        explicit_port = parsed.port
        port_display = explicit_port if explicit_port is not None else (443 if parsed.scheme.lower() == "https" else 80 if parsed.scheme.lower() == "http" else None)
    except ValueError:
        explicit_port = None
        port_display = "Invalid port"
        score += 18
        reasons.append("The address contains an invalid port number.")

    if not host:
        score += 50
        reasons.append("The destination could not be parsed as a normal web address.")
    else:
        if parsed.username or parsed.password:
            score += 50
            reasons.append("The address contains embedded sign-in credentials, which can disguise the real destination.")
        try:
            ipaddress.ip_address(host.strip("[]"))
            score += 25
            reasons.append("The link points directly to an IP address instead of a recognisable domain.")
        except ValueError:
            pass
        if "xn--" in host:
            score += 22
            reasons.append("The domain uses internationalised/punycode characters that can be used in look-alike addresses.")
        if host in SHORTENERS:
            score += 15
            reasons.append("This is a shortened link, so its final destination is hidden until it is opened.")
        if any(marker in host for marker in BAD_DEMO_MARKERS):
            score += 80
            reasons.append("The domain matches a PAUSE demonstration threat indicator (reserved .test example).")
        host_labels = host.split(".")
        if len(host_labels) >= 5:
            score += 10
            reasons.append("The address has an unusually deep subdomain chain.")
        matching_words = [word for word in SUSPICIOUS_HOST_WORDS if word in host]
        if matching_words:
            score += min(18, len(matching_words) * 8)
            reasons.append("The domain contains account/security/payment wording often used in imitation sites.")
        tld = host_labels[-1] if len(host_labels) > 1 else ""
        if tld in SUSPICIOUS_TLDS:
            score += 6
            reasons.append(f"The .{tld} domain ending is less commonly encountered; this alone does not prove danger.")

    # User-managed rules. A block rule is intentionally decisive; a trusted rule only
    # reduces low-confidence scores and never suppresses a critical indicator.
    blocked_domains = [str(x).lower().strip().lstrip(".") for x in settings.get("custom_block_domains", []) if str(x).strip()]
    trusted_domains = [str(x).lower().strip().lstrip(".") for x in settings.get("trusted_domains", []) if str(x).strip()]
    if host and any(host == d or host.endswith("." + d) for d in blocked_domains):
        score += 90
        reasons.append("This domain is on your personal PAUSE block list.")
    if host and any(host == d or host.endswith("." + d) for d in trusted_domains) and score < 30:
        score = max(0, score - 10)
        reasons.append("This domain is on your personal trusted list; only low-confidence warnings are reduced.")

    if parsed.scheme.lower() == "http":
        score += 15
        reasons.append("The connection uses HTTP rather than HTTPS, so the connection is not encrypted in transit.")
    elif parsed.scheme.lower() not in {"https", "http"}:
        score += 15
        reasons.append("The link uses an unusual protocol.")

    if len(url) > 180:
        score += 5
        reasons.append("The link is unusually long and may contain tracking or redirect information.")

    query = parse_qs(parsed.query)
    redirect_details = []
    for key in ("url", "redirect", "redirect_uri", "next", "continue", "return", "return_to", "dest", "target"):
        values = query.get(key)
        if not values:
            continue
        decoded = unquote(str(values[0]))[:2048]
        candidate = _normalise_url(decoded)
        target = urlparse(candidate)
        target_host = (target.hostname or "").lower().rstrip(".")
        if target_host:
            redirect_details.append({"parameter": key, "destination_host": target_host,
                                     "different_host": bool(host and target_host != host)})
            if target_host != host:
                score += 12
                reasons.append("The link contains a redirect parameter that may send you to another domain.")
                break

    # If the link itself displays a URL, compare that claimed destination with
    # its actual href. Ordinary descriptive text is not treated as a mismatch.
    visible_text = str(display_text or "").strip()[:180]
    visible_url = ""
    if visible_text:
        visible_matches = URL_PATTERN.findall(visible_text)
        if visible_matches:
            visible_url = visible_matches[0].rstrip(".,;:)")
        elif re.fullmatch(r"(?i)(?:www\.)?(?:[a-z0-9-]+\.)+[a-z]{2,}(?::[0-9]{1,5})?(?:/[^\s]*)?", visible_text):
            visible_url = visible_text
    visible_host = ""
    if visible_url:
        visible_host = (urlparse(_normalise_url(visible_url)).hostname or "").lower().rstrip(".")
        related_host = bool(visible_host and host and (
            host == visible_host or host.endswith("." + visible_host) or visible_host.endswith("." + host)
        ))
        if visible_host and host and not related_host:
            score += 28
            reasons.append(f"The visible link text points to {visible_host}, but the actual destination is {host}.")

    # A low score means no known heuristic fired. It is not a reputation certificate.
    if score >= int(settings.get("high_risk_threshold", 45)):
        level = "HIGH RISK"
        action = "block"
    elif score >= int(settings.get("warning_threshold", 15)):
        level = "WARNING"
        action = "warn"
    else:
        level = "SAFE"
        action = "allow"

    if not reasons:
        reasons.append("No configured risk indicators were detected in this address.")
    title = ""
    description = f"Destination: {display_host}. "
    if parsed.scheme:
        description += f"Connection: {parsed.scheme.upper()}. "
    description += "The page publisher and creation date are not independently verified by this local scan."

    xray = {
        "scheme": parsed.scheme.lower() or "unknown",
        "destination_host": display_host,
        "port": port_display,
        "path": parsed.path or "/",
        "query_parameters": sorted(set(query.keys()))[:20],
        "redirect_candidates": redirect_details[:6],
        "visible_text": visible_text,
        "visible_host": visible_host or None,
        "visible_destination_match": (bool(host == visible_host or host.endswith("." + visible_host) or visible_host.endswith("." + host))) if visible_host else None,
        "embedded_credentials": bool(parsed.username or parsed.password),
        "contains_fragment": bool(parsed.fragment),
        "reputation_lookup": "not_configured",
        "redirect_chain_status": "not_resolved_live",
    }
    return {
        "level": level,
        "action": action,
        "score": min(score, 100),
        "kind": context,
        "target": url,
        "host": display_host,
        "title": title,
        "summary": description,
        "reasons": _unique(reasons),
        "xray": xray,
    }


def scan_email(payload: dict, settings: dict | None = None) -> dict:
    settings = settings or {}
    body = str(payload.get("body", ""))[:60000]
    subject = str(payload.get("subject", ""))[:300]
    sender = str(payload.get("sender", ""))[:300]
    sender_name = str(payload.get("sender_name", ""))[:160]
    combined = (subject + "\n" + body).lower()
    reasons: list[str] = []
    score = 0

    urgency_patterns = [
        (r"act now|immediately|within 24 hours|urgent action|required immediately|final warning", 12,
         "The message uses urgency or pressure language."),
        (r"account.{0,25}(suspend|locked|disabled)|suspend.{0,20}account|unusual sign.?in", 14,
         "The message claims an account is locked, suspended, or under unusual activity."),
        (r"verify.{0,25}(account|identity|password)|confirm.{0,25}(account|identity)|update your password", 14,
         "The message asks you to verify or update account information."),
        (r"password|one.time password|\botp\b|2fa code|verification code", 18,
         "The message mentions passwords or one-time verification codes; never share these with a sender."),
        (r"gift.?cards?|crypto(currency)?|wire transfer|bank transfer|payment.{0,20}today", 18,
         "The message requests a payment method commonly abused in scams."),
        (r"keep this confidential|do not tell anyone|don't tell anyone", 10,
         "The sender asks for secrecy, which can be a social-engineering warning sign."),
    ]
    for pattern, points, reason in urgency_patterns:
        if re.search(pattern, combined, re.IGNORECASE):
            score += points
            reasons.append(reason)

    # Flag executable/script-like attachments by filename only; do not open files.
    attachments = payload.get("attachments", [])
    if isinstance(attachments, list):
        risky_ext = {".exe", ".scr", ".bat", ".cmd", ".js", ".vbs", ".ps1", ".msi", ".com"}
        found = [str(a) for a in attachments[:30] if any(str(a).lower().endswith(ext) for ext in risky_ext)]
        if found:
            score += 55
            reasons.append("The email lists an executable or script-like attachment. Do not open it unless you independently expected it.")

    links = URL_PATTERN.findall(body)
    link_results = []
    for link in links[:20]:
        result = scan_url(link, settings, context="email link")
        link_results.append(result)
        if result["level"] == "HIGH RISK":
            score += 30
            reasons.append(f"A link in the message has high-risk indicators ({result['host']}).")
        elif result["level"] == "WARNING":
            score += 12
            reasons.append(f"A link in the message has warning indicators ({result['host']}).")

    sender_email = EMAIL_PATTERN.search(sender)
    if sender_email:
        sender_domain = sender_email.group(0).split("@", 1)[1].lower()
        brand_pairs = {
            "microsoft": {"microsoft.com", "accountprotection.microsoft.com"},
            "google": {"google.com", "accounts.google.com"},
            "apple": {"apple.com", "id.apple.com"},
            "amazon": {"amazon.com", "amazon.in", "amazon.co.uk"},
            "paypal": {"paypal.com"},
        }
        for brand, trusted_domains in brand_pairs.items():
            if brand in sender_name.lower() and sender_domain not in trusted_domains:
                score += 24
                reasons.append(f"The sender display name mentions {brand.title()}, but the email address uses a different domain.")
                break

    if not links and not reasons:
        reasons.append("No configured phishing indicators were found in the supplied message text.")

    if score >= int(settings.get("high_risk_threshold", 45)):
        level, action = "HIGH RISK", "block"
    elif score >= int(settings.get("warning_threshold", 15)):
        level, action = "WARNING", "warn"
    else:
        level, action = "SAFE", "allow"

    return {
        "level": level,
        "action": action,
        "score": min(score, 100),
        "kind": "email",
        "target": sender or subject or "Email message",
        "host": sender_email.group(0).split("@", 1)[1] if sender_email else "Sender not identified",
        "summary": f"Sender: {sender or '(not identified)'}. Links checked: {len(links[:20])}. Message content is processed locally and is not saved in the activity log.",
        "reasons": _unique(reasons),
        "links_checked": len(links[:20]),
        "link_results": link_results,
    }


def scan_payload(payload: dict, settings: dict | None = None) -> dict:
    kind = str(payload.get("type", "url")).lower()
    if kind == "email":
        return scan_email(payload, settings)
    return scan_url(str(payload.get("url", "")), settings, context=kind, display_text=str(payload.get("display_text", "")))
