"""Small, consent-based Windows device helpers for PAUSE AI."""
from __future__ import annotations

import ctypes
import os
import re
import subprocess


class DeviceActionError(RuntimeError):
    pass


def wifi_networks() -> list[dict]:
    """Return SSID/security labels visible to the Windows Wi-Fi adapter; never keys."""
    if os.name != "nt":
        return []
    try:
        result = subprocess.run(["netsh", "wlan", "show", "networks", "mode=bssid"],
                                capture_output=True, text=True, timeout=8, check=False)
    except (OSError, subprocess.TimeoutExpired):
        return []
    networks, current = [], None
    for line in result.stdout.splitlines():
        match = re.match(r"\s*SSID\s+\d+\s*:\s*(.*)$", line, re.I)
        if match:
            if current and current["ssid"]:
                networks.append(current)
            current = {"ssid": match.group(1).strip(), "security": "Not reported"}
            continue
        if current:
            auth = re.match(r"\s*Authentication\s*:\s*(.*)$", line, re.I)
            if auth:
                current["security"] = auth.group(1).strip()[:80]
    if current and current["ssid"]:
        networks.append(current)
    seen, clean = set(), []
    for item in networks:
        key = item["ssid"].casefold()
        if key not in seen:
            seen.add(key)
            clean.append(item)
    return clean[:40]


def known_bluetooth_devices() -> list[dict]:
    """List Windows-known Bluetooth devices; does not scan nearby strangers."""
    if os.name != "nt":
        return []
    command = "Get-PnpDevice -Class Bluetooth -ErrorAction SilentlyContinue | Where-Object {$_.Status -eq 'OK'} | Select-Object -ExpandProperty FriendlyName"
    try:
        result = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", command],
                                capture_output=True, text=True, timeout=8, check=False)
    except (OSError, subprocess.TimeoutExpired):
        return []
    return [{"name": line.strip()} for line in result.stdout.splitlines() if line.strip()][:30]


def get_device_snapshot() -> dict:
    if os.name != "nt":
        return {"platform": os.name, "wifi_networks": [], "bluetooth_known_devices": [],
                "note": "Windows device discovery is available only on Windows."}
    return {"platform": "Windows", "wifi_networks": wifi_networks(),
            "bluetooth_known_devices": known_bluetooth_devices(),
            "note": "Wi-Fi names are networks currently visible to this adapter. Bluetooth entries are Windows-known devices, not a live scan of nearby devices."}


def perform_power_action(action: str, confirmed: bool = False) -> dict:
    """Perform only explicit, fixed device power actions. Never accepts shell text."""
    action = str(action or "").lower().strip()
    if action not in {"shutdown", "restart", "sleep", "cancel"}:
        raise DeviceActionError("Unsupported device action.")
    if not confirmed:
        raise DeviceActionError("Confirm the action in PAUSE before it can run.")
    if os.name != "nt":
        raise DeviceActionError("Device power actions are available only on Windows.")
    if action == "cancel":
        result = subprocess.run(["shutdown.exe", "/a"], capture_output=True, text=True, timeout=5, check=False)
        if result.returncode != 0:
            raise DeviceActionError("There is no scheduled shutdown or restart to cancel.")
        return {"ok": True, "message": "Scheduled shutdown/restart cancelled."}
    if action == "shutdown":
        subprocess.Popen(["shutdown.exe", "/s", "/t", "60"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return {"ok": True, "message": "Shutdown scheduled in 60 seconds. Use Cancel power action to stop it."}
    if action == "restart":
        subprocess.Popen(["shutdown.exe", "/r", "/t", "60"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return {"ok": True, "message": "Restart scheduled in 60 seconds. Use Cancel power action to stop it."}
    # Sleep is intentionally immediate only after the explicit confirmation step.
    try:
        powrprof = ctypes.WinDLL("PowrProf")
        powrprof.SetSuspendState.argtypes = [ctypes.c_bool, ctypes.c_bool, ctypes.c_bool]
        powrprof.SetSuspendState.restype = ctypes.c_bool
        if not powrprof.SetSuspendState(False, False, False):
            raise DeviceActionError("Windows could not enter sleep mode. Check power settings.")
    except (AttributeError, OSError) as exc:
        raise DeviceActionError("Windows sleep API is unavailable on this device.") from exc
    return {"ok": True, "message": "Windows is entering sleep mode."}
