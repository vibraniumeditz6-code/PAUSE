"""Local post-download metadata inspection for PAUSE.

This module never executes, extracts, previews, or deletes downloaded files.
It checks path scope, file size, SHA-256, filename indicators, file signatures,
and the browser's own danger classification. A clean result is not a malware
verdict and does not replace Microsoft Defender or browser Safe Browsing.
"""
from __future__ import annotations

import hashlib
import mimetypes
from pathlib import Path

MAX_SCAN_BYTES = 250 * 1024 * 1024
EXECUTABLE_EXTENSIONS = {".exe", ".dll", ".scr", ".com", ".msi", ".bat", ".cmd", ".ps1", ".vbs", ".js", ".jar", ".hta", ".reg"}
SCRIPT_EXTENSIONS = {".bat", ".cmd", ".ps1", ".vbs", ".js", ".hta", ".reg"}
DANGEROUS_BROWSER_STATES = {"content", "url", "host"}
WARNING_BROWSER_STATES = {"file", "uncommon", "unwanted", "passwordProtected", "blockedTooLarge"}


def _inside(child: Path, parent: Path) -> bool:
    try:
        child.relative_to(parent)
        return True
    except ValueError:
        return False


def _hash_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _result(level: str, action: str, score: int, target: str, summary: str,
            reasons: list[str], **extra) -> dict:
    return {
        "level": level,
        "action": action,
        "score": min(100, max(0, int(score))),
        "kind": "download file",
        "target": target,
        "host": "Local file",
        "summary": summary,
        "reasons": reasons,
        "inspection": "local metadata and file-signature checks; file was not executed",
        **extra,
    }



def identify_signature(header: bytes) -> str:
    """Identify a few common file container signatures without executing content."""
    if header.startswith(b"MZ"):
        return "Windows PE executable"
    if header.startswith(b"%PDF-"):
        return "PDF document"
    if header.startswith(b"\x89PNG\r\n\x1a\n"):
        return "PNG image"
    if header.startswith(b"\xff\xd8\xff"):
        return "JPEG image"
    if header.startswith((b"GIF87a", b"GIF89a")):
        return "GIF image"
    if header.startswith(b"PK\x03\x04") or header.startswith(b"PK\x05\x06") or header.startswith(b"PK\x07\x08"):
        return "ZIP container (also used by DOCX/XLSX/PPTX/JAR)"
    if header.startswith(b"Rar!\x1a\x07"):
        return "RAR archive"
    if header.startswith(b"7z\xbc\xaf\x27\x1c"):
        return "7-Zip archive"
    if header.startswith(b"\x1f\x8b"):
        return "GZIP archive"
    if header.startswith(b"\x7fELF"):
        return "ELF executable"
    if header.startswith(b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1"):
        return "OLE compound document (legacy Office / installer container)"
    if header.startswith(b"SQLite format 3\x00"):
        return "SQLite database"
    if header.startswith(b"RIFF") and header[8:12] == b"WAVE":
        return "WAV audio"
    if header.startswith(b"ID3") or header[:2] in (b"\xff\xfb", b"\xff\xf3", b"\xff\xf2"):
        return "MP3 audio"
    if len(header) >= 12 and header[4:8] == b"ftyp":
        return "ISO Base Media (MP4/MOV family)"
    sample = header.lstrip()[:100].lower()
    if sample.startswith((b"<!doctype html", b"<html", b"<script")):
        return "HTML/text content"
    if sample.startswith((b"{", b"[")):
        return "JSON-like text"
    return "Unrecognised / no supported signature"


SIGNATURE_EXTENSION_FAMILIES = {
    "Windows PE executable": {".exe", ".dll", ".scr", ".com"},
    "PDF document": {".pdf"},
    "PNG image": {".png"},
    "JPEG image": {".jpg", ".jpeg"},
    "GIF image": {".gif"},
    "ZIP container (also used by DOCX/XLSX/PPTX/JAR)": {".zip", ".docx", ".xlsx", ".pptx", ".jar", ".apk", ".odt", ".ods"},
    "RAR archive": {".rar"},
    "7-Zip archive": {".7z"},
    "GZIP archive": {".gz", ".tgz"},
    "ELF executable": {".elf", ".so", ".bin"},
    "OLE compound document (legacy Office / installer container)": {".doc", ".xls", ".ppt", ".msi"},
    "SQLite database": {".sqlite", ".sqlite3", ".db"},
    "WAV audio": {".wav"},
    "MP3 audio": {".mp3"},
    "ISO Base Media (MP4/MOV family)": {".mp4", ".m4v", ".mov"},
}


def scan_download_file(file_path: str, settings: dict | None = None,
                       chrome_danger: str | None = None,
                       downloads_root: str | Path | None = None) -> dict:
    """Inspect a completed browser download inside the user's Downloads folder.

    The optional downloads_root argument exists for deterministic tests. Production
    calls default to ~/Downloads and reject paths outside that folder.
    """
    settings = settings or {}
    root = Path(downloads_root).expanduser() if downloads_root else Path.home() / "Downloads"
    try:
        root = root.resolve(strict=False)
        candidate = Path(file_path).expanduser()
        if not candidate.is_absolute():
            return _result("WARNING", "warn", 20, candidate.name or "Unknown file",
                           "PAUSE could not verify the file's full local path.",
                           ["The file path was not absolute, so the scanner did not open it."])
        path = candidate.resolve(strict=True)
        if not _inside(path, root):
            return _result("WARNING", "warn", 20, path.name,
                           "This file is outside the configured Downloads folder and was not inspected.",
                           ["For privacy and safety, PAUSE only inspects files in the standard Downloads folder."])
        if not path.is_file():
            return _result("WARNING", "warn", 20, path.name,
                           "The download is not a regular file.",
                           ["Folders, shortcuts and special files are not inspected by this scanner."])
        size = path.stat().st_size
        if size > MAX_SCAN_BYTES:
            return _result("WARNING", "warn", 20, path.name,
                           "The file is larger than PAUSE's local inspection limit.",
                           ["The file was not hashed or read because it exceeds the 250 MB inspection limit."],
                           file_size=size)
        sha256 = _hash_file(path)
        with path.open("rb") as handle:
            header = handle.read(8192)
    except FileNotFoundError:
        return _result("WARNING", "warn", 20, Path(file_path).name,
                       "The completed download could not be found.",
                       ["The file may have been moved, renamed or removed before inspection."])
    except (OSError, ValueError) as exc:
        return _result("WARNING", "warn", 20, Path(file_path).name,
                       "PAUSE could not safely inspect this file.",
                       [f"Local file inspection failed ({type(exc).__name__})."])

    name = path.name
    lower_name = name.lower()
    suffixes = [suffix.lower() for suffix in path.suffixes]
    final_ext = suffixes[-1] if suffixes else ""
    signature = identify_signature(header)
    score = 0
    reasons: list[str] = []

    if len(suffixes) >= 2 and suffixes[-1] in EXECUTABLE_EXTENSIONS:
        previous = suffixes[-2]
        if previous in {".pdf", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx", ".jpg", ".png", ".txt"}:
            score += 65
            reasons.append("The filename disguises an executable or script behind a document or image extension.")

    if final_ext in EXECUTABLE_EXTENSIONS:
        score += 28 if final_ext not in SCRIPT_EXTENSIONS else 35
        reasons.append("The downloaded file is an executable or script type; only open it when you independently expected it.")

    if header.startswith(b"MZ") and final_ext in {".pdf", ".jpg", ".jpeg", ".png", ".gif", ".txt", ".csv"}:
        score += 70
        reasons.append("The file contents begin with a Windows executable signature but the filename presents it as a document or image.")
    elif final_ext == ".pdf" and not header.startswith(b"%PDF-"):
        score += 18
        reasons.append("The file extension says PDF, but the file header does not match a normal PDF signature.")
    elif final_ext in {".png"} and not header.startswith(b"\x89PNG\r\n\x1a\n"):
        score += 18
        reasons.append("The file extension says PNG, but its contents do not start with a PNG signature.")
    elif final_ext in {".jpg", ".jpeg"} and not header.startswith(b"\xff\xd8\xff"):
        score += 18
        reasons.append("The file extension says JPEG, but its contents do not start with a JPEG signature.")

    expected_extensions = SIGNATURE_EXTENSION_FAMILIES.get(signature)
    if expected_extensions and final_ext not in expected_extensions:
        # Only apply a mismatch when the detected signature is specific and the
        # displayed suffix is not one of its usual container/file extensions.
        score += 24
        reasons.append(f"The file header identifies {signature}, which does not match the .{final_ext.lstrip('.') or 'no extension'} filename extension.")

    danger = str(chrome_danger or "").strip()
    if danger in DANGEROUS_BROWSER_STATES:
        score += 80
        reasons.append(f"Chrome's download protection classified this item as '{danger}'.")
    elif danger in WARNING_BROWSER_STATES:
        score += 18
        reasons.append(f"Chrome's download protection classified this item as '{danger}'.")

    if not reasons:
        reasons.append("No configured filename or file-signature indicators were detected. This is not a malware verdict.")

    warning_threshold = int(settings.get("warning_threshold", 15))
    high_threshold = int(settings.get("high_risk_threshold", 45))
    if score >= high_threshold:
        level, action = "HIGH RISK", "block"
    elif score >= warning_threshold:
        level, action = "WARNING", "warn"
    else:
        level, action = "SAFE", "allow"

    summary = (f"File: {name}. Size: {size:,} bytes. SHA-256: {sha256[:16]}… "
               "PAUSE inspected local metadata and a small file header; it did not execute the file or prove it is safe.")
    return _result(level, action, score, name, summary, reasons,
                   file_size=size, sha256=sha256, sha256_prefix=sha256[:16],
                   extension=final_ext, browser_danger=danger or "not-provided",
                   file_dna={"name": name, "size_bytes": size, "extension": final_ext or "(none)",
                             "signature": signature, "mime_guess": mimetypes.guess_type(name)[0] or "unknown",
                             "sha256": sha256, "browser_danger": danger or "not-provided"})
