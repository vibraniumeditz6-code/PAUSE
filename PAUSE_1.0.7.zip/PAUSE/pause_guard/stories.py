"""Correlate recorded PAUSE events into cautious, evidence-based stories."""
from __future__ import annotations

from urllib.parse import urlsplit

LEVEL_RANK = {"SAFE": 0, "UNKNOWN": 1, "WARNING": 2, "HIGH RISK": 3}


def _host_key(event: dict) -> str:
    value = str(event.get("host") or "").strip().lower().rstrip(".")
    if not value or value in {"local file", "sender not identified", "unknown destination"}:
        return ""
    if value.startswith(("http://", "https://")):
        value = urlsplit(value).hostname or ""
    value = value.split(":", 1)[0].strip("[]")
    if value.startswith("www."):
        value = value[4:]
    if "." not in value or " " in value:
        return ""
    return value


def _surface(event: dict) -> str:
    source = str(event.get("source") or "").lower()
    kind = str(event.get("kind") or "").lower()
    if "gmail" in source or "email" in source or "message" in kind:
        return "Mail"
    if "download" in source or "download" in kind or "file" in kind:
        return "Download"
    if "browser" in source or kind in {"url", "link", "form", "page navigation"}:
        return "Browser"
    return "Other"


def build_threat_stories(events: list[dict]) -> list[dict]:
    """Group by repeated host evidence; never infer causation or unseen steps."""
    groups: dict[str, list[dict]] = {}
    for event in events:
        key = _host_key(event)
        if key:
            groups.setdefault(key, []).append(event)

    stories = []
    for host, rows in groups.items():
        rows = sorted(rows, key=lambda row: str(row.get("created_at", "")))
        rows = rows[-20:]
        high = any(row.get("level") == "HIGH RISK" for row in rows)
        if len(rows) < 2 and not high:
            continue
        surfaces = []
        for row in rows:
            label = _surface(row)
            if label not in surfaces:
                surfaces.append(label)
        level = max((str(row.get("level", "UNKNOWN")) for row in rows),
                    key=lambda value: LEVEL_RANK.get(value, 1))
        stories.append({
            "host": host,
            "level": level,
            "event_count": len(rows),
            "first_seen": rows[0].get("created_at", ""),
            "last_seen": rows[-1].get("created_at", ""),
            "surfaces": surfaces,
            "events": rows,
            "correlation_basis": "Repeated local records sharing the same hostname.",
            "causation_claimed": False,
        })
    stories.sort(key=lambda story: (LEVEL_RANK.get(story["level"], 1), story["event_count"], story["last_seen"]), reverse=True)
    return stories[:50]
