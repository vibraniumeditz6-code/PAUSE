from __future__ import annotations

import json
import os
import secrets
import sqlite3
import hashlib
import hmac
import re
import time
from contextlib import contextmanager

from urllib.parse import urlsplit, urlunsplit
from pathlib import Path
from datetime import datetime, timezone

from .gemini_models import DEFAULT_GEMINI_MODEL, GEMINI_MODEL_IDS

DEFAULT_SETTINGS = {
    "protection_enabled": True,
    "block_high_risk": True,
    "warn_on_suspicious": True,
    "show_safe_notices": False,
    "scan_page_navigation": True,
    "scan_links": True,
    "scan_forms": True,
    "scan_downloads": True,
    "gmail_scan_enabled": False,
    "gmail_client_id": "",
    "gmail_monitor_enabled": False,
    "theme": "light",
    "desktop_notifications": False,
    "notification_mode": "quiet",
    "quiet_mode": True,
    "high_risk_threshold": 45,
    "warning_threshold": 15,
    "retention_days": 30,
    "gemini_model": DEFAULT_GEMINI_MODEL,
    "custom_block_domains": [],
    "trusted_domains": [],
}


def get_data_dir() -> Path:
    base = os.environ.get("LOCALAPPDATA") or str(Path.home() / ".local" / "share")
    path = Path(base) / "PAUSEGuard"
    path.mkdir(parents=True, exist_ok=True)
    return path


class Store:
    def __init__(self):
        self.data_dir = get_data_dir()
        self.settings_path = self.data_dir / "settings.json"
        self.token_path = self.data_dir / "pairing_token.txt"
        self.db_path = self.data_dir / "activity.sqlite3"
        self.settings = self._load_settings()
        self.token = self._load_token()
        self.current_account = None
        self._init_db()

    def _load_settings(self):
        settings = DEFAULT_SETTINGS.copy()
        try:
            if self.settings_path.exists():
                loaded = json.loads(self.settings_path.read_text(encoding="utf-8"))
                if isinstance(loaded, dict):
                    settings.update({k: v for k, v in loaded.items() if k in DEFAULT_SETTINGS})
        except Exception:
            pass
        # Quiet Mode changes only priority in-app alert presentation. OS and SAFE
        # notifications remain disabled to avoid permission creep and alert spam.
        settings["quiet_mode"] = bool(settings.get("quiet_mode", True))
        # Preserve the legacy field as permanently quiet; the new boolean controls
        # only in-app alert presentation and can never re-enable OS notifications.
        settings["notification_mode"] = "quiet"
        settings["desktop_notifications"] = False
        settings["show_safe_notices"] = False
        return settings

    def _load_token(self):
        try:
            token = self.token_path.read_text(encoding="utf-8").strip()
            if token:
                return token
        except Exception:
            pass
        token = secrets.token_urlsafe(24)
        self.token_path.write_text(token, encoding="utf-8")
        try:
            os.chmod(self.token_path, 0o600)
        except Exception:
            pass
        return token

    def save_settings(self, new_settings):
        updated = self.settings.copy()
        for key in DEFAULT_SETTINGS:
            if key in new_settings:
                updated[key] = new_settings[key]
        updated["warning_threshold"] = max(1, min(99, int(updated["warning_threshold"])))
        updated["high_risk_threshold"] = max(int(updated["warning_threshold"]) + 1, min(100, int(updated["high_risk_threshold"])))
        updated["retention_days"] = max(1, min(365, int(updated["retention_days"])))
        updated["theme"] = "dark" if str(updated.get("theme", "light")).lower() == "dark" else "light"
        updated["gmail_client_id"] = str(updated.get("gmail_client_id", ""))[:300]
        selected_model = str(updated.get("gemini_model", DEFAULT_GEMINI_MODEL))
        updated["gemini_model"] = selected_model if selected_model in GEMINI_MODEL_IDS else DEFAULT_GEMINI_MODEL
        updated["gmail_monitor_enabled"] = bool(updated.get("gmail_monitor_enabled", False))
        # OS notifications and SAFE notices remain disabled. Quiet Mode controls
        # only whether new priority alerts appear in the app's inline status area.
        updated["quiet_mode"] = bool(updated.get("quiet_mode", True))
        updated["notification_mode"] = "quiet"
        updated["desktop_notifications"] = False
        updated["show_safe_notices"] = False
        temp_path = self.settings_path.with_suffix(self.settings_path.suffix + ".tmp")
        try:
            temp_path.write_text(json.dumps(updated, indent=2), encoding="utf-8")
            temp_path.replace(self.settings_path)
        except OSError:
            try:
                temp_path.unlink(missing_ok=True)
            except OSError:
                pass
            raise
        self.settings = updated
        return updated

    @contextmanager
    def _connect(self):
        conn = sqlite3.connect(self.db_path, timeout=5)
        conn.row_factory = sqlite3.Row
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def _init_db(self):
        with self._connect() as conn:
            conn.execute("""CREATE TABLE IF NOT EXISTS accounts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                display_name TEXT NOT NULL,
                email TEXT NOT NULL UNIQUE COLLATE NOCASE,
                password_salt TEXT NOT NULL,
                password_hash TEXT NOT NULL,
                created_at TEXT NOT NULL,
                last_login TEXT
            )""")
            conn.execute("""CREATE TABLE IF NOT EXISTS auth_sessions (
                token_hash TEXT PRIMARY KEY,
                account_id INTEGER NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
                created_at REAL NOT NULL,
                expires_at REAL NOT NULL
            )""")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_auth_sessions_account ON auth_sessions(account_id)")
            conn.execute("""CREATE TABLE IF NOT EXISTS events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                created_at TEXT NOT NULL,
                level TEXT NOT NULL,
                kind TEXT NOT NULL,
                target TEXT NOT NULL,
                host TEXT NOT NULL,
                score INTEGER NOT NULL,
                action TEXT NOT NULL,
                summary TEXT NOT NULL,
                reasons TEXT NOT NULL,
                source TEXT NOT NULL
            )""")


    @staticmethod
    def _session_digest(token: str) -> str:
        return hashlib.sha256(str(token).encode("utf-8")).hexdigest()

    def create_session(self, account: dict, lifetime_days: int = 30) -> str:
        """Create a revocable, 30-day device session; only its hash is stored."""
        token = secrets.token_urlsafe(40)
        now = time.time()
        with self._connect() as conn:
            conn.execute("DELETE FROM auth_sessions WHERE expires_at <= ?", (now,))
            conn.execute("INSERT INTO auth_sessions(token_hash,account_id,created_at,expires_at) VALUES(?,?,?,?)",
                         (self._session_digest(token), int(account["id"]), now, now + max(1, lifetime_days) * 86400))
        return token

    def get_session_account(self, token: str) -> dict | None:
        if not token:
            return None
        now = time.time()
        with self._connect() as conn:
            row = conn.execute("""SELECT a.id,a.display_name,a.email,a.created_at,s.expires_at
                FROM auth_sessions s JOIN accounts a ON a.id=s.account_id
                WHERE s.token_hash=? AND s.expires_at>?""", (self._session_digest(token), now)).fetchone()
            if not row:
                conn.execute("DELETE FROM auth_sessions WHERE token_hash=? OR expires_at<=?",
                             (self._session_digest(token), now))
                return None
        account = {"id": row["id"], "display_name": row["display_name"],
                   "email": row["email"], "created_at": row["created_at"]}
        self.current_account = dict(account)
        return account

    def revoke_session(self, token: str) -> None:
        if token:
            with self._connect() as conn:
                conn.execute("DELETE FROM auth_sessions WHERE token_hash=?", (self._session_digest(token),))

    def revoke_account_sessions(self, account_id: int) -> None:
        with self._connect() as conn:
            conn.execute("DELETE FROM auth_sessions WHERE account_id=?", (int(account_id),))

    # Local application accounts. Passwords are never stored in plain text.
    # Profiles are device-local; this is not a cloud identity provider.
    @staticmethod
    def _password_digest(password: str, salt: bytes) -> str:
        return hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 310_000).hex()

    def account_count(self) -> int:
        with self._connect() as conn:
            return int(conn.execute("SELECT COUNT(*) n FROM accounts").fetchone()["n"])

    def create_account(self, display_name: str, email: str, password: str) -> dict:
        display_name = str(display_name).strip()[:80]
        email = str(email).strip().lower()[:254]
        password = str(password)
        if len(display_name) < 2:
            raise ValueError("Enter a name with at least 2 characters.")
        if not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", email):
            raise ValueError("Enter a valid email address.")
        if len(password) < 10:
            raise ValueError("Use a password with at least 10 characters.")
        salt = secrets.token_bytes(16)
        digest = self._password_digest(password, salt)
        now = datetime.now().astimezone().isoformat(timespec="seconds")
        try:
            with self._connect() as conn:
                cur = conn.execute(
                    "INSERT INTO accounts(display_name,email,password_salt,password_hash,created_at,last_login) VALUES(?,?,?,?,?,?)",
                    (display_name, email, salt.hex(), digest, now, now)
                )
                account_id = cur.lastrowid
        except sqlite3.IntegrityError as exc:
            raise ValueError("An account with this email already exists on this device.") from exc
        self.current_account = {"id": account_id, "display_name": display_name, "email": email, "created_at": now}
        return dict(self.current_account)

    def sign_in(self, email: str, password: str) -> dict:
        email = str(email).strip().lower()[:254]
        with self._connect() as conn:
            row = conn.execute("SELECT * FROM accounts WHERE email=? COLLATE NOCASE", (email,)).fetchone()
            if not row:
                raise ValueError("Email or password is incorrect.")
            candidate = self._password_digest(str(password), bytes.fromhex(row["password_salt"]))
            if not hmac.compare_digest(candidate, row["password_hash"]):
                raise ValueError("Email or password is incorrect.")
            now = datetime.now().astimezone().isoformat(timespec="seconds")
            conn.execute("UPDATE accounts SET last_login=? WHERE id=?", (now, row["id"]))
        self.current_account = {
            "id": row["id"], "display_name": row["display_name"],
            "email": row["email"], "created_at": row["created_at"]
        }
        return dict(self.current_account)

    def update_account_profile(self, display_name: str, email: str) -> dict:
        if not self.current_account:
            raise ValueError("Sign in before changing account details.")
        display_name = str(display_name).strip()[:80]
        email = str(email).strip().lower()[:254]
        if len(display_name) < 2:
            raise ValueError("Enter a name with at least 2 characters.")
        if not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", email):
            raise ValueError("Enter a valid email address.")
        try:
            with self._connect() as conn:
                conn.execute("UPDATE accounts SET display_name=?, email=? WHERE id=?",
                             (display_name, email, self.current_account["id"]))
        except sqlite3.IntegrityError as exc:
            raise ValueError("Another local account already uses this email.") from exc
        self.current_account.update({"display_name": display_name, "email": email})
        return dict(self.current_account)

    def change_account_password(self, current_password: str, new_password: str) -> None:
        if not self.current_account:
            raise ValueError("Sign in before changing your password.")
        if len(str(new_password)) < 10:
            raise ValueError("Use a new password with at least 10 characters.")
        account_id = self.current_account["id"]
        with self._connect() as conn:
            row = conn.execute("SELECT password_salt,password_hash FROM accounts WHERE id=?",
                               (account_id,)).fetchone()
            if not row:
                raise ValueError("This local account could not be found.")
            candidate = self._password_digest(str(current_password), bytes.fromhex(row["password_salt"]))
            if not hmac.compare_digest(candidate, row["password_hash"]):
                raise ValueError("Your current password is incorrect.")
            salt = secrets.token_bytes(16)
            digest = self._password_digest(str(new_password), salt)
            conn.execute("UPDATE accounts SET password_salt=?, password_hash=? WHERE id=?",
                         (salt.hex(), digest, self.current_account["id"]))

    def sign_out(self) -> None:
        self.current_account = None

    def delete_current_account(self, password: str) -> None:
        if not self.current_account:
            raise ValueError("No account is signed in.")
        account_id = self.current_account["id"]
        with self._connect() as conn:
            row = conn.execute("SELECT password_salt,password_hash FROM accounts WHERE id=?",
                               (account_id,)).fetchone()
            if not row:
                raise ValueError("This local account could not be found.")
            candidate = self._password_digest(str(password), bytes.fromhex(row["password_salt"]))
            if not hmac.compare_digest(candidate, row["password_hash"]):
                raise ValueError("Password is incorrect. The account was not deleted.")
            conn.execute("DELETE FROM auth_sessions WHERE account_id=?", (account_id,))
            conn.execute("DELETE FROM accounts WHERE id=?", (account_id,))
        self.current_account = None

    def add_event(self, result: dict, source="browser"):
        # Never persist the body of an email or form values.
        now = datetime.now().astimezone().isoformat(timespec="seconds")
        target = str(result.get("target", ""))[:500]
        # Keep useful destination context without persisting potentially sensitive query values.
        if target.lower().startswith(("http://", "https://")):
            try:
                parts = urlsplit(target)
                host = parts.hostname or ""
                if parts.port:
                    host += f":{parts.port}"
                target = urlunsplit((parts.scheme, host, parts.path, "", ""))
            except Exception:
                target = "Web destination (address could not be safely shortened)"
        summary = str(result.get("summary", ""))[:1000]
        reasons = json.dumps(result.get("reasons", [])[:20], ensure_ascii=False)
        with self._connect() as conn:
            cur = conn.execute(
                "INSERT INTO events(created_at,level,kind,target,host,score,action,summary,reasons,source) VALUES(?,?,?,?,?,?,?,?,?,?)",
                (now, result.get("level", "UNKNOWN"), result.get("kind", "url"), target,
                 str(result.get("host", ""))[:255], int(result.get("score", 0)),
                 result.get("action", "allow"), summary, reasons, source[:80])
            )
            return cur.lastrowid

    def list_events(self, limit=100):
        limit = max(1, min(500, int(limit)))
        with self._connect() as conn:
            rows = conn.execute("SELECT * FROM events ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
            return [self._row_to_dict(row) for row in rows]

    @staticmethod
    def _row_to_dict(row):
        item = dict(row)
        try:
            item["reasons"] = json.loads(item["reasons"])
        except Exception:
            item["reasons"] = []
        return item

    def stats(self):
        with self._connect() as conn:
            total = conn.execute("SELECT COUNT(*) n FROM events").fetchone()["n"]
            high = conn.execute("SELECT COUNT(*) n FROM events WHERE level='HIGH RISK'").fetchone()["n"]
            warnings = conn.execute("SELECT COUNT(*) n FROM events WHERE level='WARNING'").fetchone()["n"]
            safe = conn.execute("SELECT COUNT(*) n FROM events WHERE level='SAFE'").fetchone()["n"]
        return {"total": total, "high_risk": high, "warnings": warnings, "safe": safe}

    def clear_events(self):
        with self._connect() as conn:
            conn.execute("DELETE FROM events")
            conn.execute("DELETE FROM sqlite_sequence WHERE name='events'")

    def purge_old(self):
        days = int(self.settings.get("retention_days", 30))
        # ISO local timestamps are compared by date prefix to avoid timezone parsing surprises.
        cutoff = datetime.now().astimezone().date().toordinal() - days
        with self._connect() as conn:
            rows = conn.execute("SELECT id, created_at FROM events").fetchall()
            ids = []
            for row in rows:
                try:
                    date = datetime.fromisoformat(row["created_at"]).date()
                    if date.toordinal() < cutoff:
                        ids.append((row["id"],))
                except Exception:
                    continue
            if ids:
                conn.executemany("DELETE FROM events WHERE id=?", ids)
