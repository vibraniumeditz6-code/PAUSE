"""Supported stable Gemini text-generation models for PAUSE AI.

Model IDs are checked against Google's current Gemini API model catalogue.
Only stable models with text output are listed here; preview, live-audio,
image-generation and legacy-restricted models are intentionally excluded.
"""
from __future__ import annotations

GEMINI_MODELS = (
    {
        "id": "gemini-4-argon",
        "name": "Gemini 4 Argon",
        "description": "Advanced reasoning for complex work and coding",
        "tag": "Advanced",
    },
    {
        "id": "gemini-3.8-flash",
        "name": "Gemini 3.8 Flash",
        "description": "Strong general-purpose reasoning and speed",
        "tag": "Recommended",
    },
    {
        "id": "gemini-3.6-flash",
        "name": "Gemini 3.6 Flash",
        "description": "Balanced everyday model",
        "tag": "Balanced",
    },
    {
        "id": "gemini-3.5-flash-lite",
        "name": "Gemini 3.5 Flash-Lite",
        "description": "Fast, efficient model for everyday questions",
        "tag": "Efficient",
    },
    {
        "id": "gemini-3.1-flash-lite",
        "name": "Gemini 3.1 Flash-Lite",
        "description": "Lightweight model focused on low latency",
        "tag": "Lightweight",
    },
)

DEFAULT_GEMINI_MODEL = "gemini-3.5-flash-lite"
GEMINI_MODEL_BY_ID = {item["id"]: item for item in GEMINI_MODELS}
GEMINI_MODEL_IDS = frozenset(GEMINI_MODEL_BY_ID)

def get_gemini_model(model_id: str | None = None) -> dict:
    return GEMINI_MODEL_BY_ID.get(str(model_id or ""), GEMINI_MODEL_BY_ID[DEFAULT_GEMINI_MODEL])
