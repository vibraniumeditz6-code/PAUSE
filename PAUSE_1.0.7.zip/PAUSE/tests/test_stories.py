import unittest

from pause_guard.stories import build_threat_stories


class ThreatStoryTests(unittest.TestCase):
    def test_repeated_host_events_are_grouped_without_causation_claim(self):
        events = [
            {"host": "news.example", "level": "WARNING", "kind": "url", "source": "Browser", "created_at": "2026-10-30T10:00:00", "summary": "Visited link"},
            {"host": "news.example", "level": "HIGH RISK", "kind": "download", "source": "Download", "created_at": "2026-10-30T10:02:00", "summary": "Download inspection"},
        ]
        stories = build_threat_stories(events)
        self.assertEqual(len(stories), 1)
        self.assertEqual(stories[0]["event_count"], 2)
        self.assertEqual(stories[0]["surfaces"], ["Browser", "Download"])
        self.assertFalse(stories[0]["causation_claimed"])

    def test_single_low_risk_event_is_not_promoted_to_a_story(self):
        stories = build_threat_stories([{"host": "example.com", "level": "SAFE", "kind": "url"}])
        self.assertEqual(stories, [])

    def test_single_high_risk_event_can_be_shown_as_a_story(self):
        stories = build_threat_stories([{"host": "example.com", "level": "HIGH RISK", "kind": "url", "source": "Browser"}])
        self.assertEqual(len(stories), 1)
        self.assertEqual(stories[0]["event_count"], 1)


if __name__ == "__main__":
    unittest.main()
