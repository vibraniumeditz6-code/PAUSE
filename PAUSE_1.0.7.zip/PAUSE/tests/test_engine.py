import unittest
from pause_guard.engine import scan_url, scan_email


class URLScanTests(unittest.TestCase):
    def test_normal_https_address_has_no_configured_signals(self):
        result = scan_url("https://example.com/about")
        self.assertEqual(result["level"], "SAFE")
        self.assertEqual(result["action"], "allow")

    def test_reserved_demo_threat_domain_is_high_risk(self):
        result = scan_url("https://phishing.test/login")
        self.assertEqual(result["level"], "HIGH RISK")
        self.assertEqual(result["action"], "block")

    def test_plain_http_is_a_warning_but_not_high_risk(self):
        result = scan_url("http://example.com/")
        self.assertEqual(result["level"], "WARNING")
        self.assertTrue(any("HTTP" in reason for reason in result["reasons"]))

    def test_personal_block_list(self):
        result = scan_url("https://blocked.example/path", {"custom_block_domains": ["example"]})
        self.assertEqual(result["level"], "HIGH RISK")

    def test_trusted_list_does_not_remove_strong_indicators(self):
        result = scan_url("https://phishing.test/login", {"trusted_domains": ["phishing.test"]})
        self.assertEqual(result["level"], "HIGH RISK")

    def test_link_xray_flags_visible_url_host_mismatch(self):
        result = scan_url("https://not-google.example/login", display_text="https://accounts.google.com")
        self.assertFalse(result["xray"]["visible_destination_match"])
        self.assertEqual(result["xray"]["destination_host"], "not-google.example")
        self.assertEqual(result["xray"]["visible_host"], "accounts.google.com")
        self.assertTrue(any("visible link text" in reason for reason in result["reasons"]))

    def test_link_xray_does_not_flag_descriptive_anchor_text(self):
        result = scan_url("https://example.com/sign-in", display_text="Open your account")
        self.assertIsNone(result["xray"]["visible_destination_match"])

    def test_link_xray_extracts_redirect_candidate_without_claiming_resolution(self):
        result = scan_url("https://portal.example/continue?next=https%3A%2F%2Foutside.example%2Flogin")
        self.assertEqual(result["xray"]["redirect_candidates"][0]["destination_host"], "outside.example")
        self.assertEqual(result["xray"]["redirect_chain_status"], "not_resolved_live")

    def test_link_xray_handles_invalid_port_without_crashing(self):
        result = scan_url("https://example.com:notaport/path")
        self.assertEqual(result["xray"]["port"], "Invalid port")
        self.assertTrue(any("invalid port" in reason.lower() for reason in result["reasons"]))


class EmailScanTests(unittest.TestCase):
    def test_credential_and_urgency_email_is_flagged(self):
        result = scan_email({
            "sender": "security@unknown.example",
            "sender_name": "Microsoft Security",
            "subject": "Urgent action required",
            "body": "Your account is suspended. Verify your password and share your OTP immediately: https://phishing.test/login"
        })
        self.assertEqual(result["level"], "HIGH RISK")
        self.assertGreater(result["score"], 45)

    def test_email_body_is_not_echoed_as_summary(self):
        secret = "DO_NOT_STORE_THIS_PRIVATE_BODY_123"
        result = scan_email({"sender": "friend@example.com", "subject": "Hello", "body": secret})
        self.assertNotIn(secret, result["summary"])

    def test_executable_attachment_is_high_risk(self):
        result = scan_email({"sender": "x@example.com", "subject": "file", "body": "See attached", "attachments": ["invoice.exe"]})
        self.assertEqual(result["level"], "HIGH RISK")


if __name__ == "__main__":
    unittest.main()
