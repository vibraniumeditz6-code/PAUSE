import json
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


class ExtensionAssetTests(unittest.TestCase):
    def test_manifest_icon_references_exist(self):
        manifest = json.loads((ROOT / "browser_extension" / "manifest.json").read_text(encoding="utf-8"))
        icons = manifest["icons"]
        self.assertEqual(set(icons), {"16", "32", "48", "128"})
        for relative in icons.values():
            self.assertTrue((ROOT / "browser_extension" / relative).is_file(), relative)
        for relative in manifest["action"]["default_icon"].values():
            self.assertTrue((ROOT / "browser_extension" / relative).is_file(), relative)

    def test_original_brand_art_and_extension_popup_use_shield_image(self):
        extension = ROOT / "browser_extension"
        self.assertTrue((extension / "assets" / "PAUSE-brand-art-original.png").is_file())
        popup = (extension / "popup.html").read_text(encoding="utf-8")
        options = (extension / "options.html").read_text(encoding="utf-8")
        self.assertIn('src="icons/icon48.png"', popup)
        self.assertIn('src="icons/icon48.png"', options)

    def test_extension_displays_the_shared_selected_gemini_model(self):
        sidepanel = (ROOT / "browser_extension" / "sidepanel.js").read_text(encoding="utf-8")
        self.assertIn("response.data.assistant.model_label", sidepanel)
        self.assertIn("Gemini ·", sidepanel)

    def test_app_has_light_default_and_dark_choice(self):
        html = (ROOT / "pause_guard" / "web" / "index.html").read_text(encoding="utf-8")
        self.assertIn('localStorage.getItem("pause_theme")||"light"', html)
        self.assertIn('id="themeChoice"', html)
        self.assertIn('value="dark"', html)
        self.assertIn('id="openAlerts"', html)
        self.assertIn('No operating-system pop-ups', html)
        self.assertIn('Quiet Mode', html)
        self.assertIn('Threat story', html)

    def test_extension_surfaces_use_light_colors_and_retain_accent_glows(self):
        popup_css = (ROOT / "browser_extension" / "popup.css").read_text(encoding="utf-8")
        options_css = (ROOT / "browser_extension" / "options.css").read_text(encoding="utf-8")
        for css in (popup_css, options_css):
            self.assertIn("--bg:#f4f7fb", css)
            self.assertIn("box-shadow:0 0 ", css)
            self.assertNotIn("--bg:#080d1b", css)

    def test_settings_uses_env_file_instead_of_key_field_or_vault(self):
        html = (ROOT / "pause_guard" / "web" / "index.html").read_text(encoding="utf-8")
        self.assertNotIn('id="geminiApiKey"', html)
        self.assertNotIn("Save key securely", html)
        self.assertIn("EDIT_GEMINI_KEY.bat", html)
        self.assertIn("GEMINI_API_KEY=", html)
        self.assertIn("refreshGeminiStatus", html)
        self.assertIn("/api/assistant/test", html)

    def test_every_page_renderer_in_navigation_map_is_defined(self):
        html = (ROOT / "pause_guard" / "web" / "index.html").read_text(encoding="utf-8")
        match = __import__("re").search(r"const views=\{([^}]+)\};", html)
        self.assertIsNotNone(match, "renderPage must define its page renderer map")
        referenced = __import__("re").findall(r":(render[A-Za-z0-9_]+)", match.group(1))
        declared = set(__import__("re").findall(r"function\s+(render[A-Za-z0-9_]+)\s*\(", html))
        self.assertTrue(referenced, "the page renderer map should not be empty")
        self.assertEqual(sorted(set(referenced) - declared), [], "Every page in renderPage must have a renderer")
        self.assertIn("function renderAccount()", html)
        self.assertIn("/api/auth/profile", html)
        self.assertIn("/api/auth/password", html)
        self.assertIn("/api/auth/delete", html)

    def test_shared_frontend_helpers_are_all_defined(self):
        html = (ROOT / "pause_guard" / "web" / "index.html").read_text(encoding="utf-8")
        declared = set(__import__("re").findall(r"function\s+([A-Za-z_$][\w$]*)\s*\(", html))
        required = {"wireCommon", "modal", "runDemo", "exportActivityCsv"}
        self.assertEqual(sorted(required - declared), [], "Shared UI functions must exist before their pages use them")

    def test_ai_form_prevents_browser_navigation_on_send(self):
        html = (ROOT / "pause_guard" / "web" / "index.html").read_text(encoding="utf-8")
        assistant = html[html.index("function renderAssistant()") : html.index("async function sendAssistantQuestion(")]
        self.assertIn("$('#assistantForm').onsubmit=async e=>{e.preventDefault();", assistant)
        self.assertIn("function wireCommon()", html)
        self.assertIn("view.onclick=e=>", html)

    def test_app_uses_uploaded_pause_logo_asset(self):
        web_icon = ROOT / "pause_guard" / "web" / "pause-icon.png"
        self.assertTrue(web_icon.is_file())
        self.assertGreater(web_icon.stat().st_size, 1000)

    def test_gmail_guide_matches_read_only_desktop_oauth_flow(self):
        html = (ROOT / "pause_guard" / "web" / "index.html").read_text(encoding="utf-8")
        self.assertIn("gmail.readonly", html)
        self.assertIn("Data Access", html)
        self.assertIn("Desktop OAuth client", html)
        self.assertIn("PKCE", html)
        self.assertIn("Google Gmail API Python quickstart", html)
        self.assertIn("127.0.0.1", html)

    def test_browser_decision_card_is_white_and_non_modal(self):
        content = (ROOT / "browser_extension" / "content.js").read_text(encoding="utf-8")
        self.assertIn('background:#fff', content)
        self.assertIn('top:16px;right:16px', content)
        self.assertNotIn('position:fixed;inset:0', content)
        self.assertNotIn('backdrop-filter:blur(13px)', content)

    def test_notification_delivery_is_in_app_only(self):
        background = (ROOT / "browser_extension" / "background.js").read_text(encoding="utf-8")
        ui = (ROOT / "pause_guard" / "web" / "index.html").read_text(encoding="utf-8")
        self.assertNotIn('pause-scan-${Date.now()}', background)
        self.assertIn('No operating-system pop-ups', ui)
        self.assertIn('One calm place for results', ui)
        self.assertIn('OFF · Priority alerts', ui)
        self.assertNotIn('new Notification(', ui)
        self.assertNotIn('chrome.notifications', background)
        manifest = json.loads((ROOT / 'browser_extension' / 'manifest.json').read_text(encoding='utf-8'))
        self.assertNotIn('notifications', manifest['permissions'])
        self.assertIn('setInterval(quietBackgroundRefresh,30000)', ui)

    def test_extension_pending_downloads_use_badge_instead_of_notification_stack(self):
        background = (ROOT / "browser_extension" / "background.js").read_text(encoding="utf-8")
        self.assertIn('chrome.action.setBadgeText', background)
        self.assertIn("held downloads use the toolbar badge and popup", background)
        self.assertNotIn('pause-download-result-', background)

    def test_fast_high_risk_download_is_not_auto_cancelled_by_heuristics(self):
        background = (ROOT / "browser_extension" / "background.js").read_text(encoding="utf-8")
        start = background.index("async function onDownloadCreated(item)")
        end = background.index("chrome.downloads.onCreated.addListener", start)
        created_handler = background[start:end]
        self.assertNotIn("chrome.downloads.cancel", created_handler)
        self.assertIn('status: "already_started"', created_handler)

    def test_completed_file_checks_are_persistently_deduplicated(self):
        background = (ROOT / "browser_extension" / "background.js").read_text(encoding="utf-8")
        self.assertIn('const COMPLETED_DOWNLOADS_KEY = "pauseCompletedFileChecks"', background)
        self.assertIn("wasFileCheckRecorded(downloadId, item.filename)", background)
        self.assertIn("recordFileCheck(downloadId, item.filename)", background)

    def test_extension_has_no_floating_passive_notice_system(self):
        content = (ROOT / "browser_extension" / "content.js").read_text(encoding="utf-8")
        self.assertIn("function showToast() { /* intentionally quiet */ }", content)
        self.assertNotIn('id = "pause-guard-toast"', content)
        self.assertNotIn("document.documentElement.appendChild(toast)", content)

    def test_passive_page_check_does_not_interrupt_after_navigation(self):
        content = (ROOT / "browser_extension" / "content.js").read_text(encoding="utf-8")
        start = content.index("async function checkLoadedPage()")
        end = content.index('if (document.readyState === "complete")', start)
        passive_handler = content[start:end]
        self.assertNotIn("showDecision(", passive_handler)
        self.assertIn("Activity only", passive_handler)

    def test_app_status_feedback_is_inline_not_a_floating_toast(self):
        html = (ROOT / "pause_guard" / "web" / "index.html").read_text(encoding="utf-8")
        self.assertIn('id="quietStatus"', html)
        self.assertNotIn('class="toast-area"', html)
        self.assertNotIn('id="toasts"', html)
        self.assertNotIn('.toast-area{position:fixed', html)
        self.assertIn("status.textContent=text", html)


    def test_pause_ai_side_panel_and_voice_disclosure(self):
        extension = ROOT / "browser_extension"
        manifest = json.loads((extension / "manifest.json").read_text(encoding="utf-8"))
        self.assertIn("sidePanel", manifest["permissions"])
        self.assertEqual(manifest["side_panel"]["default_path"], "sidepanel.html")
        panel = (extension / "sidepanel.html").read_text(encoding="utf-8")
        script = (extension / "sidepanel.js").read_text(encoding="utf-8")
        self.assertIn("Use this page", panel)
        self.assertIn("may use your browser's speech service", panel)
        self.assertIn("Say your question now", script)
        self.assertIn("function explicitOpenTarget(text)", script)
        self.assertIn("PAUSE_OPEN_URL", script)
        self.assertIn("speechSpeaking", script)
        content = (extension / "content.js").read_text(encoding="utf-8")
        self.assertIn("PAUSE_CAPTURE_PAGE_CONTEXT", content)
        self.assertIn("form,input,textarea,select,option,button", content)
        assistant = (ROOT / "pause_guard" / "assistant.py").read_text(encoding="utf-8")
        self.assertIn("generateContent", assistant)
        self.assertIn("_parse_env_file", assistant)
        self.assertNotIn("DpapiVault", assistant)

    def test_desktop_ai_composer_supports_enter_to_send_and_shift_enter_newline(self):
        html = (Path(__file__).parents[1] / "pause_guard" / "web" / "index.html").read_text(encoding="utf-8")
        self.assertIn("$('#assistantQuestion').addEventListener('keydown'", html)
        self.assertIn("e.key==='Enter'&&!e.shiftKey", html)
        self.assertIn("requestSubmit()", html)

    def test_local_login_token_is_persisted_in_browser_storage(self):
        html = (Path(__file__).parents[1] / "pause_guard" / "web" / "index.html").read_text(encoding="utf-8")
        self.assertIn("localStorage.getItem('pause_session')", html)
        self.assertIn("localStorage.setItem('pause_session',r.session)", html)
        self.assertNotIn("sessionStorage.getItem('pause_session')", html)

    def test_settings_has_persistent_key_status_and_live_ai_connection_test(self):
        html = (Path(__file__).parents[1] / "pause_guard" / "web" / "index.html").read_text(encoding="utf-8")
        self.assertIn('id="geminiKeyState"', html)
        self.assertIn('id="testGeminiKey"', html)
        self.assertIn('id="refreshGeminiStatus"', html)
        self.assertIn("/api/assistant/test", html)
        self.assertIn(".env", html)
        self.assertNotIn("KEY SAVED", html)


if __name__ == "__main__":
    unittest.main()

