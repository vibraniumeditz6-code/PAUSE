import json
import os
import tempfile
import unittest
import urllib.error
from pathlib import Path
from unittest.mock import patch

from pause_guard.assistant import AssistantIntegration, AssistantError
from pause_guard.storage import Store


class AssistantTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="pause-ai-test-")
        self.old_localappdata = os.environ.get("LOCALAPPDATA")
        self.old_api_key = os.environ.pop("GEMINI_API_KEY", None)
        os.environ["LOCALAPPDATA"] = self.temp.name
        self.store = Store()
        self.env_path = Path(self.temp.name) / "project" / ".env"
        self.env_path.parent.mkdir(parents=True)
        self.env_path.write_text("GEMINI_API_KEY=\n", encoding="utf-8")
        self.assistant = AssistantIntegration(self.store, env_path=self.env_path)

    def tearDown(self):
        if self.old_localappdata is None:
            os.environ.pop("LOCALAPPDATA", None)
        else:
            os.environ["LOCALAPPDATA"] = self.old_localappdata
        os.environ.pop("GEMINI_API_KEY", None)
        if self.old_api_key is not None:
            os.environ["GEMINI_API_KEY"] = self.old_api_key
        self.temp.cleanup()

    def put_key(self, key="test-gemini-api-key-value-123456789"):
        self.env_path.write_text("# local PAUSE configuration\nGEMINI_API_KEY=" + key + "\n", encoding="utf-8")

    def test_status_reports_env_setup_without_returning_secret(self):
        result = self.assistant.status()
        self.assertFalse(result["configured"])
        self.assertTrue(result["env_file_exists"])
        self.assertEqual(result["key_storage"], "not configured")
        self.assertNotIn("api_key", result)

    def test_dotenv_key_is_loaded_and_never_echoed(self):
        secret = "test-gemini-api-key-value-123456789"
        self.put_key(secret)
        result = self.assistant.status()
        self.assertTrue(result["configured"])
        self.assertTrue(result["key_saved"])
        self.assertEqual(result["key_storage"], ".env file")
        self.assertNotIn(secret, json.dumps(result))
        self.assertEqual(self.assistant._get_key(), secret)

    def test_dotenv_supports_quotes_export_and_comments(self):
        secret = "test-gemini-api-key-value-123456789"
        self.env_path.write_text("export GEMINI_API_KEY='" + secret + "' # local key\n", encoding="utf-8")
        self.assertEqual(self.assistant._get_key(), secret)

    def test_project_env_takes_precedence_over_process_environment(self):
        from_env = "project-gemini-api-key-value-123456789"
        from_process = "process-gemini-api-key-value-123456789"
        self.put_key(from_env)
        with patch.dict(os.environ, {"GEMINI_API_KEY": from_process}):
            self.assertEqual(self.assistant._get_key(), from_env)

    def test_question_required(self):
        with self.assertRaises(AssistantError):
            self.assistant.chat("")

    def test_page_context_is_bounded_and_normalized(self):
        context = self.assistant._clean_context({"title": "x" * 400, "url": "https://example.com", "text": "a" * 12000})
        self.assertEqual(len(context["title"]), 240)
        self.assertEqual(len(context["text"]), 9000)

    def test_generate_content_request_and_grounding_citations(self):
        self.put_key()
        response = {
            "candidates": [{
                "content": {"parts": [{"text": "Grounded answer."}]},
                "groundingMetadata": {"groundingChunks": [{"web": {"uri": "https://example.com/source", "title": "Example"}}]},
            }]
        }

        class FakeResponse:
            def __enter__(self): return self
            def __exit__(self, *args): return False
            def read(self, _limit): return json.dumps(response).encode()

        with patch("pause_guard.assistant.urllib.request.urlopen", return_value=FakeResponse()) as mocked:
            result = self.assistant.chat("What happened today?", context={"text": "untrusted page"}, web_search=True)
        request = mocked.call_args.args[0]
        payload = json.loads(request.data)
        self.assertTrue(request.full_url.endswith("/v1beta/models/gemini-3.5-flash-lite:generateContent"))
        self.assertIn({"google_search": {}}, payload["tools"])
        self.assertIn("systemInstruction", payload)
        self.assertNotIn("generationConfig", payload)
        self.assertIn("untrusted content", payload["contents"][0]["parts"][0]["text"].lower())
        self.assertEqual(result["answer"], "Grounded answer.")
        self.assertEqual(result["citations"][0]["url"], "https://example.com/source")
        self.assertEqual(request.get_header("X-goog-api-key"), "test-gemini-api-key-value-123456789")

    def test_generate_content_without_search_omits_tools(self):
        self.put_key()
        response = {"candidates": [{"content": {"parts": [{"text": "Hello."}]}}]}

        class FakeResponse:
            def __enter__(self): return self
            def __exit__(self, *args): return False
            def read(self, _limit): return json.dumps(response).encode()

        with patch("pause_guard.assistant.urllib.request.urlopen", return_value=FakeResponse()) as mocked:
            result = self.assistant.chat("Hello", web_search=False)
        payload = json.loads(mocked.call_args.args[0].data)
        self.assertNotIn("tools", payload)
        self.assertEqual(result["answer"], "Hello.")

    def test_http_400_surfaces_google_error_detail(self):
        self.put_key()
        error_body = json.dumps({"error": {"code": 400, "status": "INVALID_ARGUMENT", "message": "API key not valid. Please pass a valid API key."}}).encode()
        error = urllib.error.HTTPError("https://example.invalid", 400, "Bad Request", {}, None)
        error.read = lambda _limit=-1: error_body
        with patch("pause_guard.assistant.urllib.request.urlopen", side_effect=error):
            with self.assertRaisesRegex(AssistantError, "API key not valid"):
                self.assistant.chat("Hello")

    def test_old_in_app_key_save_is_disabled(self):
        with self.assertRaisesRegex(AssistantError, "project .env file"):
            self.assistant.set_key("test-gemini-api-key-value-123456789")

    def test_test_connection_makes_a_real_chat_call(self):
        self.put_key()
        with patch.object(self.assistant, "chat", return_value={"answer": "PAUSE AI connection successful.", "model": "gemini-3.5-flash-lite"}) as mocked:
            result = self.assistant.test_connection()
        mocked.assert_called_once_with("Reply with exactly: PAUSE AI connection successful.", web_search=False)
        self.assertTrue(result["ok"])


    def test_model_status_exposes_only_supported_model_options(self):
        result = self.assistant.status()
        model_ids = {item["id"] for item in result["models"]}
        self.assertEqual(result["model"], "gemini-3.5-flash-lite")
        self.assertIn("gemini-4-argon", model_ids)
        self.assertIn("gemini-3.8-flash", model_ids)
        self.assertIn("gemini-3.5-flash-lite", model_ids)
        self.assertNotIn("gemini-2.0-flash", model_ids)
        self.assertNotIn("api_key", result)

    def test_selected_model_is_used_in_generate_content_request(self):
        self.put_key()
        self.store.save_settings({"gemini_model": "gemini-3.8-flash"})
        response = {"candidates": [{"content": {"parts": [{"text": "Model selected."}]}}]}

        class FakeResponse:
            def __enter__(self): return self
            def __exit__(self, *args): return False
            def read(self, _limit): return json.dumps(response).encode()

        with patch("pause_guard.assistant.urllib.request.urlopen", return_value=FakeResponse()) as mocked:
            result = self.assistant.chat("Hello", web_search=False)
        self.assertTrue(mocked.call_args.args[0].full_url.endswith("/v1beta/models/gemini-3.8-flash:generateContent"))
        self.assertEqual(result["model"], "gemini-3.8-flash")
        self.assertEqual(result["model_label"], "Gemini 3.8 Flash")

    def test_invalid_model_preference_falls_back_to_safe_default(self):
        saved = self.store.save_settings({"gemini_model": "not-a-real-model"})
        self.assertEqual(saved["gemini_model"], "gemini-3.5-flash-lite")

    def test_429_error_mentions_selected_model_and_project_quota(self):
        self.put_key()
        self.store.save_settings({"gemini_model": "gemini-3.8-flash"})
        error_body = json.dumps({"error": {"code": 429, "status": "RESOURCE_EXHAUSTED", "message": "Quota exceeded for this model."}}).encode()
        error = urllib.error.HTTPError("https://example.invalid", 429, "Too Many Requests", {}, None)
        error.read = lambda _limit=-1: error_body
        with patch("pause_guard.assistant.urllib.request.urlopen", side_effect=error):
            with self.assertRaises(AssistantError) as ctx:
                self.assistant.chat("Hello")
        self.assertIn("Gemini 3.8 Flash", str(ctx.exception))
        self.assertIn("same Google project", str(ctx.exception))
        self.assertIn("Live web search turned off", str(ctx.exception))

    def test_clear_key_blanks_env_file(self):
        self.put_key()
        self.assertTrue(self.assistant.status()["configured"])
        result = self.assistant.clear_key()
        self.assertFalse(result["configured"])
        self.assertIn("GEMINI_API_KEY=", self.env_path.read_text(encoding="utf-8"))


if __name__ == "__main__":
    unittest.main()
