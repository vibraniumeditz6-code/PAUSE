import json
import os
import tempfile
import unittest
import urllib.error
import urllib.request
from pathlib import Path
from unittest.mock import patch

from pause_guard.storage import Store
from pause_guard.server import LocalAPI


class LocalAPITests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="pause-api-test-")
        self.old_localappdata = os.environ.get("LOCALAPPDATA")
        os.environ["LOCALAPPDATA"] = self.temp.name
        self.store = Store()
        self.api = LocalAPI(self.store, port=0)
        self.api.start()
        self.base = f"http://127.0.0.1:{self.api.httpd.server_port}"
        self.session = ""

    def tearDown(self):
        self.api.stop()
        if self.old_localappdata is None:
            os.environ.pop("LOCALAPPDATA", None)
        else:
            os.environ["LOCALAPPDATA"] = self.old_localappdata
        self.temp.cleanup()

    def request(self, path, payload=None, session=None, extension=False):
        headers = {"Content-Type": "application/json"}
        if session:
            headers["X-PAUSE-Session"] = session
        if extension:
            headers["X-PAUSE-Token"] = self.store.token
        data = json.dumps(payload).encode("utf-8") if payload is not None else None
        req = urllib.request.Request(self.base + path, data=data, headers=headers)
        with urllib.request.urlopen(req, timeout=5) as response:
            raw = response.read()
            try:
                return response.status, json.loads(raw or b"{}")
            except Exception:
                return response.status, raw.decode("utf-8", "replace")

    def test_ui_is_served_by_local_service(self):
        status, body = self.request("/api/health")
        self.assertEqual(status, 200)
        self.assertEqual(body["version"], "1.0.7")
        status, html = self.request("/")
        self.assertEqual(status, 200)
        self.assertIn("PAUSE — Digital Safety Command", html)
        self.assertIn("assistantModel", html)
        self.assertIn("geminiModelSetting", html)
        self.assertIn("persistGeminiModel", html)
        self.assertIn("PAUSE Midnight", html) if "PAUSE Midnight" in html else self.assertIn("DIGITAL SAFETY SYSTEM", html)

    def test_local_account_and_message_body_not_retained(self):
        _, auth = self.request("/api/auth/status")
        self.assertFalse(auth["has_account"])
        _, signup = self.request("/api/auth/signup", {
            "display_name": "Test User", "email": "test@example.com", "password": "SecurePass123!"
        })
        session = signup["session"]
        status, result = self.request("/api/messages/analyse", {
            "channel": "whatsapp", "sender": "sender@example.com",
            "subject": "urgent account notice",
            "body": "Act now. Your account is locked. Verify your password immediately at http://phishing.test/login"
        }, session=session)
        self.assertEqual(status, 200)
        self.assertEqual(result["level"], "HIGH RISK")
        _, events = self.request("/api/events", session=session)
        self.assertEqual(len(events["events"]), 1)
        stored = events["events"][0]
        self.assertNotIn("Verify your password", stored["summary"])
        self.assertNotIn("phishing.test/login", stored["summary"])

    def test_dashboard_requires_local_session(self):
        with self.assertRaises(urllib.error.HTTPError) as ctx:
            self.request("/api/overview")
        self.assertEqual(ctx.exception.code, 401)

    def test_extension_uses_separate_pairing_token(self):
        result_status, result = self.request("/api/scan", {"type": "url", "url": "http://example.com"}, extension=True)
        self.assertEqual(result_status, 200)
        self.assertEqual(result["level"], "WARNING")


    def test_extension_can_call_local_download_file_inspection(self):
        file_path = Path(self.temp.name) / "outside-downloads.pdf"
        file_path.write_bytes(b"%PDF-1.7\nPAUSE test")
        status, result = self.request(
            "/api/download/file-scan",
            {"path": str(file_path)},
            extension=True,
        )
        self.assertEqual(status, 200)
        self.assertEqual(result["level"], "WARNING")
        self.assertIn("outside the configured Downloads folder", result["summary"])

    def test_download_file_inspection_rejects_missing_extension_token(self):
        with self.assertRaises(urllib.error.HTTPError) as ctx:
            self.request("/api/download/file-scan", {"path": str(Path(self.temp.name) / "test.pdf")})
        self.assertEqual(ctx.exception.code, 401)

    def test_same_origin_app_write_is_allowed(self):
        data = json.dumps({"display_name": "Local User", "email": "local@example.com", "password": "SecurePass123!"}).encode()
        req = urllib.request.Request(
            self.base + "/api/auth/signup", data=data, method="POST",
            headers={"Content-Type": "application/json", "Origin": self.base},
        )
        with urllib.request.urlopen(req, timeout=5) as response:
            body = json.loads(response.read())
        self.assertEqual(response.status, 200)
        self.assertIn("session", body)

    def test_cross_origin_browser_write_is_rejected(self):
        data = json.dumps({"display_name": "Injected", "email": "attacker@example.com", "password": "SecurePass123!"}).encode()
        req = urllib.request.Request(
            self.base + "/api/auth/signup", data=data, method="POST",
            headers={"Content-Type": "application/json", "Origin": "https://untrusted.example"},
        )
        with self.assertRaises(urllib.error.HTTPError) as ctx:
            urllib.request.urlopen(req, timeout=5)
        self.assertEqual(ctx.exception.code, 403)
        self.assertEqual(self.store.account_count(), 0)

    def test_extension_origin_cannot_create_local_account(self):
        data = json.dumps({"display_name": "Injected", "email": "extension@example.com", "password": "SecurePass123!"}).encode()
        req = urllib.request.Request(
            self.base + "/api/auth/signup", data=data, method="POST",
            headers={"Content-Type": "application/json", "Origin": "chrome-extension://untrusted-id"},
        )
        with self.assertRaises(urllib.error.HTTPError) as ctx:
            urllib.request.urlopen(req, timeout=5)
        self.assertEqual(ctx.exception.code, 403)
        self.assertEqual(self.store.account_count(), 0)

    def test_manual_link_xray_endpoint_returns_visible_destination_evidence(self):
        _, signup = self.request("/api/auth/signup", {
            "display_name": "Xray Test", "email": "xray@example.com", "password": "SecurePass123!"
        })
        status, result = self.request("/api/toolkit/url", {
            "url": "https://lookalike.example/login", "display_text": "https://accounts.google.com"
        }, session=signup["session"])
        self.assertEqual(status, 200)
        self.assertFalse(result["xray"]["visible_destination_match"])
        self.assertEqual(result["xray"]["destination_host"], "lookalike.example")

    def test_threat_story_endpoint_returns_evidence_based_groupings(self):
        _, signup = self.request("/api/auth/signup", {
            "display_name": "Story Test", "email": "story@example.com", "password": "SecurePass123!"
        })
        session = signup["session"]
        self.store.add_event({"level": "WARNING", "kind": "url", "host": "example.test",
                              "target": "https://example.test/a", "score": 20,
                              "summary": "First observed URL", "reasons": []}, source="Browser")
        self.store.add_event({"level": "HIGH RISK", "kind": "download", "host": "example.test",
                              "target": "report.exe", "score": 70,
                              "summary": "Second observed event", "reasons": []}, source="Download")
        status, result = self.request("/api/threat-stories", session=session)
        self.assertEqual(status, 200)
        self.assertEqual(result["events_checked"], 2)
        self.assertEqual(len(result["stories"]), 1)
        self.assertEqual(result["stories"][0]["host"], "example.test")
        self.assertFalse(result["stories"][0]["causation_claimed"])

    def test_whatsapp_personal_is_not_misrepresented_as_connected(self):
        _, signup = self.request("/api/auth/signup", {
            "display_name": "Test User", "email": "test@example.com", "password": "SecurePass123!"
        })
        session = signup["session"]
        _, result = self.request("/api/connections/intent", {"provider": "whatsapp_personal"}, session=session)
        self.assertEqual(result["status"], "not_supported")
        _, catalog = self.request("/api/connections", session=session)
        self.assertEqual(catalog["providers"]["whatsapp_personal"]["status"], "not_supported")


    def test_assistant_status_is_authenticated_and_never_exposes_key(self):
        with self.assertRaises(urllib.error.HTTPError) as ctx:
            self.request("/api/assistant/status")
        self.assertEqual(ctx.exception.code, 401)
        _, signup = self.request("/api/auth/signup", {
            "display_name": "AI Tester", "email": "ai@example.com", "password": "SecurePass123!"
        })
        status, result = self.request("/api/assistant/status", session=signup["session"])
        self.assertEqual(status, 200)
        self.assertFalse(result["assistant"]["configured"])
        self.assertNotIn("api_key", result["assistant"])

    def test_assistant_model_preference_is_saved_and_returned(self):
        _, signup = self.request("/api/auth/signup", {
            "display_name": "AI Model Tester", "email": "ai-model@example.com", "password": "SecurePass123!"
        })
        session = signup["session"]
        status, saved = self.request("/api/settings/update", {"gemini_model": "gemini-3.8-flash"}, session=session)
        self.assertEqual(status, 200)
        self.assertEqual(saved["settings"]["gemini_model"], "gemini-3.8-flash")
        status, assistant = self.request("/api/assistant/status", session=session)
        self.assertEqual(status, 200)
        self.assertEqual(assistant["assistant"]["model"], "gemini-3.8-flash")
        self.assertEqual(len(assistant["assistant"]["models"]), 5)
        self.assertNotIn("api_key", assistant["assistant"])

    def test_assistant_config_rejects_retired_in_app_key_storage(self):
        _, signup = self.request("/api/auth/signup", {
            "display_name": "AI Tester", "email": "ai-key@example.com", "password": "SecurePass123!"
        })
        data = json.dumps({"api_key": "must-not-be-persisted"}).encode()
        req = urllib.request.Request(
            self.base + "/api/assistant/config", data=data, method="POST",
            headers={"Content-Type": "application/json", "X-PAUSE-Session": signup["session"]},
        )
        with self.assertRaises(urllib.error.HTTPError) as ctx:
            urllib.request.urlopen(req, timeout=5)
        self.assertEqual(ctx.exception.code, 410)
        self.assertIn("project .env file", json.loads(ctx.exception.read())["error"])

    def test_assistant_connection_test_requires_session_and_returns_live_result(self):
        with self.assertRaises(urllib.error.HTTPError) as ctx:
            self.request("/api/assistant/test", {})
        self.assertEqual(ctx.exception.code, 401)
        _, signup = self.request("/api/auth/signup", {
            "display_name": "AI Test", "email": "ai-test@example.com", "password": "SecurePass123!"
        })
        with patch.object(self.api.assistant, "test_connection", return_value={"ok": True, "model": "gemini-3.8-flash", "message": "Gemini authenticated and returned a response."}):
            status, result = self.request("/api/assistant/test", {}, session=signup["session"])
        self.assertEqual(status, 200)
        self.assertTrue(result["ok"])
        self.assertIn("authenticated", result["message"])

    def test_device_snapshot_requires_local_session_or_extension_pairing(self):
        with self.assertRaises(urllib.error.HTTPError) as ctx:
            self.request("/api/device/snapshot")
        self.assertEqual(ctx.exception.code, 401)
        _, signup = self.request("/api/auth/signup", {
            "display_name": "Device Tester", "email": "device@example.com", "password": "SecurePass123!"
        })
        status, result = self.request("/api/device/snapshot", session=signup["session"])
        self.assertEqual(status, 200)
        self.assertIn("device", result)

    def test_device_action_requires_explicit_confirmation(self):
        _, signup = self.request("/api/auth/signup", {
            "display_name": "Power Tester", "email": "power@example.com", "password": "SecurePass123!"
        })
        with self.assertRaises(urllib.error.HTTPError) as ctx:
            self.request("/api/device/action", {"action": "shutdown", "confirmed": False}, session=signup["session"])
        self.assertEqual(ctx.exception.code, 400)

if __name__ == "__main__":
    unittest.main()
