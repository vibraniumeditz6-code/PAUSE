import tempfile
import unittest
from pathlib import Path

from pause_guard.downloads import scan_download_file


class DownloadInspectionTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name) / "Downloads"
        self.root.mkdir()

    def tearDown(self):
        self.temp.cleanup()

    def make_file(self, name, content=b"sample content"):
        path = self.root / name
        path.write_bytes(content)
        return path

    def test_plain_text_file_has_no_configured_indicators(self):
        path = self.make_file("notes.txt")
        result = scan_download_file(str(path), downloads_root=self.root)
        self.assertEqual(result["level"], "SAFE")
        self.assertEqual(len(result["sha256"]), 64)
        self.assertIn("did not execute the file or prove it is safe", result["summary"])

    def test_double_extension_executable_is_high_risk(self):
        path = self.make_file("invoice.pdf.exe", b"MZ" + b"x" * 128)
        result = scan_download_file(str(path), downloads_root=self.root)
        self.assertEqual(result["level"], "HIGH RISK")
        self.assertTrue(any("disguises an executable" in reason for reason in result["reasons"]))

    def test_script_file_is_warning(self):
        path = self.make_file("run.ps1", b"Write-Output 'hello'")
        result = scan_download_file(str(path), downloads_root=self.root)
        self.assertEqual(result["level"], "WARNING")

    def test_chrome_known_malicious_content_is_high_risk(self):
        path = self.make_file("sample.bin")
        result = scan_download_file(str(path), chrome_danger="content", downloads_root=self.root)
        self.assertEqual(result["level"], "HIGH RISK")

    def test_outside_downloads_folder_is_not_opened(self):
        outside = Path(self.temp.name) / "private.txt"
        outside.write_text("private data", encoding="utf-8")
        result = scan_download_file(str(outside), downloads_root=self.root)
        self.assertEqual(result["level"], "WARNING")
        self.assertIn("was not inspected", result["summary"])

    def test_missing_file_is_unknown_warning(self):
        result = scan_download_file(str(self.root / "missing.exe"), downloads_root=self.root)
        self.assertEqual(result["level"], "WARNING")
        self.assertIn("could not be found", result["summary"])

    def test_file_dna_contains_detected_signature_and_full_hash(self):
        path = self.make_file("report.pdf", b"%PDF-1.7\nPAUSE fixture")
        result = scan_download_file(str(path), downloads_root=self.root)
        dna = result["file_dna"]
        self.assertEqual(dna["signature"], "PDF document")
        self.assertEqual(dna["extension"], ".pdf")
        self.assertEqual(dna["sha256"], result["sha256"])
        self.assertEqual(len(dna["sha256"]), 64)

    def test_file_dna_detects_signature_extension_mismatch(self):
        path = self.make_file("holiday.jpg", b"MZ" + b"x" * 128)
        result = scan_download_file(str(path), downloads_root=self.root)
        self.assertEqual(result["file_dna"]["signature"], "Windows PE executable")
        self.assertEqual(result["level"], "HIGH RISK")


if __name__ == "__main__":
    unittest.main()
