from pathlib import Path
import unittest


class ActivityMapUITests(unittest.TestCase):
    def test_activity_map_is_registered_in_sidebar_and_router(self):
        html = (Path(__file__).parents[1] / "pause_guard" / "web" / "index.html").read_text(encoding="utf-8")
        self.assertIn("['map','Activity Map']", html)
        self.assertIn("map:renderActivityMap", html)
        self.assertIn("async function renderActivityMap()", html)

    def test_activity_map_uses_real_authenticated_event_api_and_interactions(self):
        html = (Path(__file__).parents[1] / "pause_guard" / "web" / "index.html").read_text(encoding="utf-8")
        self.assertIn("/api/events?limit=120", html)
        for control in ("mapSearch", "mapRisk", "mapSurface", "mapZoomIn", "mapZoomOut", "mapReset"):
            self.assertIn(f'id="{control}"', html)
        self.assertIn("pointerdown", html)
        self.assertIn("pointermove", html)
        self.assertIn("Connections represent recorded hostname membership only", html)


if __name__ == "__main__":
    unittest.main()
