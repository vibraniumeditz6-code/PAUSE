import base64
import os
import tempfile
import unittest
import threading
import time
from pathlib import Path

from pause_guard.gmail import GmailIntegration, GmailIntegrationError, DpapiVault
from pause_guard.storage import Store


def b64(value: str) -> str:
    return base64.urlsafe_b64encode(value.encode()).decode().rstrip("=")


class GmailIntegrationTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        old = os.environ.get("LOCALAPPDATA")
        os.environ["LOCALAPPDATA"] = self.tmp.name
        self.addCleanup(lambda: os.environ.__setitem__("LOCALAPPDATA", old) if old is not None else os.environ.pop("LOCALAPPDATA", None))
        self.store = Store()
        self.results = []
        self.gmail = GmailIntegration(self.store, on_result=self.results.append)

    def tearDown(self):
        self.tmp.cleanup()

    def test_message_parser_collects_headers_body_links_and_attachments(self):
        msg = {
            "payload": {
                "headers": [
                    {"name": "From", "value": "Security Desk <alert@fake-login.test>"},
                    {"name": "Subject", "value": "Urgent account verification"},
                ],
                "mimeType": "multipart/mixed",
                "parts": [
                    {"mimeType": "text/plain", "body": {"data": b64("Verify your password immediately https://fake-login.test/account")}},
                    {"mimeType": "text/html", "body": {"data": b64('<p>Open <a href="https://fake-login.test/pay">this page</a></p>')}},
                    {"mimeType": "application/octet-stream", "filename": "statement.exe", "body": {}},
                ],
            }
        }
        payload = self.gmail._message_payload(msg)
        self.assertEqual(payload["sender"], "alert@fake-login.test")
        self.assertEqual(payload["subject"], "Urgent account verification")
        self.assertIn("Verify your password", payload["body"])
        self.assertIn("https://fake-login.test/pay", payload["body"])
        self.assertIn("statement.exe", payload["attachments"])

    def test_scan_recent_redacts_message_contents_from_event(self):
        message = {
            "payload": {
                "headers": [
                    {"name": "From", "value": "Security Desk <alert@fake-login.test>"},
                    {"name": "Subject", "value": "Urgent account verification"},
                ],
                "mimeType": "text/plain",
                "body": {"data": b64("Act now. Verify your password immediately at https://fake-login.test/login")},
            }
        }
        original_get = self.gmail._gmail_get
        self.gmail._gmail_get = lambda path, query=None: {"messages": [{"id": "message-id-123"}]} if path == "messages" else message
        seen = set()
        self.gmail._seen = lambda: seen
        self.gmail._mark_seen = lambda message_id, value: value.add(message_id)
        result = self.gmail.scan_recent()
        self.gmail._gmail_get = original_get
        self.assertEqual(result["scanned"], 1)
        self.assertEqual(len(self.results), 1)
        self.assertEqual(self.results[0]["level"], "HIGH RISK")
        self.assertNotIn("Verify your password", self.results[0]["summary"])
        self.assertNotIn("Urgent account verification", self.results[0]["summary"])

    def test_gmail_status_is_not_claimed_connected_without_decrypted_token(self):
        self.assertFalse(self.gmail.status()["connected"])
        self.assertIn("token_storage_supported", self.gmail.status())

    def test_monitoring_requires_an_authorised_account(self):
        with self.assertRaises(GmailIntegrationError):
            self.gmail.set_monitoring(True)

    def test_dpapi_vault_fails_closed_off_windows(self):
        if os.name == "nt":
            self.skipTest("DPAPI is available on Windows")
        with self.assertRaises(GmailIntegrationError):
            DpapiVault().save(Path(self.tmp.name) / "secret.bin", {"refresh_token": "do-not-store"})

    def test_monitor_can_be_toggled_without_old_worker_clobbering_new_state(self):
        self.gmail._tokens_cache = {"refresh_token": "test-refresh-token"}
        scan_condition = threading.Condition()
        scans = {"count": 0}

        def fake_scan(limit=20):
            with scan_condition:
                scans["count"] += 1
                scan_condition.notify_all()
            return {"scanned": 0, "alerts": 0}

        self.gmail.scan_recent = fake_scan
        self.gmail.set_monitoring(True)
        with scan_condition:
            self.assertTrue(scan_condition.wait_for(lambda: scans["count"] >= 1, timeout=2))
        self.gmail.set_monitoring(False)
        self.gmail.set_monitoring(True)
        with scan_condition:
            self.assertTrue(scan_condition.wait_for(lambda: scans["count"] >= 2, timeout=2))
        self.gmail.set_monitoring(False)
        time.sleep(0.05)
        self.assertFalse(self.gmail.status()["monitoring"])


if __name__ == "__main__":
    unittest.main()
