import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from pause_guard.storage import Store


class LocalAccountTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.patch = patch("pause_guard.storage.get_data_dir", return_value=Path(self.temp.name))
        self.patch.start()
        self.store = Store()

    def tearDown(self):
        self.patch.stop()
        self.temp.cleanup()

    def test_create_account_and_sign_in(self):
        account = self.store.create_account("Adwik Kukreti", "adwik@example.com", "A-strong-pass-123")
        self.assertEqual(account["email"], "adwik@example.com")
        self.assertEqual(self.store.account_count(), 1)
        self.store.sign_out()
        self.assertIsNone(self.store.current_account)
        logged_in = self.store.sign_in("ADWIK@example.com", "A-strong-pass-123")
        self.assertEqual(logged_in["display_name"], "Adwik Kukreti")

    def test_device_session_survives_store_restart_and_can_be_revoked(self):
        account = self.store.create_account("Example User", "example@example.com", "A-strong-pass-123")
        token = self.store.create_session(account, lifetime_days=30)
        # A second Store instance simulates restarting the desktop service.
        restarted = Store()
        restored = restarted.get_session_account(token)
        self.assertEqual(restored["email"], "example@example.com")
        restarted.revoke_session(token)
        self.assertIsNone(self.store.get_session_account(token))

    def test_password_is_not_stored_in_plain_text(self):
        self.store.create_account("Example User", "example@example.com", "A-strong-pass-123")
        with self.store._connect() as conn:
            row = conn.execute("SELECT password_hash,password_salt FROM accounts").fetchone()
        self.assertNotEqual(row["password_hash"], "A-strong-pass-123")
        self.assertEqual(len(row["password_salt"]), 32)

    def test_bad_password_is_rejected(self):
        self.store.create_account("Example User", "example@example.com", "A-strong-pass-123")
        self.store.sign_out()
        with self.assertRaisesRegex(ValueError, "incorrect"):
            self.store.sign_in("example@example.com", "wrong-password")

    def test_profile_and_password_can_be_updated(self):
        self.store.create_account("Example User", "example@example.com", "A-strong-pass-123")
        self.store.update_account_profile("Updated User", "updated@example.com")
        self.assertEqual(self.store.current_account["display_name"], "Updated User")
        self.store.change_account_password("A-strong-pass-123", "Another-strong-456")
        self.store.sign_out()
        self.store.sign_in("updated@example.com", "Another-strong-456")
        self.assertEqual(self.store.current_account["email"], "updated@example.com")

    def test_duplicate_email_and_weak_password_are_rejected(self):
        self.store.create_account("Example User", "example@example.com", "A-strong-pass-123")
        with self.assertRaisesRegex(ValueError, "already exists"):
            self.store.create_account("Second User", "EXAMPLE@example.com", "A-strong-pass-123")
        with self.assertRaisesRegex(ValueError, "10 characters"):
            self.store.create_account("Second User", "second@example.com", "short")

    def test_delete_account_requires_correct_password(self):
        self.store.create_account("Example User", "example@example.com", "A-strong-pass-123")
        with self.assertRaisesRegex(ValueError, "Password is incorrect"):
            self.store.delete_current_account("wrong-password")
        self.store.delete_current_account("A-strong-pass-123")
        self.assertEqual(self.store.account_count(), 0)
        self.assertIsNone(self.store.current_account)


if __name__ == "__main__":
    unittest.main()
