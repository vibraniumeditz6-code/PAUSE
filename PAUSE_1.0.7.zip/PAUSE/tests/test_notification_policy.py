import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from pause_guard.storage import Store


class QuietNotificationPolicyTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="pause-notifications-")
        self.root = Path(self.temp.name)
        self.patch = patch("pause_guard.storage.get_data_dir", return_value=self.root)
        self.patch.start()

    def tearDown(self):
        self.patch.stop()
        self.temp.cleanup()

    def test_new_install_defaults_to_quiet_and_no_safe_popups(self):
        store = Store()
        self.assertEqual(store.settings["notification_mode"], "quiet")
        self.assertFalse(store.settings["desktop_notifications"])
        self.assertFalse(store.settings["show_safe_notices"])

    def test_old_noisy_settings_are_migrated_to_quiet(self):
        (self.root / "settings.json").write_text(json.dumps({
            "desktop_notifications": True,
            "show_safe_notices": True,
            "theme": "light",
        }), encoding="utf-8")
        store = Store()
        self.assertEqual(store.settings["notification_mode"], "quiet")
        self.assertFalse(store.settings["desktop_notifications"])
        self.assertFalse(store.settings["show_safe_notices"])

    def test_critical_mode_is_forced_back_to_quiet(self):
        store = Store()
        updated = store.save_settings({"notification_mode": "critical"})
        self.assertEqual(updated["notification_mode"], "quiet")
        self.assertFalse(updated["desktop_notifications"])

    def test_legacy_notification_toggle_cannot_reenable_system_popups(self):
        store = Store()
        self.assertEqual(store.save_settings({"desktop_notifications": True})["notification_mode"], "quiet")
        self.assertFalse(store.settings["desktop_notifications"])
        self.assertEqual(store.save_settings({"desktop_notifications": False})["notification_mode"], "quiet")

    def test_quiet_mode_on_and_off_persist_without_enabling_os_notifications(self):
        store = Store()
        quiet = store.save_settings({"quiet_mode": True})
        self.assertTrue(quiet["quiet_mode"])
        self.assertEqual(quiet["notification_mode"], "quiet")
        loud = store.save_settings({"quiet_mode": False})
        self.assertFalse(loud["quiet_mode"])
        self.assertEqual(loud["notification_mode"], "quiet")
        self.assertFalse(loud["desktop_notifications"])
        self.assertFalse(loud["show_safe_notices"])


if __name__ == "__main__":
    unittest.main()
