# PAUSE Website

A self-contained, responsive landing page for PAUSE. It uses plain HTML, CSS and JavaScript; there is no build step or package installation.

## Preview locally

Open `index.html` in a browser, or run a local static server from this folder:

```bash
python -m http.server 8000
```

Then visit `http://localhost:8000`.

## Deploy with Vercel

1. Push the `website` folder to the root of your GitHub repository.
2. In Vercel, choose **Add New → Project** and import the PAUSE GitHub repository.
3. Set **Root Directory** to `website`.
4. Set **Framework Preset** to `Other`.
5. Leave **Build Command** blank and set **Output Directory** to `.`.
6. Deploy.

Vercel will build and host the static `index.html` site. No API key or environment variable is needed for this landing page.

## Important

This is a public marketing/information website, not the PAUSE desktop application's Python backend. The current desktop app and Chrome/Edge extension still run locally. Do not put `GEMINI_API_KEY`, `.env`, OAuth credentials, tokens, local databases or other secrets in this website or a public repository.
